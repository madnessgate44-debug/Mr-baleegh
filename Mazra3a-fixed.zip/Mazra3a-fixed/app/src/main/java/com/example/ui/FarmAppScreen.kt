package com.example.ui

import android.widget.Toast
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.animation.*
import androidx.compose.animation.core.*
import androidx.compose.foundation.background
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.verticalScroll
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.automirrored.filled.Send
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalLayoutDirection
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.LayoutDirection
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.example.api.GeminiManager
import com.example.data.*
import kotlinx.coroutines.launch

enum class ScreenTab {
    CHAT,
    MEETINGS,
    TABLES
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun FarmAppScreen(viewModel: FarmViewModel) {
    val currentTabString by viewModel.currentTab.collectAsStateWithLifecycle()
    val currentTab = when (currentTabString) {
        "TABLES" -> ScreenTab.TABLES
        "MEETINGS" -> ScreenTab.MEETINGS
        else -> ScreenTab.CHAT
    }
    var showApiKeyDialog by remember { mutableStateOf(false) }

    val context = LocalContext.current

    // Collect global voice-to-task states
    val voiceTaskAction by viewModel.voiceTaskAction.collectAsStateWithLifecycle()
    val isProcessingVoiceTask by viewModel.isProcessingVoiceTask.collectAsStateWithLifecycle()
    val isRecording by viewModel.isRecording.collectAsStateWithLifecycle()
    val recordingDuration by viewModel.recordingDuration.collectAsStateWithLifecycle()
    var showGlobalRecordingDialog by remember { mutableStateOf(false) }

    // Pulse animation for recording microphone
    val infiniteTransition = rememberInfiniteTransition(label = "global_pulse")
    val pulseScale by infiniteTransition.animateFloat(
        initialValue = 1f,
        targetValue = 1.25f,
        animationSpec = infiniteRepeatable(
            animation = tween(800, easing = FastOutSlowInEasing),
            repeatMode = RepeatMode.Reverse
        ),
        label = "global_scale"
    )

    val globalRecordPermissionLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.RequestPermission()
    ) { isGranted ->
        if (isGranted) {
            viewModel.startRecording()
            showGlobalRecordingDialog = true
        } else {
            android.widget.Toast.makeText(context, "يرجى تفعيل صلاحية الميكروفون للتسجيل", android.widget.Toast.LENGTH_SHORT).show()
        }
    }

    // Force Right-to-Left (RTL) for perfect Arabic alignment
    CompositionLocalProvider(LocalLayoutDirection provides LayoutDirection.Rtl) {
        Scaffold(
            topBar = {
                TopAppBar(
                    title = {
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(8.dp)
                        ) {
                            Text(
                                "🌾 إدارة المزرعة الذكية",
                                fontWeight = FontWeight.Bold,
                                color = MaterialTheme.colorScheme.onPrimary
                            )
                        }
                    },
                    colors = TopAppBarDefaults.topAppBarColors(
                        containerColor = MaterialTheme.colorScheme.primary,
                        titleContentColor = MaterialTheme.colorScheme.onPrimary
                    ),
                    actions = {
                        IconButton(
                            onClick = { showApiKeyDialog = true },
                            modifier = Modifier.testTag("settings_button")
                        ) {
                            Icon(
                                imageVector = Icons.Default.Settings,
                                contentDescription = "الإعدادات",
                                tint = MaterialTheme.colorScheme.onPrimary
                            )
                        }
                    }
                )
            },
            bottomBar = {
                NavigationBar(
                    containerColor = MaterialTheme.colorScheme.surface,
                    tonalElevation = 8.dp
                ) {
                    NavigationBarItem(
                        selected = currentTab == ScreenTab.TABLES,
                        onClick = { viewModel.currentTab.value = "TABLES" },
                        icon = { Icon(Icons.Default.GridOn, contentDescription = "الجداول") },
                        label = { Text("الجداول") },
                        modifier = Modifier.testTag("nav_tables")
                    )
                    NavigationBarItem(
                        selected = currentTab == ScreenTab.CHAT,
                        onClick = { viewModel.currentTab.value = "CHAT" },
                        icon = { Icon(Icons.Default.Chat, contentDescription = "الأستاذ بليغ") },
                        label = { Text("الأستاذ بليغ") },
                        modifier = Modifier.testTag("nav_chat")
                    )
                    NavigationBarItem(
                        selected = currentTab == ScreenTab.MEETINGS,
                        onClick = { viewModel.currentTab.value = "MEETINGS" },
                        icon = { Icon(Icons.Default.People, contentDescription = "الاجتماعات") },
                        label = { Text("الاجتماعات") },
                        modifier = Modifier.testTag("nav_meetings")
                    )
                }
            },
            floatingActionButton = {
                if (currentTab != ScreenTab.CHAT) {
                    ExtendedFloatingActionButton(
                        onClick = {
                            globalRecordPermissionLauncher.launch(android.Manifest.permission.RECORD_AUDIO)
                        },
                        containerColor = MaterialTheme.colorScheme.primary,
                        contentColor = MaterialTheme.colorScheme.onPrimary,
                        icon = { Icon(Icons.Default.Mic, contentDescription = "اسأل الأستاذ بليغ") },
                        text = { Text("اسأل الأستاذ بليغ 🎙️", fontWeight = FontWeight.Bold) },
                        modifier = Modifier.testTag("global_voice_to_task_fab")
                    )
                }
            }
        ) { innerPadding ->
            Box(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(innerPadding)
                    .background(MaterialTheme.colorScheme.background)
            ) {
                when (currentTab) {
                    ScreenTab.CHAT -> ChatScreen(viewModel)
                    ScreenTab.MEETINGS -> MeetingsScreen(viewModel)
                    ScreenTab.TABLES -> TablesScreen(viewModel)
                }
            }
        }

        if (showApiKeyDialog) {
            ApiKeySettingsDialog(
                context = context,
                onDismiss = { showApiKeyDialog = false }
            )
        }

        // --- Global Voice-to-Task Dialogs & Overlays ---
        if (isProcessingVoiceTask) {
            Dialog(onDismissRequest = {}) {
                Card(
                    shape = RoundedCornerShape(24.dp),
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                    elevation = CardDefaults.cardElevation(defaultElevation = 8.dp)
                ) {
                    Column(
                        modifier = Modifier.padding(24.dp),
                        horizontalAlignment = Alignment.CenterHorizontally,
                        verticalArrangement = Arrangement.spacedBy(16.dp)
                    ) {
                        CircularProgressIndicator(color = MaterialTheme.colorScheme.primary)
                        Text(
                            text = "الأستاذ بيسمع ويفهم كلامك كالعادة... 🌾",
                            fontSize = 14.sp,
                            fontWeight = FontWeight.Bold,
                            color = MaterialTheme.colorScheme.primary,
                            textAlign = TextAlign.Center
                        )
                    }
                }
            }
        }

        voiceTaskAction?.let { action ->
            VoiceToTaskFillDialog(
                action = action,
                onDismiss = { viewModel.dismissVoiceTask() },
                onConfirm = { editedData ->
                    viewModel.confirmVoiceTask(editedData)
                    android.widget.Toast.makeText(context, "تم حفظ وتحديث السجل بنجاح! 🎉", android.widget.Toast.LENGTH_SHORT).show()
                }
            )
        }

        if (showGlobalRecordingDialog) {
            Dialog(onDismissRequest = {
                viewModel.cancelRecording()
                showGlobalRecordingDialog = false
            }) {
                Card(
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                    shape = RoundedCornerShape(24.dp),
                    border = BorderStroke(2.dp, MaterialTheme.colorScheme.primary.copy(alpha = 0.3f)),
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(16.dp)
                ) {
                    Column(
                        modifier = Modifier
                            .padding(20.dp)
                            .fillMaxWidth(),
                        horizontalAlignment = Alignment.CenterHorizontally,
                        verticalArrangement = Arrangement.spacedBy(16.dp)
                    ) {
                        Text(
                            text = "🎙️ الميكروفون الذكي للتعبئة التلقائية",
                            fontWeight = FontWeight.Bold,
                            fontSize = 16.sp,
                            color = MaterialTheme.colorScheme.primary
                        )

                        Text(
                            text = "أحمد باشا، اتكلم وسجل المعاملة (مثلا: حضور عامل, بيع, شراء, حركة خزنة) ليتم تعبئة البيانات تلقائياً!",
                            fontSize = 12.sp,
                            textAlign = TextAlign.Center,
                            color = Color.Gray,
                            modifier = Modifier.padding(horizontal = 8.dp)
                        )

                        Spacer(modifier = Modifier.height(8.dp))

                        // Pulsating Record Circle
                        Box(
                            contentAlignment = Alignment.Center,
                            modifier = Modifier.size(110.dp)
                        ) {
                            Box(
                                modifier = Modifier
                                    .size(80.dp * pulseScale)
                                    .background(
                                        color = Color.Red.copy(alpha = 0.15f),
                                        shape = CircleShape
                                    )
                            )
                            Box(
                                modifier = Modifier
                                    .size(70.dp)
                                    .background(
                                        color = Color.Red.copy(alpha = 0.8f),
                                        shape = CircleShape
                                    )
                                    .clickable {
                                        viewModel.stopRecordingAndSend(isGlobalVoiceToTask = true)
                                        showGlobalRecordingDialog = false
                                    },
                                contentAlignment = Alignment.Center
                            ) {
                                Icon(
                                    imageVector = Icons.Default.VolumeUp,
                                    contentDescription = "تسجيل",
                                    tint = Color.White,
                                    modifier = Modifier.size(36.dp)
                                )
                            }
                        }

                        // Recording Timer Display
                        val seconds = recordingDuration % 60
                        val minutes = recordingDuration / 60
                        Text(
                            text = String.format("%02d:%02d", minutes, seconds),
                            fontWeight = FontWeight.Bold,
                            fontSize = 24.sp,
                            color = Color.Red
                        )

                        Text(
                            text = "جاري تسجيل الصوت الآن ورفع الذبذبات...",
                            fontSize = 11.sp,
                            color = Color.Gray
                        )

                        HorizontalDivider(modifier = Modifier.fillMaxWidth().padding(vertical = 4.dp))

                        Text(
                            text = "💡 مواضيع سريعة مقترحة (اضغط للتسجيل الفوري):",
                            fontWeight = FontWeight.Bold,
                            fontSize = 12.sp,
                            color = MaterialTheme.colorScheme.onSurface,
                            modifier = Modifier.align(Alignment.Start)
                        )

                        val presets = listOf(
                            "بعت النهارده محصول طماطم بـ 5000 جنيه ودخلها الخزنة" to "بيع طماطم بـ 5000",
                            "اشتريت علف للمواشي بـ 1200 جنيه وصرفتهم من الخزينة" to "شراء علف بـ 1200",
                            "سجل حضور العامل فرج النهارده وسجل له يومية كاملة" to "حضور العامل فرج",
                            "سجل آلة جديدة كود 00543 واسم آلة ري وتكلفة 50 جنيه في سجل المعدات" to "🚜 إضافة آلة ري كود 00543 وتكلفة 50 ج.م"
                        )

                        presets.forEach { (fullText, shortText) ->
                            Button(
                                onClick = {
                                    viewModel.stopRecordingAndSend(simulatedText = fullText, isGlobalVoiceToTask = true)
                                    showGlobalRecordingDialog = false
                                },
                                colors = ButtonDefaults.buttonColors(containerColor = MaterialTheme.colorScheme.surfaceVariant),
                                shape = RoundedCornerShape(12.dp),
                                modifier = Modifier.fillMaxWidth(),
                                contentPadding = PaddingValues(horizontal = 12.dp, vertical = 6.dp)
                            ) {
                                Row(
                                    modifier = Modifier.fillMaxWidth(),
                                    horizontalArrangement = Arrangement.SpaceBetween,
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    Text(
                                        text = "🗣️ \"$shortText...\"",
                                        fontSize = 11.sp,
                                        fontWeight = FontWeight.Bold,
                                        color = MaterialTheme.colorScheme.onSurfaceVariant
                                    )
                                    Icon(
                                        imageVector = Icons.Default.PlayArrow,
                                        contentDescription = null,
                                        tint = MaterialTheme.colorScheme.primary,
                                        modifier = Modifier.size(16.dp)
                                    )
                                }
                            }
                        }
                    }
                }
            }
        }
    }
}

@Composable
fun ChatScreen(viewModel: FarmViewModel) {
    val messages by viewModel.chatMessages.collectAsStateWithLifecycle()
    val isLoading by viewModel.isChatLoading.collectAsStateWithLifecycle()
    val isRecording by viewModel.isRecording.collectAsStateWithLifecycle()
    val recordingDuration by viewModel.recordingDuration.collectAsStateWithLifecycle()
    val questionnaireStep by viewModel.questionnaireStep.collectAsStateWithLifecycle()
    var inputQuery by remember { mutableStateOf("") }
    val listState = rememberLazyListState()
    val scope = rememberCoroutineScope()
    var showRecordingDialog by remember { mutableStateOf(false) }
    var showAttachmentOptions by remember { mutableStateOf(false) }

    // Pulse animation for recording microphone
    val infiniteTransition = rememberInfiniteTransition(label = "pulse")
    val pulseScale by infiniteTransition.animateFloat(
        initialValue = 1f,
        targetValue = 1.25f,
        animationSpec = infiniteRepeatable(
            animation = tween(800, easing = FastOutSlowInEasing),
            repeatMode = RepeatMode.Reverse
        ),
        label = "scale"
    )

    // Voice record permission launcher
    val recordPermissionLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.RequestPermission()
    ) { isGranted ->
        // Start recording regardless to support emulator fallback gracefully
        viewModel.startRecording()
        showRecordingDialog = true
    }

    // Scroll to bottom when new messages arrive
    LaunchedEffect(messages.size) {
        if (messages.isNotEmpty()) {
            listState.animateScrollToItem(messages.size - 1)
        }
    }

    Column(modifier = Modifier.fillMaxSize().padding(8.dp)) {
        // Excel Questionnaire Banner
        if (questionnaireStep == -1) {
            Card(
                onClick = { viewModel.startExcelQuestionnaire() },
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.primaryContainer),
                shape = RoundedCornerShape(12.dp),
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(bottom = 8.dp)
            ) {
                Row(
                    modifier = Modifier.padding(12.dp),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(12.dp)
                ) {
                    Box(
                        modifier = Modifier
                            .background(MaterialTheme.colorScheme.primary, CircleShape)
                            .padding(8.dp)
                    ) {
                        Icon(
                            imageVector = Icons.Default.Analytics,
                            contentDescription = null,
                            tint = MaterialTheme.colorScheme.onPrimary,
                            modifier = Modifier.size(24.dp)
                        )
                    }
                    Column(modifier = Modifier.weight(1f)) {
                        Text(
                            text = "📊 استبيان هيكلة ملف الإكسل لبناء البيانات",
                            fontWeight = FontWeight.Bold,
                            fontSize = 13.sp,
                            color = MaterialTheme.colorScheme.onPrimaryContainer
                        )
                        Text(
                            text = "اضغط هنا لبدء استبيان ودي مع الأستاذ لفهم شيت الإكسل الخاص بك وتجهيز القالب المتوافق.",
                            fontSize = 11.sp,
                            color = MaterialTheme.colorScheme.onPrimaryContainer.copy(alpha = 0.8f)
                        )
                    }
                    Icon(
                        imageVector = Icons.Default.PlayArrow,
                        contentDescription = null,
                        tint = MaterialTheme.colorScheme.primary
                    )
                }
            }
        } else {
            Card(
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.tertiaryContainer),
                shape = RoundedCornerShape(12.dp),
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(bottom = 8.dp)
            ) {
                Row(
                    modifier = Modifier.padding(12.dp),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(12.dp)
                ) {
                    CircularProgressIndicator(
                        progress = { (questionnaireStep + 1) / 5f },
                        color = MaterialTheme.colorScheme.tertiary,
                        trackColor = MaterialTheme.colorScheme.tertiaryContainer.copy(alpha = 0.5f),
                        modifier = Modifier.size(24.dp),
                        strokeWidth = 3.dp
                    )
                    Column(modifier = Modifier.weight(1f)) {
                        Text(
                            text = "استبيان الإكسل نشط (الخطوة ${questionnaireStep + 1} من 5)",
                            fontWeight = FontWeight.Bold,
                            fontSize = 13.sp,
                            color = MaterialTheme.colorScheme.onTertiaryContainer
                        )
                        Text(
                            text = "جاوب الأستاذ في الشات بالصوت أو النص لمتابعة تصميم هيكل الإكسل بتاعك.",
                            fontSize = 11.sp,
                            color = MaterialTheme.colorScheme.onTertiaryContainer.copy(alpha = 0.8f)
                        )
                    }
                }
            }
        }

        // Chat History Scroll List
        LazyColumn(
            state = listState,
            modifier = Modifier
                .weight(1f)
                .fillMaxWidth()
                .padding(horizontal = 8.dp),
            verticalArrangement = Arrangement.spacedBy(8.dp),
            contentPadding = PaddingValues(top = 8.dp, bottom = 16.dp)
        ) {
            items(messages, key = { it.id }) { message ->
                ChatBubble(message)
            }

            if (isLoading) {
                item {
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(8.dp),
                        horizontalArrangement = Arrangement.Start
                    ) {
                        Card(
                            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant),
                            shape = RoundedCornerShape(12.dp)
                        ) {
                            Row(
                                modifier = Modifier.padding(horizontal = 16.dp, vertical = 10.dp),
                                verticalAlignment = Alignment.CenterVertically,
                                horizontalArrangement = Arrangement.spacedBy(4.dp)
                            ) {
                                Text("الأستاذ بيفكر ويكتب...", fontSize = 13.sp, color = Color.Gray)
                                CircularProgressIndicator(
                                    modifier = Modifier.size(14.dp),
                                    strokeWidth = 2.dp,
                                    color = MaterialTheme.colorScheme.primary
                                )
                            }
                        }
                    }
                }
            }
        }

        // Smart Documents Simulated Uploads
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 8.dp, vertical = 4.dp),
            verticalArrangement = Arrangement.spacedBy(4.dp)
        ) {
            Text(
                text = "📸 التحليل الذكي للصور والمستندات (أرسل مستنداً للأستاذ بليغ):",
                fontSize = 11.sp,
                fontWeight = FontWeight.Bold,
                color = MaterialTheme.colorScheme.primary,
                modifier = Modifier.padding(start = 4.dp)
            )
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .horizontalScroll(rememberScrollState()),
                horizontalArrangement = Arrangement.spacedBy(6.dp)
            ) {
                // Chip 1: INVOICE
                Card(
                    modifier = Modifier.clickable { viewModel.processAttachedDocument("INVOICE") },
                    colors = CardDefaults.cardColors(containerColor = Color(0xFFE8F5E9)),
                    shape = RoundedCornerShape(16.dp),
                    border = BorderStroke(1.dp, Color(0xFF81C784))
                ) {
                    Text(
                        text = "📄 مسح فاتورة سماد 📸",
                        fontSize = 10.sp,
                        fontWeight = FontWeight.Bold,
                        color = Color(0xFF2E7D32),
                        modifier = Modifier.padding(horizontal = 10.dp, vertical = 6.dp)
                    )
                }

                // Chip 2: CROP_SICK
                Card(
                    modifier = Modifier.clickable { viewModel.processAttachedDocument("CROP_SICK") },
                    colors = CardDefaults.cardColors(containerColor = Color(0xFFFFF3E0)),
                    shape = RoundedCornerShape(16.dp),
                    border = BorderStroke(1.dp, Color(0xFFFFB74D))
                ) {
                    Text(
                        text = "🌾 تصوير نبات مصاب 🔍",
                        fontSize = 10.sp,
                        fontWeight = FontWeight.Bold,
                        color = Color(0xFFE65100),
                        modifier = Modifier.padding(horizontal = 10.dp, vertical = 6.dp)
                    )
                }

                // Chip 3: SOIL_TEST
                Card(
                    modifier = Modifier.clickable { viewModel.processAttachedDocument("SOIL_TEST") },
                    colors = CardDefaults.cardColors(containerColor = Color(0xFFE0F7FA)),
                    shape = RoundedCornerShape(16.dp),
                    border = BorderStroke(1.dp, Color(0xFF4DD0E1))
                ) {
                    Text(
                        text = "🧪 فحص عينة تربة 🔬",
                        fontSize = 10.sp,
                        fontWeight = FontWeight.Bold,
                        color = Color(0xFF006064),
                        modifier = Modifier.padding(horizontal = 10.dp, vertical = 6.dp)
                    )
                }

                // Chip 4: ACCOUNT_STATEMENT
                Card(
                    modifier = Modifier.clickable { viewModel.processAttachedDocument("ACCOUNT_STATEMENT") },
                    colors = CardDefaults.cardColors(containerColor = Color(0xFFEDE7F6)),
                    shape = RoundedCornerShape(16.dp),
                    border = BorderStroke(1.dp, Color(0xFF9575CD))
                ) {
                    Text(
                        text = "📝 كشف حساب تاجر 🤝",
                        fontSize = 10.sp,
                        fontWeight = FontWeight.Bold,
                        color = Color(0xFF311B92),
                        modifier = Modifier.padding(horizontal = 10.dp, vertical = 6.dp)
                    )
                }
            }
        }

        // Chat Input Box
        Surface(
            tonalElevation = 4.dp,
            modifier = Modifier.fillMaxWidth().clip(RoundedCornerShape(16.dp))
        ) {
            Row(
                modifier = Modifier
                    .padding(10.dp)
                    .fillMaxWidth(),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                // Attachment Picker Button
                IconButton(
                    onClick = { showAttachmentOptions = true },
                    modifier = Modifier
                        .size(46.dp)
                        .background(
                            color = MaterialTheme.colorScheme.primaryContainer,
                            shape = CircleShape
                        )
                ) {
                    Icon(
                        imageVector = Icons.Default.AttachFile,
                        contentDescription = "إرفاق مستند أو صورة",
                        tint = MaterialTheme.colorScheme.onPrimaryContainer,
                        modifier = Modifier.size(24.dp)
                    )
                }

                // Microphone Recording Option
                IconButton(
                    onClick = {
                        recordPermissionLauncher.launch(android.Manifest.permission.RECORD_AUDIO)
                    },
                    modifier = Modifier
                        .size(46.dp)
                        .background(
                            color = MaterialTheme.colorScheme.secondaryContainer,
                            shape = CircleShape
                        )
                ) {
                    Icon(
                        imageVector = Icons.Default.Mic,
                        contentDescription = "تسجيل صوتي",
                        tint = MaterialTheme.colorScheme.onSecondaryContainer,
                        modifier = Modifier.size(24.dp)
                    )
                }

                OutlinedTextField(
                    value = inputQuery,
                    onValueChange = { inputQuery = it },
                    placeholder = { Text("مثال: بعت النهارده طماطم بـ 5000 جنيه...") },
                    modifier = Modifier
                        .weight(1f)
                        .testTag("chat_input_text"),
                    shape = RoundedCornerShape(24.dp),
                    colors = OutlinedTextFieldDefaults.colors(
                        focusedBorderColor = MaterialTheme.colorScheme.primary,
                        unfocusedBorderColor = Color.LightGray
                    ),
                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Text),
                    maxLines = 3
                )

                FloatingActionButton(
                    onClick = {
                        if (inputQuery.trim().isNotEmpty()) {
                            viewModel.sendChatMessage(inputQuery)
                            inputQuery = ""
                        }
                    },
                    containerColor = MaterialTheme.colorScheme.primary,
                    contentColor = MaterialTheme.colorScheme.onPrimary,
                    shape = CircleShape,
                    modifier = Modifier
                        .size(46.dp)
                        .testTag("chat_send_button")
                ) {
                    Icon(
                        imageVector = Icons.AutoMirrored.Filled.Send,
                        contentDescription = "إرسال",
                        modifier = Modifier.size(20.dp)
                    )
                }
            }
        }
    }

    // Loud and Clear Audio Recording Dialog
    if (showRecordingDialog) {
        Dialog(onDismissRequest = {
            viewModel.cancelRecording()
            showRecordingDialog = false
        }) {
            Card(
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                shape = RoundedCornerShape(24.dp),
                border = BorderStroke(2.dp, MaterialTheme.colorScheme.primary.copy(alpha = 0.3f)),
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(16.dp)
            ) {
                Column(
                    modifier = Modifier
                        .padding(20.dp)
                        .fillMaxWidth(),
                    horizontalAlignment = Alignment.CenterHorizontally,
                    verticalArrangement = Arrangement.spacedBy(16.dp)
                ) {
                    Text(
                        text = "🎙️ الميكروفون الذكي نشط",
                        fontWeight = FontWeight.Bold,
                        fontSize = 18.sp,
                        color = MaterialTheme.colorScheme.primary
                    )

                    Text(
                        text = "أحمد باشا، اتكلم وسجل كل اللي حصل النهارده في المزرعة أو جاوب على أسئلة شيت الإكسل بالصوت!",
                        fontSize = 12.sp,
                        textAlign = TextAlign.Center,
                        color = Color.Gray,
                        modifier = Modifier.padding(horizontal = 8.dp)
                    )

                    Spacer(modifier = Modifier.height(8.dp))

                    // Pulsating Record Circle
                    Box(
                        contentAlignment = Alignment.Center,
                        modifier = Modifier.size(110.dp)
                    ) {
                        Box(
                            modifier = Modifier
                                .size(80.dp * pulseScale)
                                .background(
                                    color = Color.Red.copy(alpha = 0.15f),
                                    shape = CircleShape
                                )
                        )
                        Box(
                            modifier = Modifier
                                .size(70.dp)
                                .background(
                                    color = Color.Red.copy(alpha = 0.8f),
                                    shape = CircleShape
                                )
                                .clickable {
                                    viewModel.stopRecordingAndSend()
                                    showRecordingDialog = false
                                },
                            contentAlignment = Alignment.Center
                        ) {
                            Icon(
                                imageVector = Icons.Default.VolumeUp,
                                contentDescription = "تسجيل",
                                tint = Color.White,
                                modifier = Modifier.size(36.dp)
                            )
                        }
                    }

                    // Recording Timer Display
                    val seconds = recordingDuration % 60
                    val minutes = recordingDuration / 60
                    Text(
                        text = String.format("%02d:%02d", minutes, seconds),
                        fontWeight = FontWeight.Bold,
                        fontSize = 24.sp,
                        color = Color.Red
                    )

                    Text(
                        text = "جاري تسجيل الصوت الآن ورفع الذبذبات...",
                        fontSize = 11.sp,
                        color = Color.Gray
                    )

                    HorizontalDivider(modifier = Modifier.fillMaxWidth().padding(vertical = 4.dp))

                    // Quick simulation phrases in Egyptian Arabic
                    Text(
                        text = "💡 مواضيع سريعة مقترحة (اضغط للتكلم الفوري):",
                        fontWeight = FontWeight.Bold,
                        fontSize = 12.sp,
                        color = MaterialTheme.colorScheme.onSurface,
                        modifier = Modifier.align(Alignment.Start)
                    )

                    val presets = listOf(
                        "بعت النهارده محصول طماطم بـ 5000 جنيه ودخلها الخزنة" to "بعت محصول طماطم بـ 5000 جنيه",
                        "اشتريت علف للمواشي بـ 1200 جنيه وصرفتهم من الخزينة" to "شراء علف للمواشي بـ 1200 جنيه",
                        "سجل حضور العامل فرج النهارده وسجل له يومية كاملة" to "حضور العامل فرج",
                        "الأعمدة هي التاريخ، الصنف، القيمة، اسم العامل، والملاحظات" to "أعمدة الشيت الإكسل"
                    )

                    presets.forEach { (fullText, shortText) ->
                        Button(
                            onClick = {
                                viewModel.stopRecordingAndSend(fullText)
                                showRecordingDialog = false
                            },
                            colors = ButtonDefaults.buttonColors(containerColor = MaterialTheme.colorScheme.surfaceVariant),
                            shape = RoundedCornerShape(12.dp),
                            modifier = Modifier.fillMaxWidth(),
                            contentPadding = PaddingValues(horizontal = 12.dp, vertical = 6.dp)
                        ) {
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Text(
                                    text = "🗣️ \"$shortText...\"",
                                    fontSize = 11.sp,
                                    fontWeight = FontWeight.Bold,
                                    color = MaterialTheme.colorScheme.onSurfaceVariant
                                )
                                Icon(
                                    imageVector = Icons.Default.PlayArrow,
                                    contentDescription = null,
                                    tint = MaterialTheme.colorScheme.primary,
                                    modifier = Modifier.size(16.dp)
                                )
                            }
                        }
                    }

                    Spacer(modifier = Modifier.height(8.dp))

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(12.dp)
                    ) {
                        OutlinedButton(
                            onClick = {
                                viewModel.cancelRecording()
                                showRecordingDialog = false
                            },
                            modifier = Modifier.weight(1f),
                            shape = RoundedCornerShape(12.dp)
                        ) {
                            Text("إلغاء", fontSize = 13.sp, color = Color.Red)
                        }

                        Button(
                            onClick = {
                                viewModel.stopRecordingAndSend()
                                showRecordingDialog = false
                            },
                            colors = ButtonDefaults.buttonColors(containerColor = MaterialTheme.colorScheme.primary),
                            modifier = Modifier.weight(1f),
                            shape = RoundedCornerShape(12.dp)
                        ) {
                            Text("إنهاء وإرسال", fontSize = 13.sp, color = Color.White)
                        }
                    }
                }
            }
        }
    }

    // Attachment Options Custom Dialog
    if (showAttachmentOptions) {
        AlertDialog(
            onDismissRequest = { showAttachmentOptions = false },
            title = {
                Text(
                    text = "📎 إرفاق مستند أو التقاط صورة",
                    fontWeight = FontWeight.Bold,
                    fontSize = 16.sp,
                    textAlign = TextAlign.Right,
                    modifier = Modifier.fillMaxWidth()
                )
            },
            text = {
                Column(
                    modifier = Modifier.fillMaxWidth(),
                    verticalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    Text(
                        text = "اختر نوع المستند أو الصورة التي تريد من الأستاذ بليغ معالجتها وإدخال بياناتها تلقائياً:",
                        fontSize = 12.sp,
                        color = Color.Gray,
                        textAlign = TextAlign.Right,
                        modifier = Modifier.fillMaxWidth()
                    )

                    // Invoice option
                    Button(
                        onClick = {
                            showAttachmentOptions = false
                            viewModel.processAttachedDocument("INVOICE")
                        },
                        colors = ButtonDefaults.buttonColors(containerColor = Color(0xFFE8F5E9)),
                        modifier = Modifier.fillMaxWidth(),
                        shape = RoundedCornerShape(12.dp)
                    ) {
                        Text("📸 مسح فاتورة شراء أسمدة ضوئياً", color = Color(0xFF2E7D32), fontWeight = FontWeight.Bold, fontSize = 12.sp)
                    }

                    // Sick plant option
                    Button(
                        onClick = {
                            showAttachmentOptions = false
                            viewModel.processAttachedDocument("CROP_SICK")
                        },
                        colors = ButtonDefaults.buttonColors(containerColor = Color(0xFFFFF3E0)),
                        modifier = Modifier.fillMaxWidth(),
                        shape = RoundedCornerShape(12.dp)
                    ) {
                        Text("🔍 تصوير نبات مصاب وتشخيص المرض", color = Color(0xFFE65100), fontWeight = FontWeight.Bold, fontSize = 12.sp)
                    }

                    // Soil report option
                    Button(
                        onClick = {
                            showAttachmentOptions = false
                            viewModel.processAttachedDocument("SOIL_TEST")
                        },
                        colors = ButtonDefaults.buttonColors(containerColor = Color(0xFFE0F7FA)),
                        modifier = Modifier.fillMaxWidth(),
                        shape = RoundedCornerShape(12.dp)
                    ) {
                        Text("🔬 تحليل تقرير عينات ومياه التربة", color = Color(0xFF006064), fontWeight = FontWeight.Bold, fontSize = 12.sp)
                    }

                    // Statement option
                    Button(
                        onClick = {
                            showAttachmentOptions = false
                            viewModel.processAttachedDocument("ACCOUNT_STATEMENT")
                        },
                        colors = ButtonDefaults.buttonColors(containerColor = Color(0xFFEDE7F6)),
                        modifier = Modifier.fillMaxWidth(),
                        shape = RoundedCornerShape(12.dp)
                    ) {
                        Text("📝 معالجة كشف حساب تاجر أو مورد", color = Color(0xFF311B92), fontWeight = FontWeight.Bold, fontSize = 12.sp)
                    }

                    // Excel Option
                    Button(
                        onClick = {
                            showAttachmentOptions = false
                            viewModel.exportCompleteFarmDataToCSV()
                        },
                        colors = ButtonDefaults.buttonColors(containerColor = Color(0xFFE2F0D9)),
                        modifier = Modifier.fillMaxWidth(),
                        shape = RoundedCornerShape(12.dp)
                    ) {
                        Text("📊 تصدير شيت الإكسل الشامل وتحميله", color = Color(0xFF1B5E20), fontWeight = FontWeight.Bold, fontSize = 12.sp)
                    }
                }
            },
            confirmButton = {
                TextButton(onClick = { showAttachmentOptions = false }) {
                    Text("إلغاء", color = Color.Gray)
                }
            }
        )
    }
}

@Composable
fun ChatBubble(message: ChatMessage) {
    val isUser = message.isUser
    val alignment = if (isUser) Alignment.End else Alignment.Start
    val bg = if (isUser) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.surface
    val textColor = if (isUser) MaterialTheme.colorScheme.onPrimary else MaterialTheme.colorScheme.onSurface
    val shape = if (isUser) {
        RoundedCornerShape(topStart = 16.dp, topEnd = 16.dp, bottomStart = 16.dp, bottomEnd = 2.dp)
    } else {
        RoundedCornerShape(topStart = 16.dp, topEnd = 16.dp, bottomStart = 2.dp, bottomEnd = 16.dp)
    }

    Column(
        modifier = Modifier
            .fillMaxWidth()
            .padding(vertical = 4.dp),
        horizontalAlignment = alignment
    ) {
        Card(
            colors = CardDefaults.cardColors(containerColor = bg),
            shape = shape,
            elevation = CardDefaults.cardElevation(defaultElevation = 2.dp),
            modifier = Modifier.widthIn(max = 280.dp)
        ) {
            Column(modifier = Modifier.padding(12.dp)) {
                // Name Tag
                Text(
                    text = if (isUser) "أحمد باشا" else "الأستاذ مساعد المزرعة 👨‍🌾",
                    fontSize = 11.sp,
                    fontWeight = FontWeight.Bold,
                    color = if (isUser) MaterialTheme.colorScheme.primaryContainer else MaterialTheme.colorScheme.primary,
                    modifier = Modifier.padding(bottom = 4.dp)
                )

                Text(
                    text = message.text,
                    fontSize = 14.sp,
                    color = textColor,
                    lineHeight = 20.sp
                )

                // Database trigger success flag
                if (message.actionSuccess && message.actionTable != null) {
                    Spacer(modifier = Modifier.height(6.dp))
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        modifier = Modifier
                            .clip(RoundedCornerShape(4.dp))
                            .background(Color(0xFFE8F8F5))
                            .padding(horizontal = 6.dp, vertical = 2.dp)
                    ) {
                        Text("✓ تم حفظ البيانات بجدول: ${translateTableName(message.actionTable)}", fontSize = 11.sp, color = Color(0xFF16A085), fontWeight = FontWeight.Bold)
                    }
                }
            }
        }
    }
}

@Composable
fun ApiKeySettingsDialog(context: android.content.Context, onDismiss: () -> Unit) {
    var keyInput by remember { mutableStateOf(GeminiManager.getApiKey(context)) }

    Dialog(onDismissRequest = onDismiss) {
        Card(
            shape = RoundedCornerShape(16.dp),
            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
            modifier = Modifier
                .fillMaxWidth()
                .padding(16.dp)
        ) {
            Column(
                modifier = Modifier.padding(16.dp),
                horizontalAlignment = Alignment.CenterHorizontally
            ) {
                Text(
                    "⚙️ إعدادات مفتاح Gemini API",
                    fontSize = 18.sp,
                    fontWeight = FontWeight.Bold,
                    modifier = Modifier.fillMaxWidth(),
                    textAlign = TextAlign.Center
                )
                Spacer(modifier = Modifier.height(12.dp))
                Text(
                    "لتفعيل الذكاء الاصطناعي بالكامل، يرجى كتابة أو لصق مفتاح API الخاص بك من Google AI Studio:",
                    fontSize = 13.sp,
                    color = Color.Gray,
                    lineHeight = 18.sp
                )
                Spacer(modifier = Modifier.height(12.dp))
                OutlinedTextField(
                    value = keyInput,
                    onValueChange = { keyInput = it },
                    label = { Text("Gemini API Key") },
                    modifier = Modifier
                        .fillMaxWidth()
                        .testTag("api_key_field"),
                    singleLine = true
                )
                Spacer(modifier = Modifier.height(16.dp))
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    Button(
                        onClick = {
                            GeminiManager.saveApiKey(context, keyInput)
                            Toast.makeText(context, "تم حفظ المفتاح بنجاح ✓", Toast.LENGTH_SHORT).show()
                            onDismiss()
                        },
                        colors = ButtonDefaults.buttonColors(containerColor = MaterialTheme.colorScheme.primary),
                        modifier = Modifier.weight(1f)
                    ) {
                        Text("حفظ")
                    }
                    OutlinedButton(
                        onClick = onDismiss,
                        modifier = Modifier.weight(1f)
                    ) {
                        Text("إلغاء")
                    }
                }
            }
        }
    }
}

// Translate system table name to Arabic for friendly reading
fun translateTableName(name: String): String {
    return when (name.lowercase()) {
        "land" -> "الأراضي 🗺️"
        "crops" -> "المحاصيل 🌱"
        "operations" -> "العمليات الزراعية 🚜"
        "inventory" -> "مستودع المخزون 📦"
        "inventory_movement" -> "حركات المخزون 🔄"
        "animals" -> "الثروة الحيوانية 🐄"
        "animal_production" -> "الإنتاج الحيواني 🥛"
        "workers" -> "العمال 👨‍🌾"
        "attendance" -> "حضور وغياب العمال ⏰"
        "contacts" -> "المتعاملون (موردين/عملاء) 👥"
        "equipment" -> "المعدات والجرارات 🚜"
        "maintenance" -> "صيانة المعدات 🛠️"
        "water" -> "سجل المياه والري 💧"
        "purchases" -> "سجل المشتريات 🛒"
        "sales" -> "سجل المبيعات 💰"
        "treasury" -> "الخزينة والحسابات 💵"
        "debts" -> "الديون والالتزامات 📈"
        else -> name
    }
}

@Composable
fun TablesScreen(viewModel: FarmViewModel) {
    // List of 17 Tables in Farm Management
    val tableOptions = listOf(
        "land" to "الأراضي والقطع 🗺️",
        "crops" to "المحاصيل الزراعية 🌱",
        "operations" to "العمليات وحالة المحاصيل 🚜",
        "inventory" to "المستودع والمخازن 📦",
        "inventory_movement" to "حركات المخزون 🔄",
        "animals" to "الحيوانات والمواشي 🐄",
        "animal_production" to "الإنتاج الحيواني (حليب/بيض) 🥛",
        "workers" to "العمال والموظفين 👨‍🌾",
        "attendance" to "سجل الحضور واليوميات ⏰",
        "contacts" to "المتعاملون (عملاء وموردين) 👥",
        "equipment" to "الآلات والمعدات 🚜",
        "maintenance" to "سجل صيانة المعدات 🛠️",
        "water" to "سجل المياه وتكلفة الري 💧",
        "purchases" to "سجل المشتريات والمدفوعات 🛒",
        "sales" to "سجل المبيعات والإيرادات 💰",
        "treasury" to "الخزينة والحركة المالية 💵",
        "debts" to "الديون والالتزامات 📈"
    )

    val selectedTable by viewModel.selectedTableKey.collectAsStateWithLifecycle()
    val selectedTableTitle by viewModel.selectedTableTitle.collectAsStateWithLifecycle()

    val treasuryBalance by viewModel.treasuryBalance.collectAsStateWithLifecycle()
    val totalOwedToUs by viewModel.totalOwedToUs.collectAsStateWithLifecycle()
    val totalOwedByUs by viewModel.totalOwedByUs.collectAsStateWithLifecycle()
    val alertInventoryCount by viewModel.alertInventoryCount.collectAsStateWithLifecycle()

    if (selectedTable != null) {
        TableDetailScreen(
            tableKey = selectedTable!!,
            title = selectedTableTitle,
            viewModel = viewModel,
            onBack = { viewModel.selectedTableKey.value = null }
        )
    } else {
        Column(modifier = Modifier.fillMaxSize().padding(16.dp)) {
            Text(
                "🗂️ الجداول الحسابية والإدارية",
                fontSize = 18.sp,
                fontWeight = FontWeight.Bold,
                modifier = Modifier.padding(bottom = 4.dp)
            )
            Text(
                "اختر أي سجل من سجلات المزرعة أدناه لعرض وتعديل وإضافة البيانات يدوياً بكل سهولة.",
                fontSize = 12.sp,
                color = Color.Gray,
                modifier = Modifier.padding(bottom = 12.dp)
            )

            // --- 📥 SMART EXCEL WORKBOOK EXPORTER BANNER ---
            Card(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(bottom = 12.dp),
                colors = CardDefaults.cardColors(containerColor = Color(0xFFE8F5E9)), // Soft Excel green tint
                shape = RoundedCornerShape(12.dp),
                border = BorderStroke(1.5.dp, Color(0xFF2E7D32)) // Deep Excel Green
            ) {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(12.dp),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(12.dp)
                ) {
                    Box(
                        modifier = Modifier
                            .background(Color(0xFF2E7D32), CircleShape)
                            .padding(8.dp)
                    ) {
                        Icon(
                            imageVector = Icons.Default.Analytics,
                            contentDescription = null,
                            tint = Color.White,
                            modifier = Modifier.size(24.dp)
                        )
                    }
                    Column(modifier = Modifier.weight(1f)) {
                        Text(
                            text = "📥 تصدير شيت الإكسل الشامل للمزرعة",
                            fontWeight = FontWeight.Bold,
                            fontSize = 13.sp,
                            color = Color(0xFF1B5E20)
                        )
                        Text(
                            text = "تنزيل ملف Excel مدمج يحتوي على كافة الجداول (المخازن، الخزينة، الديون، العمال، المحاصيل) بلمسة واحدة لمشاركتها فوراً.",
                            fontSize = 10.sp,
                            color = Color(0xFF2E7D32),
                            lineHeight = 14.sp
                        )
                    }
                    Button(
                        onClick = { viewModel.exportCompleteFarmDataToCSV() },
                        colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF2E7D32)),
                        contentPadding = PaddingValues(horizontal = 12.dp, vertical = 6.dp),
                        modifier = Modifier.height(36.dp),
                        shape = RoundedCornerShape(8.dp)
                    ) {
                        Text("تحميل الشيت 📊", fontSize = 11.sp, fontWeight = FontWeight.Bold, color = Color.White)
                    }
                }
            }

            // --- 📊 ANALYTICAL REPORTS INSIGHTS HUB ---
            Text(
                "📈 التقارير المالية والتحليلات الفورية",
                fontSize = 13.sp,
                fontWeight = FontWeight.Bold,
                color = MaterialTheme.colorScheme.primary,
                modifier = Modifier.padding(bottom = 8.dp)
            )

            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(bottom = 16.dp)
                    .horizontalScroll(rememberScrollState()),
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                // Card 1: Treasury
                Card(
                    modifier = Modifier
                        .width(150.dp)
                        .clickable {
                            viewModel.selectedTableKey.value = "treasury"
                            viewModel.selectedTableTitle.value = "الخزينة والحركة المالية 💵"
                        },
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.primaryContainer.copy(alpha = 0.4f)),
                    shape = RoundedCornerShape(12.dp)
                ) {
                    Column(modifier = Modifier.padding(10.dp)) {
                        Text("💵 رصيد الخزينة", fontSize = 11.sp, color = MaterialTheme.colorScheme.onPrimaryContainer)
                        Spacer(modifier = Modifier.height(4.dp))
                        Text("${treasuryBalance.toInt()} ج.م", fontSize = 15.sp, fontWeight = FontWeight.Bold, color = MaterialTheme.colorScheme.primary)
                        Spacer(modifier = Modifier.height(6.dp))
                        Text("عرض كشف الحساب ←", fontSize = 9.sp, color = Color.Gray)
                    }
                }

                // Card 2: Inventory
                Card(
                    modifier = Modifier
                        .width(150.dp)
                        .clickable {
                            viewModel.selectedTableKey.value = "inventory"
                            viewModel.selectedTableTitle.value = "المستودع والمخازن 📦"
                        },
                    colors = CardDefaults.cardColors(
                        containerColor = if (alertInventoryCount > 0) Color(0xFFFCE4D6) else MaterialTheme.colorScheme.secondaryContainer.copy(alpha = 0.4f)
                    ),
                    shape = RoundedCornerShape(12.dp)
                ) {
                    Column(modifier = Modifier.padding(10.dp)) {
                        Text("📦 نواقص المستودع", fontSize = 11.sp, color = if (alertInventoryCount > 0) Color(0xFFC00000) else MaterialTheme.colorScheme.onSecondaryContainer)
                        Spacer(modifier = Modifier.height(4.dp))
                        Text(
                            text = if (alertInventoryCount > 0) "$alertInventoryCount أصناف حرجة ⚠️" else "المخزون ممتاز ✅",
                            fontSize = 13.sp,
                            fontWeight = FontWeight.Bold,
                            color = if (alertInventoryCount > 0) Color(0xFFC00000) else Color(0xFF2E7D32)
                        )
                        Spacer(modifier = Modifier.height(6.dp))
                        Text("عرض جرد المخازن ←", fontSize = 9.sp, color = Color.Gray)
                    }
                }

                // Card 3: Debts Owed To Us
                Card(
                    modifier = Modifier
                        .width(150.dp)
                        .clickable {
                            viewModel.selectedTableKey.value = "debts"
                            viewModel.selectedTableTitle.value = "الديون والالتزامات 📈"
                        },
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.tertiaryContainer.copy(alpha = 0.4f)),
                    shape = RoundedCornerShape(12.dp)
                ) {
                    Column(modifier = Modifier.padding(10.dp)) {
                        Text("📈 مستحقاتنا بالخارج", fontSize = 11.sp, color = MaterialTheme.colorScheme.onTertiaryContainer)
                        Spacer(modifier = Modifier.height(4.dp))
                        Text("${totalOwedToUs.toInt()} ج.م", fontSize = 15.sp, fontWeight = FontWeight.Bold, color = MaterialTheme.colorScheme.tertiary)
                        Spacer(modifier = Modifier.height(6.dp))
                        Text("عرض تفاصيل الديون ←", fontSize = 9.sp, color = Color.Gray)
                    }
                }

                // Card 4: Debts Owed By Us
                Card(
                    modifier = Modifier
                        .width(150.dp)
                        .clickable {
                            viewModel.selectedTableKey.value = "debts"
                            viewModel.selectedTableTitle.value = "الديون والالتزامات 📈"
                        },
                    colors = CardDefaults.cardColors(containerColor = Color(0xFFFFF3E0)),
                    shape = RoundedCornerShape(12.dp)
                ) {
                    Column(modifier = Modifier.padding(10.dp)) {
                        Text("📉 التزامات وموردين", fontSize = 11.sp, color = Color(0xFFE65100))
                        Spacer(modifier = Modifier.height(4.dp))
                        Text("${totalOwedByUs.toInt()} ج.م", fontSize = 15.sp, fontWeight = FontWeight.Bold, color = Color(0xFFE65100))
                        Spacer(modifier = Modifier.height(6.dp))
                        Text("عرض كشف الموردين ←", fontSize = 9.sp, color = Color.Gray)
                    }
                }
            }

            Text(
                "📋 كشاف الدفاتر المتاحة للجداول والمدخلات",
                fontSize = 13.sp,
                fontWeight = FontWeight.Bold,
                color = MaterialTheme.colorScheme.primary,
                modifier = Modifier.padding(bottom = 8.dp)
            )

            LazyColumn(
                verticalArrangement = Arrangement.spacedBy(8.dp),
                modifier = Modifier.weight(1.5f)
            ) {
                items(tableOptions.toList()) { (key, label) ->
                    Card(
                        modifier = Modifier
                            .fillMaxWidth()
                            .clickable {
                                viewModel.selectedTableKey.value = key
                                viewModel.selectedTableTitle.value = label
                            }
                            .testTag("table_row_$key"),
                        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)
                    ) {
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(16.dp),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Text(label, fontWeight = FontWeight.SemiBold, fontSize = 15.sp)
                            Icon(Icons.Filled.ArrowBack, contentDescription = null, modifier = Modifier.size(16.dp))
                        }
                    }
                }
            }
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun TableDetailScreen(
    tableKey: String,
    title: String,
    viewModel: FarmViewModel,
    onBack: () -> Unit
) {
    var searchQuery by remember { mutableStateOf("") }
    var showAddDialog by remember { mutableStateOf(false) }

    // Table states
    val lands by viewModel.lands.collectAsStateWithLifecycle()
    val crops by viewModel.crops.collectAsStateWithLifecycle()
    val operations by viewModel.operations.collectAsStateWithLifecycle()
    val inventoryItems by viewModel.inventoryItems.collectAsStateWithLifecycle()
    val inventoryMovements by viewModel.inventoryMovements.collectAsStateWithLifecycle()
    val animals by viewModel.animals.collectAsStateWithLifecycle()
    val animalProd by viewModel.animalProduction.collectAsStateWithLifecycle()
    val workers by viewModel.workers.collectAsStateWithLifecycle()
    val attendance by viewModel.attendance.collectAsStateWithLifecycle()
    val contacts by viewModel.contacts.collectAsStateWithLifecycle()
    val equipment by viewModel.equipment.collectAsStateWithLifecycle()
    val maintenance by viewModel.maintenanceLogs.collectAsStateWithLifecycle()
    val waterLogs by viewModel.waterLogs.collectAsStateWithLifecycle()
    val purchases by viewModel.purchases.collectAsStateWithLifecycle()
    val sales by viewModel.sales.collectAsStateWithLifecycle()
    val treasury by viewModel.treasuryTransactions.collectAsStateWithLifecycle()
    val debts by viewModel.debts.collectAsStateWithLifecycle()

    Column(modifier = Modifier.fillMaxSize()) {
        // Table Bar Header
        TopAppBar(
            title = { Text(title, fontSize = 16.sp, fontWeight = FontWeight.Bold) },
            navigationIcon = {
                IconButton(onClick = onBack) {
                    Icon(Icons.Filled.ArrowBack, contentDescription = "رجوع")
                }
            },
            colors = TopAppBarDefaults.topAppBarColors(containerColor = MaterialTheme.colorScheme.surfaceVariant),
            actions = {
                IconButton(
                    onClick = { showAddDialog = true },
                    modifier = Modifier.testTag("add_item_button")
                ) {
                    Icon(Icons.Default.Add, contentDescription = "إضافة")
                }
            }
        )

        // Search Bar Row
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(8.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            OutlinedTextField(
                value = searchQuery,
                onValueChange = { searchQuery = it },
                placeholder = { Text("ابحث في السجل...") },
                modifier = Modifier
                    .fillMaxWidth()
                    .testTag("table_search_field"),
                shape = RoundedCornerShape(12.dp),
                leadingIcon = { Icon(Icons.Default.Search, contentDescription = null) },
                singleLine = true
            )
        }

        // Display Table Records based on screen tab chosen
        Box(modifier = Modifier.weight(1f).padding(horizontal = 12.dp)) {
            when (tableKey) {
                "land" -> {
                    val filtered = lands.filter { it.name.contains(searchQuery, true) || it.code.contains(searchQuery, true) }
                    LazyColumn(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                        items(filtered) { item ->
                            Card(colors = CardDefaults.cardColors(containerColor = Color.White)) {
                                Column(modifier = Modifier.padding(12.dp)) {
                                    Row(horizontalArrangement = Arrangement.SpaceBetween, modifier = Modifier.fillMaxWidth()) {
                                        Text("${item.name} (${item.code})", fontWeight = FontWeight.Bold)
                                        IconButton(onClick = { viewModel.deleteLandManual(item.code) }, modifier = Modifier.size(24.dp)) {
                                            Icon(Icons.Default.Delete, contentDescription = "حذف", tint = Color.Red, modifier = Modifier.size(18.dp))
                                        }
                                    }
                                    Text("المساحة: ${item.area} ${item.unit} | المنطقة: ${item.region}", fontSize = 13.sp)
                                    if (item.notes.isNotEmpty()) Text("ملاحظات: ${item.notes}", fontSize = 12.sp, color = Color.Gray)
                                }
                            }
                        }
                    }
                }
                "crops" -> {
                    val filtered = crops.filter { it.crop.contains(searchQuery, true) || it.code.contains(searchQuery, true) }
                    LazyColumn(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                        items(filtered) { item ->
                            Card(colors = CardDefaults.cardColors(containerColor = Color.White)) {
                                Column(modifier = Modifier.padding(12.dp)) {
                                    Row(horizontalArrangement = Arrangement.SpaceBetween, modifier = Modifier.fillMaxWidth()) {
                                        Text("${item.crop} (${item.code})", fontWeight = FontWeight.Bold)
                                        IconButton(onClick = { viewModel.deleteCropManual(item.code) }, modifier = Modifier.size(24.dp)) {
                                            Icon(Icons.Default.Delete, contentDescription = "حذف", tint = Color.Red, modifier = Modifier.size(18.dp))
                                        }
                                    }
                                    Text("كود الأرض: ${item.landCode} | الموسم: ${item.season} | مساحة: ${item.area} فدان", fontSize = 13.sp)
                                    Text("المسؤول: ${item.responsible} | النوع: ${item.managementType}", fontSize = 13.sp)
                                    Text("الإنتاج المتوقع: ${item.expectedProduction} طن | الفعلي: ${item.actualProduction} طن", fontSize = 13.sp, color = MaterialTheme.colorScheme.primary)
                                }
                            }
                        }
                    }
                }
                "operations" -> {
                    val filtered = operations.filter { it.operation.contains(searchQuery, true) || it.worker.contains(searchQuery, true) }
                    LazyColumn(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                        items(filtered) { item ->
                            Card(colors = CardDefaults.cardColors(containerColor = Color.White)) {
                                Column(modifier = Modifier.padding(12.dp)) {
                                    Row(horizontalArrangement = Arrangement.SpaceBetween, modifier = Modifier.fillMaxWidth()) {
                                        Text(item.operation, fontWeight = FontWeight.Bold)
                                        IconButton(onClick = { viewModel.deleteOperationManual(item) }, modifier = Modifier.size(24.dp)) {
                                            Icon(Icons.Default.Delete, contentDescription = "حذف", tint = Color.Red, modifier = Modifier.size(18.dp))
                                        }
                                    }
                                    Text("كود المحصول: ${item.cropCode} | القائم بالعمل: ${item.worker} | تاريخ: ${item.date}", fontSize = 13.sp)
                                    Text("التكلفة: ${item.cost} ج.م", fontSize = 13.sp, fontWeight = FontWeight.Bold, color = Color(0xFFC0392B))
                                    if (item.notes.isNotEmpty()) Text("ملاحظات: ${item.notes}", fontSize = 12.sp, color = Color.Gray)
                                }
                            }
                        }
                    }
                }
                "inventory" -> {
                    val filtered = inventoryItems.filter { it.item.contains(searchQuery, true) || it.category.contains(searchQuery, true) }
                    LazyColumn(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                        items(filtered) { item ->
                            val isLow = item.currentBalance < item.minimumLevel
                            Card(colors = CardDefaults.cardColors(containerColor = if (isLow) Color(0xFFFDF2E9) else Color.White)) {
                                Column(modifier = Modifier.padding(12.dp)) {
                                    Row(horizontalArrangement = Arrangement.SpaceBetween, modifier = Modifier.fillMaxWidth()) {
                                        Text("${item.item} (${item.code})", fontWeight = FontWeight.Bold)
                                        IconButton(onClick = { viewModel.deleteInventoryManual(item.code) }, modifier = Modifier.size(24.dp)) {
                                            Icon(Icons.Default.Delete, contentDescription = "حذف", tint = Color.Red, modifier = Modifier.size(18.dp))
                                        }
                                    }
                                    Text("التصنيف: ${item.category} | الرصيد الحالي: ${item.currentBalance} ${item.unit}", fontSize = 13.sp)
                                    Text("الرصيد الافتتاحي: ${item.openingBalance} ${item.unit} | حد الأمان: ${item.minimumLevel} ${item.unit}", fontSize = 13.sp)
                                    if (isLow) {
                                        Text("⚠️ الرصيد الحالي أقل من حد الأمان!", color = Color(0xFFD35400), fontSize = 12.sp, fontWeight = FontWeight.Bold)
                                    }
                                }
                            }
                        }
                    }
                }
                "inventory_movement" -> {
                    val filtered = inventoryMovements.filter { it.itemCode.contains(searchQuery, true) || it.movementType.contains(searchQuery, true) }
                    LazyColumn(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                        items(filtered) { item ->
                            Card(colors = CardDefaults.cardColors(containerColor = Color.White)) {
                                Column(modifier = Modifier.padding(12.dp)) {
                                    Row(horizontalArrangement = Arrangement.SpaceBetween, modifier = Modifier.fillMaxWidth()) {
                                        Text("كود الصنف: ${item.itemCode} [${item.movementType}]", fontWeight = FontWeight.Bold, color = if (item.movementType == "وارد") MaterialTheme.colorScheme.primary else Color(0xFFC0392B))
                                        IconButton(onClick = { viewModel.deleteInventoryMovementManual(item) }, modifier = Modifier.size(24.dp)) {
                                            Icon(Icons.Default.Delete, contentDescription = "حذف", tint = Color.Red, modifier = Modifier.size(18.dp))
                                        }
                                    }
                                    Text("الكمية: ${item.quantity} | تاريخ: ${item.date}", fontSize = 13.sp)
                                    Text("من: ${item.fromLocation} | إلى: ${item.toLocation} | كود المحصول: ${item.cropCode}", fontSize = 13.sp)
                                    Text("التكلفة الكلية: ${item.cost} ج.م", fontSize = 13.sp, fontWeight = FontWeight.Bold)
                                }
                            }
                        }
                    }
                }
                "animals" -> {
                    val filtered = animals.filter { it.type.contains(searchQuery, true) || it.purpose.contains(searchQuery, true) }
                    LazyColumn(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                        items(filtered) { item ->
                            Card(colors = CardDefaults.cardColors(containerColor = Color.White)) {
                                Column(modifier = Modifier.padding(12.dp)) {
                                    Row(horizontalArrangement = Arrangement.SpaceBetween, modifier = Modifier.fillMaxWidth()) {
                                        Text("${item.type} (${item.code})", fontWeight = FontWeight.Bold)
                                        IconButton(onClick = { viewModel.deleteAnimalManual(item.code) }, modifier = Modifier.size(24.dp)) {
                                            Icon(Icons.Default.Delete, contentDescription = "حذف", tint = Color.Red, modifier = Modifier.size(18.dp))
                                        }
                                    }
                                    Text("العدد الحقيقي: ${item.count} رأس | الغرض: ${item.purpose}", fontSize = 13.sp)
                                    Text("الموقع بالحظيرة: ${item.location} | القيمة المالية: ${item.value} ج.م", fontSize = 13.sp)
                                }
                            }
                        }
                    }
                }
                "animal_production" -> {
                    val filtered = animalProd.filter { it.animalType.contains(searchQuery, true) }
                    LazyColumn(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                        items(filtered) { item ->
                            Card(colors = CardDefaults.cardColors(containerColor = Color.White)) {
                                Column(modifier = Modifier.padding(12.dp)) {
                                    Row(horizontalArrangement = Arrangement.SpaceBetween, modifier = Modifier.fillMaxWidth()) {
                                        Text(item.animalType, fontWeight = FontWeight.Bold)
                                        IconButton(onClick = { viewModel.deleteAnimalProductionManual(item) }, modifier = Modifier.size(24.dp)) {
                                            Icon(Icons.Default.Delete, contentDescription = "حذف", tint = Color.Red, modifier = Modifier.size(18.dp))
                                        }
                                    }
                                    Text("الكمية المنتجة: ${item.quantity} ${item.unit} | تاريخ: ${item.date}", fontSize = 13.sp)
                                    Text("الإيرادات المحققة: ${item.revenue} ج.م", fontSize = 13.sp, fontWeight = FontWeight.Bold, color = MaterialTheme.colorScheme.primary)
                                }
                            }
                        }
                    }
                }
                "workers" -> {
                    val filtered = workers.filter { it.name.contains(searchQuery, true) || it.job.contains(searchQuery, true) }
                    LazyColumn(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                        items(filtered) { item ->
                            Card(colors = CardDefaults.cardColors(containerColor = Color.White)) {
                                Column(modifier = Modifier.padding(12.dp)) {
                                    Row(horizontalArrangement = Arrangement.SpaceBetween, modifier = Modifier.fillMaxWidth()) {
                                        Text("${item.name} (${item.code})", fontWeight = FontWeight.Bold)
                                        IconButton(onClick = { viewModel.deleteWorkerManual(item.code) }, modifier = Modifier.size(24.dp)) {
                                            Icon(Icons.Default.Delete, contentDescription = "حذف", tint = Color.Red, modifier = Modifier.size(18.dp))
                                        }
                                    }
                                    Text("الوظيفة: ${item.job} | رقم الهاتف: ${item.phone}", fontSize = 13.sp)
                                    Text("الراتب الشهري: ${item.salary} ج.م", fontSize = 13.sp, fontWeight = FontWeight.Bold, color = MaterialTheme.colorScheme.primary)
                                }
                            }
                        }
                    }
                }
                "attendance" -> {
                    val filtered = attendance.filter { it.workerCode.contains(searchQuery, true) || it.task.contains(searchQuery, true) }
                    LazyColumn(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                        items(filtered) { item ->
                            Card(colors = CardDefaults.cardColors(containerColor = Color.White)) {
                                Column(modifier = Modifier.padding(12.dp)) {
                                    Row(horizontalArrangement = Arrangement.SpaceBetween, modifier = Modifier.fillMaxWidth()) {
                                        Text("كود العامل: ${item.workerCode}", fontWeight = FontWeight.Bold)
                                        IconButton(onClick = { viewModel.deleteAttendanceManual(item) }, modifier = Modifier.size(24.dp)) {
                                            Icon(Icons.Default.Delete, contentDescription = "حذف", tint = Color.Red, modifier = Modifier.size(18.dp))
                                        }
                                    }
                                    Text("المهمة: ${item.task} | الموقع: ${item.location} | تاريخ: ${item.date}", fontSize = 13.sp)
                                    Text("عدد الساعات: ${item.hours} ساعة | الأجر اليومي: ${item.wage} ج.م", fontSize = 13.sp)
                                }
                            }
                        }
                    }
                }
                "contacts" -> {
                    val filtered = contacts.filter { it.name.contains(searchQuery, true) || it.type.contains(searchQuery, true) }
                    LazyColumn(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                        items(filtered) { item ->
                            Card(colors = CardDefaults.cardColors(containerColor = Color.White)) {
                                Column(modifier = Modifier.padding(12.dp)) {
                                    Row(horizontalArrangement = Arrangement.SpaceBetween, modifier = Modifier.fillMaxWidth()) {
                                        Text("${item.name} (${item.code}) - [${item.type}]", fontWeight = FontWeight.Bold)
                                        IconButton(onClick = { viewModel.deleteContactManual(item.code) }, modifier = Modifier.size(24.dp)) {
                                            Icon(Icons.Default.Delete, contentDescription = "حذف", tint = Color.Red, modifier = Modifier.size(18.dp))
                                        }
                                    }
                                    Text("الهاتف: ${item.phone}", fontSize = 13.sp)
                                    Text("الحساب الحالي: ${item.balance} ج.م", fontSize = 13.sp, fontWeight = FontWeight.Bold, color = if (item.balance >= 0) MaterialTheme.colorScheme.primary else Color.Red)
                                }
                            }
                        }
                    }
                }
                "equipment" -> {
                    val filtered = equipment.filter { it.name.contains(searchQuery, true) || it.category.contains(searchQuery, true) }
                    LazyColumn(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                        items(filtered) { item ->
                            Card(colors = CardDefaults.cardColors(containerColor = Color.White)) {
                                Column(modifier = Modifier.padding(12.dp)) {
                                    Row(horizontalArrangement = Arrangement.SpaceBetween, modifier = Modifier.fillMaxWidth()) {
                                        Text("${item.name} (${item.code})", fontWeight = FontWeight.Bold)
                                        IconButton(onClick = { viewModel.deleteEquipmentManual(item.code) }, modifier = Modifier.size(24.dp)) {
                                            Icon(Icons.Default.Delete, contentDescription = "حذف", tint = Color.Red, modifier = Modifier.size(18.dp))
                                        }
                                    }
                                    Text("التصنيف: ${item.category} | ساعات التشغيل: ${item.operatingHours} ساعة", fontSize = 13.sp)
                                    Text("تاريخ الشراء: ${item.purchaseDate} | القيمة المالية: ${item.value} ج.م", fontSize = 13.sp)
                                }
                            }
                        }
                    }
                }
                "maintenance" -> {
                    val filtered = maintenance.filter { it.equipmentCode.contains(searchQuery, true) || it.description.contains(searchQuery, true) }
                    LazyColumn(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                        items(filtered) { item ->
                            Card(colors = CardDefaults.cardColors(containerColor = Color.White)) {
                                Column(modifier = Modifier.padding(12.dp)) {
                                    Row(horizontalArrangement = Arrangement.SpaceBetween, modifier = Modifier.fillMaxWidth()) {
                                        Text("كود المعدة: ${item.equipmentCode}", fontWeight = FontWeight.Bold)
                                        IconButton(onClick = { viewModel.deleteMaintenanceManual(item) }, modifier = Modifier.size(24.dp)) {
                                            Icon(Icons.Default.Delete, contentDescription = "حذف", tint = Color.Red, modifier = Modifier.size(18.dp))
                                        }
                                    }
                                    Text("تفاصيل الصيانة: ${item.description} | تاريخ: ${item.date}", fontSize = 13.sp)
                                    Text("تكلفة الصيانة: ${item.cost} ج.م", fontSize = 13.sp, fontWeight = FontWeight.Bold, color = Color(0xFFC0392B))
                                }
                            }
                        }
                    }
                }
                "water" -> {
                    val filtered = waterLogs.filter { it.source.contains(searchQuery, true) }
                    LazyColumn(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                        items(filtered) { item ->
                            Card(colors = CardDefaults.cardColors(containerColor = Color.White)) {
                                Column(modifier = Modifier.padding(12.dp)) {
                                    Row(horizontalArrangement = Arrangement.SpaceBetween, modifier = Modifier.fillMaxWidth()) {
                                        Text("مصدر المياه: ${item.source}", fontWeight = FontWeight.Bold)
                                        IconButton(onClick = { viewModel.deleteWaterManual(item) }, modifier = Modifier.size(24.dp)) {
                                            Icon(Icons.Default.Delete, contentDescription = "حذف", tint = Color.Red, modifier = Modifier.size(18.dp))
                                        }
                                    }
                                    Text("ساعات التشغيل: ${item.operatingHours} ساعة | تاريخ: ${item.date}", fontSize = 13.sp)
                                    Text("كود المحصول: ${item.cropCode} | التكلفة: ${item.cost} ج.م", fontSize = 13.sp, fontWeight = FontWeight.Bold)
                                }
                            }
                        }
                    }
                }
                "purchases" -> {
                    val filtered = purchases.filter { it.supplier.contains(searchQuery, true) || it.item.contains(searchQuery, true) }
                    LazyColumn(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                        items(filtered) { item ->
                            Card(colors = CardDefaults.cardColors(containerColor = Color.White)) {
                                Column(modifier = Modifier.padding(12.dp)) {
                                    Row(horizontalArrangement = Arrangement.SpaceBetween, modifier = Modifier.fillMaxWidth()) {
                                        Text("شراء ${item.item}", fontWeight = FontWeight.Bold)
                                        IconButton(onClick = { viewModel.deletePurchaseManual(item) }, modifier = Modifier.size(24.dp)) {
                                            Icon(Icons.Default.Delete, contentDescription = "حذف", tint = Color.Red, modifier = Modifier.size(18.dp))
                                        }
                                    }
                                    Text("المورد: ${item.supplier} | الكمية: ${item.quantity} | تاريخ: ${item.date}", fontSize = 13.sp)
                                    Text("التكلفة الإجمالية: ${item.price} ج.م", fontSize = 13.sp, fontWeight = FontWeight.Bold, color = Color(0xFFC0392B))
                                }
                            }
                        }
                    }
                }
                "sales" -> {
                    val filtered = sales.filter { it.customer.contains(searchQuery, true) || it.product.contains(searchQuery, true) }
                    LazyColumn(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                        items(filtered) { item ->
                            Card(colors = CardDefaults.cardColors(containerColor = Color.White)) {
                                Column(modifier = Modifier.padding(12.dp)) {
                                    Row(horizontalArrangement = Arrangement.SpaceBetween, modifier = Modifier.fillMaxWidth()) {
                                        Text("بيع ${item.product}", fontWeight = FontWeight.Bold)
                                        IconButton(onClick = { viewModel.deleteSaleManual(item) }, modifier = Modifier.size(24.dp)) {
                                            Icon(Icons.Default.Delete, contentDescription = "حذف", tint = Color.Red, modifier = Modifier.size(18.dp))
                                        }
                                    }
                                    Text("العميل: ${item.customer} | الكمية: ${item.quantity} | تاريخ: ${item.date}", fontSize = 13.sp)
                                    Text("سعر بيع الوحدة: ${item.price} ج.م | الإجمالي: ${item.quantity * item.price} ج.م", fontSize = 13.sp, fontWeight = FontWeight.Bold, color = MaterialTheme.colorScheme.primary)
                                }
                            }
                        }
                    }
                }
                "treasury" -> {
                    val filtered = treasury.filter { it.reason.contains(searchQuery, true) || it.party.contains(searchQuery, true) }
                    LazyColumn(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                        items(filtered) { item ->
                            val isDeposit = item.movementType == "إيداع"
                            Card(colors = CardDefaults.cardColors(containerColor = Color.White)) {
                                Column(modifier = Modifier.padding(12.dp)) {
                                    Row(horizontalArrangement = Arrangement.SpaceBetween, modifier = Modifier.fillMaxWidth()) {
                                        Text(item.reason, fontWeight = FontWeight.Bold)
                                        IconButton(onClick = { viewModel.deleteTreasuryManual(item) }, modifier = Modifier.size(24.dp)) {
                                            Icon(Icons.Default.Delete, contentDescription = "حذف", tint = Color.Red, modifier = Modifier.size(18.dp))
                                        }
                                    }
                                    Text("نوع الحركة: ${item.movementType} | الطرف الآخر: ${item.party} | تاريخ: ${item.date}", fontSize = 13.sp)
                                    Text("القيمة المالية: ${item.value} ج.م", fontSize = 14.sp, fontWeight = FontWeight.Bold, color = if (isDeposit) MaterialTheme.colorScheme.primary else Color(0xFFC0392B))
                                }
                            }
                        }
                    }
                }
                "debts" -> {
                    val filtered = debts.filter { it.party.contains(searchQuery, true) }
                    LazyColumn(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                        items(filtered) { item ->
                            Card(colors = CardDefaults.cardColors(containerColor = Color.White)) {
                                Column(modifier = Modifier.padding(12.dp)) {
                                    Row(horizontalArrangement = Arrangement.SpaceBetween, modifier = Modifier.fillMaxWidth()) {
                                        Text("طرف الدين: ${item.party}", fontWeight = FontWeight.Bold)
                                        IconButton(onClick = { viewModel.deleteDebtManual(item) }, modifier = Modifier.size(24.dp)) {
                                            Icon(Icons.Default.Delete, contentDescription = "حذف", tint = Color.Red, modifier = Modifier.size(18.dp))
                                        }
                                    }
                                    Text("مستحق لنا بالخارج: ${item.owedToUs} ج.م | مستحق علينا لغيرنا: ${item.owedByUs} ج.م", fontSize = 13.sp)
                                    Text("تاريخ الاستحقاق: ${item.dueDate} | حالة الدين: ${item.status}", fontSize = 13.sp, fontWeight = FontWeight.Bold, color = if (item.status == "نشط") Color(0xFFD35400) else Color.Gray)
                                }
                            }
                        }
                    }
                }
            }
        }
    }

    if (showAddDialog) {
        TableAddRecordDialog(
            tableKey = tableKey,
            onDismiss = { showAddDialog = false },
            viewModel = viewModel
        )
    }
}

@Composable
fun TableAddRecordDialog(
    tableKey: String,
    onDismiss: () -> Unit,
    viewModel: FarmViewModel
) {
    val todayDate = java.text.SimpleDateFormat("yyyy-MM-dd", java.util.Locale.getDefault()).format(java.util.Date())

    // Generically manage state form values using keys
    val formData = remember { mutableStateMapOf<String, String>() }

    Dialog(onDismissRequest = onDismiss) {
        Card(
            shape = RoundedCornerShape(16.dp),
            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
            modifier = Modifier
                .fillMaxWidth()
                .padding(16.dp)
        ) {
            Column(
                modifier = Modifier
                    .padding(16.dp)
                    .verticalScroll(rememberScrollState()),
                verticalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                Text(
                    "📝 إضافة سجل جديد في جدول: ${translateTableName(tableKey)}",
                    fontWeight = FontWeight.Bold,
                    fontSize = 16.sp,
                    modifier = Modifier.fillMaxWidth(),
                    textAlign = TextAlign.Center
                )
                Spacer(modifier = Modifier.height(4.dp))

                // Render dynamic fields based on table key
                when (tableKey) {
                    "land" -> {
                        FormTextField(label = "كود الأرض (مثل: L003)", key = "code", data = formData)
                        FormTextField(label = "اسم قطعة الأرض", key = "name", data = formData)
                        FormTextField(label = "المساحة (رقم)", key = "area", data = formData, isNumber = true)
                        FormTextField(label = "الوحدة (فدان / متر)", key = "unit", data = formData)
                        FormTextField(label = "المنطقة الجغرافية", key = "region", data = formData)
                        FormTextField(label = "ملاحظات إضافية", key = "notes", data = formData)
                    }
                    "crops" -> {
                        FormTextField(label = "كود المحصول (Cxxx)", key = "code", data = formData)
                        FormTextField(label = "كود الأرض المزروع بها", key = "landCode", data = formData)
                        FormTextField(label = "اسم المحصول (مثل: قمح)", key = "crop", data = formData)
                        FormTextField(label = "الموسم (صيفي/شتوي)", key = "season", data = formData)
                        FormTextField(label = "المساحة المزروعة (فدان)", key = "area", data = formData, isNumber = true)
                        FormTextField(label = "نوع الإدارة (عضوي/تقليدي)", key = "managementType", data = formData)
                        FormTextField(label = "الشخص المسؤول", key = "responsible", data = formData)
                        FormTextField(label = "الإنتاج المتوقع بالطن", key = "expectedProduction", data = formData, isNumber = true)
                        FormTextField(label = "الإنتاج الفعلي بالطن", key = "actualProduction", data = formData, isNumber = true)
                    }
                    "operations" -> {
                        FormTextField(label = "التاريخ (YYYY-MM-DD)", key = "date", data = formData, initial = todayDate)
                        FormTextField(label = "كود المحصول", key = "cropCode", data = formData)
                        FormTextField(label = "اسم العملية (ري/تسميد/حصاد)", key = "operation", data = formData)
                        FormTextField(label = "العامل القائم بالعملية", key = "worker", data = formData)
                        FormTextField(label = "التكلفة المالية (ج.م)", key = "cost", data = formData, isNumber = true)
                        FormTextField(label = "ملاحظات", key = "notes", data = formData)
                    }
                    "inventory" -> {
                        FormTextField(label = "كود الصنف بالمخزن (INVxxx)", key = "code", data = formData)
                        FormTextField(label = "اسم الصنف (أسمدة/أعلاف/أدوية)", key = "item", data = formData)
                        FormTextField(label = "التصنيف والنوع", key = "category", data = formData)
                        FormTextField(label = "وحدة القياس (طن/كيس/لتر)", key = "unit", data = formData)
                        FormTextField(label = "الرصيد الافتتاحي (رقم)", key = "openingBalance", data = formData, isNumber = true)
                        FormTextField(label = "الرصيد الحالي (رقم)", key = "currentBalance", data = formData, isNumber = true)
                        FormTextField(label = "حد الأمان للأقراص", key = "minimumLevel", data = formData, isNumber = true)
                    }
                    "inventory_movement" -> {
                        FormTextField(label = "التاريخ", key = "date", data = formData, initial = todayDate)
                        FormTextField(label = "كود الصنف بالمخزن", key = "itemCode", data = formData)
                        FormTextField(label = "نوع الحركة (وارد / صادر)", key = "movementType", data = formData)
                        FormTextField(label = "الكمية والحركة", key = "quantity", data = formData, isNumber = true)
                        FormTextField(label = "من موقع", key = "fromLocation", data = formData)
                        FormTextField(label = "إلى موقع", key = "toLocation", data = formData)
                        FormTextField(label = "كود المحصول المرتبط", key = "cropCode", data = formData)
                        FormTextField(label = "التكلفة المالية (ج.م)", key = "cost", data = formData, isNumber = true)
                    }
                    "animals" -> {
                        FormTextField(label = "كود الحيوان (Axxx)", key = "code", data = formData)
                        FormTextField(label = "نوع الحيوان (أبقار/أغنام/ماعز)", key = "type", data = formData)
                        FormTextField(label = "العدد الحالي (رأس)", key = "count", data = formData, isNumber = true)
                        FormTextField(label = "الغرض (لحم/حليب/بيض)", key = "purpose", data = formData)
                        FormTextField(label = "الموقع بالحظيرة", key = "location", data = formData)
                        FormTextField(label = "القيمة المالية الكلية", key = "value", data = formData, isNumber = true)
                    }
                    "animal_production" -> {
                        FormTextField(label = "التاريخ", key = "date", data = formData, initial = todayDate)
                        FormTextField(label = "نوع الحيوان المنتج", key = "animalType", data = formData)
                        FormTextField(label = "الكمية والإنتاج", key = "quantity", data = formData, isNumber = true)
                        FormTextField(label = "الوحدة (لتر/طبق)", key = "unit", data = formData)
                        FormTextField(label = "الإيرادات المحققة (ج.م)", key = "revenue", data = formData, isNumber = true)
                    }
                    "workers" -> {
                        FormTextField(label = "كود العامل (Wxxx)", key = "code", data = formData)
                        FormTextField(label = "اسم العامل بالكامل", key = "name", data = formData)
                        FormTextField(label = "الوظيفة والمسؤولية", key = "job", data = formData)
                        FormTextField(label = "رقم الهاتف", key = "phone", data = formData)
                        FormTextField(label = "الراتب الشهري (ج.م)", key = "salary", data = formData, isNumber = true)
                    }
                    "attendance" -> {
                        FormTextField(label = "التاريخ", key = "date", data = formData, initial = todayDate)
                        FormTextField(label = "كود العامل (Wxxx)", key = "workerCode", data = formData)
                        FormTextField(label = "المهمة الموكلة إليه", key = "task", data = formData)
                        FormTextField(label = "موقع العمل بالقطعة", key = "location", data = formData)
                        FormTextField(label = "ساعات العمل المنجزة", key = "hours", data = formData, isNumber = true)
                        FormTextField(label = "الأجر اليومي المالي", key = "wage", data = formData, isNumber = true)
                    }
                    "contacts" -> {
                        FormTextField(label = "كود المتعامل (CTxxx)", key = "code", data = formData)
                        FormTextField(label = "اسم العميل أو المورد", key = "name", data = formData)
                        FormTextField(label = "النوع (عميل / مورد)", key = "type", data = formData)
                        FormTextField(label = "رقم الهاتف", key = "phone", data = formData)
                        FormTextField(label = "الحساب المالي الابتدائي", key = "balance", data = formData, isNumber = true)
                    }
                    "equipment" -> {
                        FormTextField(label = "كود المعدة (Exxx)", key = "code", data = formData)
                        FormTextField(label = "اسم المعدة أو الجرار", key = "name", data = formData)
                        FormTextField(label = "التصنيف", key = "category", data = formData)
                        FormTextField(label = "تاريخ الشراء", key = "purchaseDate", data = formData, initial = todayDate)
                        FormTextField(label = "القيمة المالية للآلة", key = "value", data = formData, isNumber = true)
                        FormTextField(label = "ساعات العمل الكلية", key = "operatingHours", data = formData, isNumber = true)
                    }
                    "maintenance" -> {
                        FormTextField(label = "التاريخ", key = "date", data = formData, initial = todayDate)
                        FormTextField(label = "كود الآلة أو المعدة", key = "equipmentCode", data = formData)
                        FormTextField(label = "وصف الصيانة والتصليح", key = "description", data = formData)
                        FormTextField(label = "التكلفة المالية (ج.م)", key = "cost", data = formData, isNumber = true)
                    }
                    "water" -> {
                        FormTextField(label = "التاريخ", key = "date", data = formData, initial = todayDate)
                        FormTextField(label = "مصدر مياه الري", key = "source", data = formData)
                        FormTextField(label = "ساعات تشغيل الطلمبة", key = "operatingHours", data = formData, isNumber = true)
                        FormTextField(label = "تكلفة الري (سولار/كهرباء)", key = "cost", data = formData, isNumber = true)
                        FormTextField(label = "كود المحصول المروي", key = "cropCode", data = formData)
                    }
                    "purchases" -> {
                        FormTextField(label = "التاريخ", key = "date", data = formData, initial = todayDate)
                        FormTextField(label = "اسم المورد والشركة", key = "supplier", data = formData)
                        FormTextField(label = "اسم المادة المشتراة", key = "item", data = formData)
                        FormTextField(label = "الكمية المشتراة", key = "quantity", data = formData, isNumber = true)
                        FormTextField(label = "التكلفة الإجمالية (ج.م)", key = "price", data = formData, isNumber = true)
                    }
                    "sales" -> {
                        FormTextField(label = "التاريخ", key = "date", data = formData, initial = todayDate)
                        FormTextField(label = "اسم العميل والتاجر", key = "customer", data = formData)
                        FormTextField(label = "المنتج المباع والسلعة", key = "product", data = formData)
                        FormTextField(label = "الكمية والطن", key = "quantity", data = formData, isNumber = true)
                        FormTextField(label = "سعر الوحدة المالية", key = "price", data = formData, isNumber = true)
                    }
                    "treasury" -> {
                        FormTextField(label = "التاريخ", key = "date", data = formData, initial = todayDate)
                        FormTextField(label = "نوع الحركة المالي (إيداع / صرف)", key = "movementType", data = formData)
                        FormTextField(label = "المبلغ المالي (ج.م)", key = "value", data = formData, isNumber = true)
                        FormTextField(label = "سبب الحركة والتفاصيل", key = "reason", data = formData)
                        FormTextField(label = "الشخص والطرف المقابل", key = "party", data = formData)
                    }
                    "debts" -> {
                        FormTextField(label = "اسم الطرف والتاجر", key = "party", data = formData)
                        FormTextField(label = "مستحق لنا بالخارج (رقم)", key = "owedToUs", data = formData, isNumber = true)
                        FormTextField(label = "مستحق علينا للغير (رقم)", key = "owedByUs", data = formData, isNumber = true)
                        FormTextField(label = "تاريخ السداد المحدد", key = "dueDate", data = formData, initial = todayDate)
                        FormTextField(label = "حالة الدين (نشط / مسدد)", key = "status", data = formData, initial = "نشط")
                    }
                }

                Spacer(modifier = Modifier.height(10.dp))
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    Button(
                        onClick = {
                            // Validate and insert
                            when (tableKey) {
                                "land" -> {
                                    viewModel.addLandManual(
                                        Land(
                                            code = formData["code"] ?: "",
                                            name = formData["name"] ?: "",
                                            area = formData["area"]?.toDoubleOrNull() ?: 0.0,
                                            unit = formData["unit"] ?: "فدان",
                                            region = formData["region"] ?: "عام",
                                            notes = formData["notes"] ?: ""
                                        )
                                    )
                                }
                                "crops" -> {
                                    viewModel.addCropManual(
                                        Crop(
                                            code = formData["code"] ?: "",
                                            landCode = formData["landCode"] ?: "L001",
                                            crop = formData["crop"] ?: "",
                                            season = formData["season"] ?: "",
                                            area = formData["area"]?.toDoubleOrNull() ?: 1.0,
                                            managementType = formData["managementType"] ?: "تقليدي",
                                            responsible = formData["responsible"] ?: "",
                                            expectedProduction = formData["expectedProduction"]?.toDoubleOrNull() ?: 0.0,
                                            actualProduction = formData["actualProduction"]?.toDoubleOrNull() ?: 0.0
                                        )
                                    )
                                }
                                "operations" -> {
                                    viewModel.addOperationManual(
                                        Operation(
                                            date = formData["date"] ?: todayDate,
                                            cropCode = formData["cropCode"] ?: "C001",
                                            operation = formData["operation"] ?: "",
                                            worker = formData["worker"] ?: "",
                                            cost = formData["cost"]?.toDoubleOrNull() ?: 0.0,
                                            notes = formData["notes"] ?: ""
                                        )
                                    )
                                }
                                "inventory" -> {
                                    viewModel.addInventoryManual(
                                        InventoryItem(
                                            code = formData["code"] ?: "",
                                            item = formData["item"] ?: "",
                                            category = formData["category"] ?: "",
                                            unit = formData["unit"] ?: "",
                                            openingBalance = formData["openingBalance"]?.toDoubleOrNull() ?: 0.0,
                                            currentBalance = formData["currentBalance"]?.toDoubleOrNull() ?: 0.0,
                                            minimumLevel = formData["minimumLevel"]?.toDoubleOrNull() ?: 0.0
                                        )
                                    )
                                }
                                "inventory_movement" -> {
                                    viewModel.addInventoryMovementManual(
                                        InventoryMovement(
                                            date = formData["date"] ?: todayDate,
                                            itemCode = formData["itemCode"] ?: "",
                                            movementType = formData["movementType"] ?: "وارد",
                                            quantity = formData["quantity"]?.toDoubleOrNull() ?: 0.0,
                                            fromLocation = formData["fromLocation"] ?: "",
                                            toLocation = formData["toLocation"] ?: "",
                                            cropCode = formData["cropCode"] ?: "",
                                            cost = formData["cost"]?.toDoubleOrNull() ?: 0.0
                                        )
                                    )
                                }
                                "animals" -> {
                                    viewModel.addAnimalManual(
                                        Animal(
                                            code = formData["code"] ?: "",
                                            type = formData["type"] ?: "",
                                            count = formData["count"]?.toIntOrNull() ?: 1,
                                            purpose = formData["purpose"] ?: "لحم",
                                            location = formData["location"] ?: "الحظيرة",
                                            value = formData["value"]?.toDoubleOrNull() ?: 0.0
                                        )
                                    )
                                }
                                "animal_production" -> {
                                    viewModel.addAnimalProductionManual(
                                        AnimalProduction(
                                            date = formData["date"] ?: todayDate,
                                            animalType = formData["animalType"] ?: "",
                                            quantity = formData["quantity"]?.toDoubleOrNull() ?: 0.0,
                                            unit = formData["unit"] ?: "لتر",
                                            revenue = formData["revenue"]?.toDoubleOrNull() ?: 0.0
                                        )
                                    )
                                }
                                "workers" -> {
                                    viewModel.addWorkerManual(
                                        Worker(
                                            code = formData["code"] ?: "",
                                            name = formData["name"] ?: "",
                                            job = formData["job"] ?: "",
                                            phone = formData["phone"] ?: "",
                                            salary = formData["salary"]?.toDoubleOrNull() ?: 0.0
                                        )
                                    )
                                }
                                "attendance" -> {
                                    viewModel.addAttendanceManual(
                                        Attendance(
                                            date = formData["date"] ?: todayDate,
                                            workerCode = formData["workerCode"] ?: "",
                                            task = formData["task"] ?: "",
                                            location = formData["location"] ?: "",
                                            hours = formData["hours"]?.toDoubleOrNull() ?: 8.0,
                                            wage = formData["wage"]?.toDoubleOrNull() ?: 0.0
                                        )
                                    )
                                }
                                "contacts" -> {
                                    viewModel.addContactManual(
                                        Contact(
                                            code = formData["code"] ?: "",
                                            name = formData["name"] ?: "",
                                            type = formData["type"] ?: "عميل",
                                            phone = formData["phone"] ?: "",
                                            balance = formData["balance"]?.toDoubleOrNull() ?: 0.0
                                        )
                                    )
                                }
                                "equipment" -> {
                                    viewModel.addEquipmentManual(
                                        Equipment(
                                            code = formData["code"] ?: "",
                                            name = formData["name"] ?: "",
                                            category = formData["category"] ?: "",
                                            purchaseDate = formData["purchaseDate"] ?: todayDate,
                                            value = formData["value"]?.toDoubleOrNull() ?: 0.0,
                                            operatingHours = formData["operatingHours"]?.toDoubleOrNull() ?: 0.0
                                        )
                                    )
                                }
                                "maintenance" -> {
                                    viewModel.addMaintenanceManual(
                                        Maintenance(
                                            date = formData["date"] ?: todayDate,
                                            equipmentCode = formData["equipmentCode"] ?: "",
                                            description = formData["description"] ?: "",
                                            cost = formData["cost"]?.toDoubleOrNull() ?: 0.0
                                        )
                                    )
                                }
                                "water" -> {
                                    viewModel.addWaterManual(
                                        WaterLog(
                                            date = formData["date"] ?: todayDate,
                                            source = formData["source"] ?: "بئر",
                                            operatingHours = formData["operatingHours"]?.toDoubleOrNull() ?: 0.0,
                                            cost = formData["cost"]?.toDoubleOrNull() ?: 0.0,
                                            cropCode = formData["cropCode"] ?: ""
                                        )
                                    )
                                }
                                "purchases" -> {
                                    viewModel.addPurchaseManual(
                                        Purchase(
                                            date = formData["date"] ?: todayDate,
                                            supplier = formData["supplier"] ?: "",
                                            item = formData["item"] ?: "",
                                            quantity = formData["quantity"]?.toDoubleOrNull() ?: 1.0,
                                            price = formData["price"]?.toDoubleOrNull() ?: 0.0
                                        )
                                    )
                                }
                                "sales" -> {
                                    viewModel.addSaleManual(
                                        Sale(
                                            date = formData["date"] ?: todayDate,
                                            customer = formData["customer"] ?: "",
                                            product = formData["product"] ?: "",
                                            quantity = formData["quantity"]?.toDoubleOrNull() ?: 1.0,
                                            price = formData["price"]?.toDoubleOrNull() ?: 0.0
                                        )
                                    )
                                }
                                "treasury" -> {
                                    viewModel.addTreasuryManual(
                                        TreasuryTransaction(
                                            date = formData["date"] ?: todayDate,
                                            movementType = formData["movementType"] ?: "إيداع",
                                            value = formData["value"]?.toDoubleOrNull() ?: 0.0,
                                            reason = formData["reason"] ?: "",
                                            party = formData["party"] ?: ""
                                        )
                                    )
                                }
                                "debts" -> {
                                    viewModel.addDebtManual(
                                        Debt(
                                            party = formData["party"] ?: "",
                                            owedToUs = formData["owedToUs"]?.toDoubleOrNull() ?: 0.0,
                                            owedByUs = formData["owedByUs"]?.toDoubleOrNull() ?: 0.0,
                                            dueDate = formData["dueDate"] ?: todayDate,
                                            status = formData["status"] ?: "نشط"
                                        )
                                    )
                                }
                            }
                            onDismiss()
                        },
                        colors = ButtonDefaults.buttonColors(containerColor = MaterialTheme.colorScheme.primary),
                        modifier = Modifier.weight(1f)
                    ) {
                        Text("إضافة")
                    }
                    OutlinedButton(
                        onClick = onDismiss,
                        modifier = Modifier.weight(1f)
                    ) {
                        Text("إلغاء")
                    }
                }
            }
        }
    }
}

@Composable
fun FormTextField(
    label: String,
    key: String,
    data: MutableMap<String, String>,
    initial: String = "",
    isNumber: Boolean = false
) {
    var textState by remember { mutableStateOf(data[key] ?: initial) }
    
    // sync map early
    LaunchedEffect(textState) {
        data[key] = textState
    }

    OutlinedTextField(
        value = textState,
        onValueChange = { textState = it },
        label = { Text(label) },
        singleLine = true,
        modifier = Modifier.fillMaxWidth().testTag("form_input_$key"),
        keyboardOptions = KeyboardOptions(
            keyboardType = if (isNumber) KeyboardType.Number else KeyboardType.Text
        )
    )
}

fun shareMeetingReport(context: android.content.Context, meeting: Meeting) {
    val shareBody = """
        📝 تقرير اجتماع: ${meeting.title}
        📅 التاريخ والوقت: ${meeting.date}
        👨‍🌾 الحاضرون: ${meeting.attendees}
        
        -------------------------------------------
        📌 الملخص التنفيذي وتوصيات الاجتماع:
        ${meeting.summary}
        
        -------------------------------------------
        ✅ القرارات ومهام العمل المطلوبة:
        ${meeting.actionItems}
        
        -------------------------------------------
        📄 التقرير الرسمي الشامل والبيان الختامي:
        ${meeting.reportText}
        
        -------------------------------------------
        تم توليد وتصدير هذا التقرير تلقائياً بواسطة:
        🌾 نظام إدارة المزرعة الشخصي الذكي للأستاذ أحمد باشا
    """.trimIndent()

    val intent = android.content.Intent(android.content.Intent.ACTION_SEND).apply {
        type = "text/plain"
        putExtra(android.content.Intent.EXTRA_SUBJECT, "تقرير اجتماع: ${meeting.title}")
        putExtra(android.content.Intent.EXTRA_TEXT, shareBody)
    }
    context.startActivity(android.content.Intent.createChooser(intent, "تصدير ومشاركة التقرير عبر:"))
}

@Composable
fun MeetingsScreen(viewModel: FarmViewModel) {
    val meetings by viewModel.meetings.collectAsStateWithLifecycle()
    val isProcessing by viewModel.isProcessingMeeting.collectAsStateWithLifecycle()
    val isMeetingRecording by viewModel.isMeetingRecording.collectAsStateWithLifecycle()
    val meetingRecordingDuration by viewModel.meetingRecordingDuration.collectAsStateWithLifecycle()

    val context = LocalContext.current
    var showAddDialog by remember { mutableStateOf(false) }

    val meetingRecordPermissionLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.RequestPermission()
    ) { isGranted ->
        if (isGranted) {
            viewModel.startMeetingRecording()
        } else {
            android.widget.Toast.makeText(context, "يرجى تفعيل صلاحية الميكروفون للتسجيل صامتاً", android.widget.Toast.LENGTH_SHORT).show()
        }
    }

    Column(modifier = Modifier.fillMaxSize()) {
        Box(modifier = Modifier.fillMaxSize()) {
                Column(modifier = Modifier.fillMaxSize()) {
                    SilentMeetingRecorderCard(
                        isRecording = isMeetingRecording,
                        duration = meetingRecordingDuration,
                        onStart = {
                            meetingRecordPermissionLauncher.launch(android.Manifest.permission.RECORD_AUDIO)
                        },
                        onStop = { simulatedText ->
                            viewModel.stopAndProcessMeeting(simulatedText)
                        },
                        onCancel = {
                            viewModel.cancelMeetingRecording()
                        }
                    )

                    if (meetings.isEmpty()) {
                        Column(
                            modifier = Modifier
                                .weight(1f)
                                .fillMaxWidth()
                                .padding(32.dp),
                            horizontalAlignment = Alignment.CenterHorizontally,
                            verticalArrangement = Arrangement.Center
                        ) {
                            Text("📝", fontSize = 64.sp)
                            Spacer(modifier = Modifier.height(16.dp))
                            Text("لا توجد اجتماعات مسجلة حتى الآن", fontSize = 18.sp, fontWeight = FontWeight.Bold, color = MaterialTheme.colorScheme.onSurface)
                            Spacer(modifier = Modifier.height(8.dp))
                            Text(
                                "يمكنك تسجيل جلسات النقاش، اجتماعات العمال، تفاصيل الزيارات، وسيقوم المساعد الذكي بتلخيصها وصياغة تقارير رسمية جاهزة للتصدير والمشاركة.",
                                fontSize = 13.sp,
                                color = Color.Gray,
                                textAlign = TextAlign.Center
                            )
                        }
                    } else {
                        LazyColumn(
                            modifier = Modifier
                                .weight(1f)
                                .fillMaxWidth()
                                .padding(16.dp),
                            verticalArrangement = Arrangement.spacedBy(16.dp)
                        ) {
                            item {
                                Row(
                                    modifier = Modifier.fillMaxWidth(),
                                    horizontalArrangement = Arrangement.SpaceBetween,
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    Text("🗒️ سجل الاجتماعات والتقارير الذكية", fontSize = 18.sp, fontWeight = FontWeight.Bold)
                                    Button(
                                        onClick = { showAddDialog = true },
                                        shape = RoundedCornerShape(8.dp),
                                        contentPadding = PaddingValues(horizontal = 12.dp, vertical = 8.dp)
                                    ) {
                                        Icon(Icons.Default.Add, contentDescription = null)
                                        Spacer(modifier = Modifier.width(4.dp))
                                        Text("تسجيل يدوي")
                                    }
                                }
                            }

                            items(meetings) { meeting ->
                                MeetingCard(
                                    meeting = meeting,
                                    onDelete = { viewModel.deleteMeetingManual(meeting) },
                                    onShare = { shareMeetingReport(context, meeting) }
                                )
                            }
                        }
                    }

            if (isProcessing) {
                Box(
                    modifier = Modifier
                        .fillMaxSize()
                        .background(Color.Black.copy(alpha = 0.5f)),
                    contentAlignment = Alignment.Center
                ) {
                    Card(
                        shape = RoundedCornerShape(12.dp),
                        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)
                    ) {
                        Column(
                            modifier = Modifier.padding(24.dp),
                            horizontalAlignment = Alignment.CenterHorizontally,
                            verticalArrangement = Arrangement.spacedBy(16.dp)
                        ) {
                            CircularProgressIndicator(color = MaterialTheme.colorScheme.primary)
                            Text(
                                "🪄 يقوم المساعد الآن بتحليل النقاش وتلخيصه وصياغة التقرير الرسمي...",
                                fontSize = 14.sp,
                                fontWeight = FontWeight.Bold,
                                color = MaterialTheme.colorScheme.onSurface,
                                textAlign = TextAlign.Center,
                                modifier = Modifier.width(260.dp)
                            )
                        }
                    }
                }
            }

            if (showAddDialog) {
                AddMeetingDialog(
                    onDismiss = { showAddDialog = false },
                    onSave = { title, attendees, rawNotes ->
                        viewModel.processAndSaveMeeting(title, attendees, rawNotes) {
                            showAddDialog = false
                        }
                    }
                )
            }
        }
    }
}

@Composable
fun MeetingCard(
    meeting: Meeting,
    onDelete: () -> Unit,
    onShare: () -> Unit
) {
    var expanded by remember { mutableStateOf(false) }
    var selectedTab by remember { mutableStateOf(0) } // 0: Summary, 1: Action Items, 2: Report

    ElevatedCard(
        modifier = Modifier.fillMaxWidth(),
        shape = RoundedCornerShape(12.dp)
    ) {
        Column(modifier = Modifier.padding(16.dp)) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.Top
            ) {
                Column(modifier = Modifier.weight(1f)) {
                    Text(meeting.title, fontSize = 16.sp, fontWeight = FontWeight.Bold, color = MaterialTheme.colorScheme.primary)
                    Spacer(modifier = Modifier.height(4.dp))
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(6.dp)
                    ) {
                        Icon(Icons.Default.DateRange, contentDescription = null, tint = Color.Gray, modifier = Modifier.size(14.dp))
                        Text(meeting.date, fontSize = 11.sp, color = Color.Gray)
                        Spacer(modifier = Modifier.width(8.dp))
                        Icon(Icons.Default.People, contentDescription = null, tint = Color.Gray, modifier = Modifier.size(14.dp))
                        Text(meeting.attendees, fontSize = 11.sp, color = Color.Gray, maxLines = 1, overflow = TextOverflow.Ellipsis)
                    }
                }
                Row {
                    IconButton(onClick = onShare) {
                        Icon(Icons.Default.Share, contentDescription = "مشاركة التقرير", tint = MaterialTheme.colorScheme.primary)
                    }
                    IconButton(onClick = onDelete) {
                        Icon(Icons.Default.Delete, contentDescription = "حذف", tint = Color(0xFFC0392B))
                    }
                }
            }

            Spacer(modifier = Modifier.height(12.dp))
            Button(
                onClick = { expanded = !expanded },
                colors = ButtonDefaults.buttonColors(containerColor = MaterialTheme.colorScheme.secondaryContainer, contentColor = MaterialTheme.colorScheme.onSecondaryContainer),
                shape = RoundedCornerShape(8.dp),
                modifier = Modifier.fillMaxWidth(),
                contentPadding = PaddingValues(vertical = 4.dp)
            ) {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.Center
                ) {
                    Text(if (expanded) "🔼 إغلاق ملف الاجتماع" else "🔽 فتح واستعراض التقرير والقرارات", fontSize = 13.sp)
                }
            }

            AnimatedVisibility(visible = expanded) {
                Column(modifier = Modifier.padding(top = 16.dp)) {
                    TabRow(
                        selectedTabIndex = selectedTab,
                        containerColor = Color.Transparent,
                        contentColor = MaterialTheme.colorScheme.primary
                    ) {
                        Tab(selected = selectedTab == 0, onClick = { selectedTab = 0 }) {
                            Text("📌 الملخص", modifier = Modifier.padding(vertical = 10.dp), fontSize = 13.sp, fontWeight = FontWeight.Bold)
                        }
                        Tab(selected = selectedTab == 1, onClick = { selectedTab = 1 }) {
                            Text("✅ القرارات والمهام", modifier = Modifier.padding(vertical = 10.dp), fontSize = 13.sp, fontWeight = FontWeight.Bold)
                        }
                        Tab(selected = selectedTab == 2, onClick = { selectedTab = 2 }) {
                            Text("📄 التقرير الشامل", modifier = Modifier.padding(vertical = 10.dp), fontSize = 13.sp, fontWeight = FontWeight.Bold)
                        }
                    }

                    Spacer(modifier = Modifier.height(12.dp))

                    when (selectedTab) {
                        0 -> {
                            Text(meeting.summary, fontSize = 13.sp, color = MaterialTheme.colorScheme.onSurface, lineHeight = 20.sp)
                        }
                        1 -> {
                            Text(meeting.actionItems, fontSize = 13.sp, color = MaterialTheme.colorScheme.onSurface, lineHeight = 20.sp)
                        }
                        2 -> {
                            Box(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .background(MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.3f), RoundedCornerShape(8.dp))
                                    .padding(12.dp)
                            ) {
                                Text(meeting.reportText, fontSize = 13.sp, color = MaterialTheme.colorScheme.onSurface, lineHeight = 20.sp)
                            }
                        }
                    }

                    Spacer(modifier = Modifier.height(16.dp))
                    
                    // Show raw notes in small subtitle
                    Text("💡 النقاط الخام المسجلة:", fontSize = 11.sp, color = Color.Gray, fontWeight = FontWeight.Bold)
                    Text(meeting.rawNotes, fontSize = 11.sp, color = Color.Gray, maxLines = 2, overflow = TextOverflow.Ellipsis)
                }
            }
        }
    }
}

@Composable
fun AddMeetingDialog(
    onDismiss: () -> Unit,
    onSave: (title: String, attendees: String, rawNotes: String) -> Unit
) {
    var title by remember { mutableStateOf("") }
    var attendees by remember { mutableStateOf("") }
    var rawNotes by remember { mutableStateOf("") }
    var errorMsg by remember { mutableStateOf("") }

    Dialog(onDismissRequest = onDismiss) {
        Card(
            shape = RoundedCornerShape(16.dp),
            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
            modifier = Modifier
                .fillMaxWidth()
                .padding(vertical = 24.dp)
        ) {
            Column(
                modifier = Modifier
                    .padding(16.dp)
                    .verticalScroll(androidx.compose.foundation.rememberScrollState()),
                verticalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                Text(
                    "📝 تسجيل وتلخيص اجتماع جديد",
                    fontSize = 18.sp,
                    fontWeight = FontWeight.Bold,
                    color = MaterialTheme.colorScheme.primary,
                    textAlign = TextAlign.Center,
                    modifier = Modifier.fillMaxWidth()
                )

                Text(
                    "اكتب هنا تفاصيل الاجتماع أو مسودة الملاحظات غير المنظمة، وسيقوم المساعد الذكي بصياغة تقرير رسمي متكامل واستخراج القرارات والمواعيد.",
                    fontSize = 12.sp,
                    color = Color.Gray,
                    lineHeight = 16.sp
                )

                OutlinedTextField(
                    value = title,
                    onValueChange = { title = it },
                    label = { Text("عنوان الاجتماع (مثال: اجتماع العمال والرواتب)") },
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth()
                )

                OutlinedTextField(
                    value = attendees,
                    onValueChange = { attendees = it },
                    label = { Text("الحاضرون (مثال: أحمد، أبو العلا، فرج)") },
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth()
                )

                OutlinedTextField(
                    value = rawNotes,
                    onValueChange = { rawNotes = it },
                    label = { Text("ملاحظات ونقاط النقاش بالاجتماع...") },
                    minLines = 4,
                    modifier = Modifier.fillMaxWidth()
                )

                if (errorMsg.isNotEmpty()) {
                    Text(errorMsg, color = Color.Red, fontSize = 12.sp)
                }

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    Button(
                        onClick = {
                            if (title.isBlank() || rawNotes.isBlank()) {
                                errorMsg = "يرجى كتابة العنوان وملاحظات النقاش أولاً"
                            } else {
                                onSave(title, attendees.ifBlank { "أحمد باشا والحضور" }, rawNotes)
                            }
                        },
                        colors = ButtonDefaults.buttonColors(containerColor = MaterialTheme.colorScheme.primary),
                        modifier = Modifier.weight(1f)
                    ) {
                        Text("🪄 صياغة بالذكاء الاصطناعي")
                    }

                    OutlinedButton(
                        onClick = onDismiss,
                        modifier = Modifier.weight(0.5f)
                    ) {
                        Text("إلغاء")
                    }
                }
            }
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun VoiceToTaskFillDialog(
    action: com.example.api.ChatResponse,
    onDismiss: () -> Unit,
    onConfirm: (Map<String, String>) -> Unit
) {
    val context = LocalContext.current
    val initialData = remember(action) { action.actionData ?: emptyMap() }
    val editableFields = remember(action) {
        mutableStateMapOf<String, String>().apply {
            putAll(initialData)
        }
    }
    
    val tableNameArabic = when (action.tableName?.lowercase()) {
        "land" -> "تفاصيل الأرض 🗺️"
        "crops" -> "المحاصيل الزراعية 🌾"
        "operations" -> "العمليات الزراعية 🚜"
        "inventory" -> "مخزون المستودع 📦"
        "inventory_movement" -> "حركة مخزن 📥"
        "animals" -> "الثروة الحيوانية 🐄"
        "animal_production" -> "الإنتاج الحيواني 🥛"
        "workers" -> "بيانات العمال 👥"
        "attendance" -> "كشف الحضور والرواتب 📝"
        "contacts" -> "الموردين والعملاء 🤝"
        "equipment" -> "المعدات والآلات 🚜"
        "maintenance" -> "صيانة المعدات 🛠️"
        "water" -> "استهلاك المياه والري 💧"
        "purchases" -> "فاتورة مشتريات 💸"
        "sales" -> "فاتورة مبيعات 💰"
        "treasury" -> "حركة الخزينة والنقدية 💵"
        "debts" -> "الديون والحسابات المعلقة ⚖️"
        else -> "معاملة جديدة ⚙️"
    }

    val fieldNameArabic = mapOf(
        "code" to "كود السجل",
        "name" to "الاسم",
        "area" to "المساحة",
        "unit" to "الوحدة",
        "region" to "المنطقة",
        "crop" to "المحصول",
        "season" to "الموسم",
        "landCode" to "كود الأرض",
        "managementType" to "نوع الإدارة",
        "responsible" to "المسؤول",
        "expectedProduction" to "الإنتاج المتوقع",
        "actualProduction" to "الإنتاج الفعلي",
        "date" to "التاريخ",
        "cropCode" to "كود المحصول",
        "operation" to "نوع العملية",
        "worker" to "العامل",
        "cost" to "التكلفة (ج.م)",
        "notes" to "ملاحظات إضافية",
        "item" to "الصنف / البند",
        "category" to "القسم",
        "openingBalance" to "الرصيد الافتتاحي",
        "currentBalance" to "الرصيد الحالي",
        "minimumLevel" to "الحد الأدنى",
        "itemCode" to "كود الصنف",
        "movementType" to "نوع الحركة",
        "quantity" to "الكمية",
        "fromLocation" to "من مكان",
        "toLocation" to "إلى مكان",
        "type" to "النوع",
        "count" to "العدد",
        "purpose" to "الغرض",
        "location" to "المكان",
        "value" to "القيمة (ج.م)",
        "animalType" to "نوع الحيوان",
        "revenue" to "الإيراد (ج.م)",
        "job" to "الوظيفة / المهنة",
        "phone" to "رقم الهاتف",
        "salary" to "الراتب / اليومية",
        "workerCode" to "كود العامل",
        "task" to "المهمة المكلف بها",
        "hours" to "عدد الساعات",
        "wage" to "الأجر اليومي",
        "balance" to "الرصيد الحالي",
        "purchaseDate" to "تاريخ الشراء",
        "operatingHours" to "ساعات التشغيل",
        "equipmentCode" to "كود المعدة",
        "description" to "الوصف",
        "source" to "مصدر المياه",
        "supplier" to "المورد",
        "price" to "السعر للواحدة",
        "customer" to "العميل",
        "product" to "المنتج المباع",
        "reason" to "السبب / البيان",
        "party" to "الطرف الآخر",
        "owedToUs" to "فلوس لينا (ج.م)",
        "owedByUs" to "ديون علينا (ج.م)",
        "dueDate" to "تاريخ الاستحقاق",
        "status" to "حالة الدين"
    )

    Dialog(onDismissRequest = onDismiss) {
        Card(
            shape = RoundedCornerShape(28.dp),
            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
            border = BorderStroke(1.5.dp, MaterialTheme.colorScheme.primary),
            modifier = Modifier
                .fillMaxWidth()
                .padding(vertical = 16.dp)
        ) {
            Column(
                modifier = Modifier
                    .padding(24.dp)
                    .fillMaxWidth(),
                verticalArrangement = Arrangement.spacedBy(16.dp)
            ) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    Icon(
                        imageVector = Icons.Default.Info,
                        contentDescription = null,
                        tint = MaterialTheme.colorScheme.primary,
                        modifier = Modifier.size(28.dp)
                    )
                    Column {
                        Text(
                            text = "تعبئة البيانات تلقائياً بالصوت",
                            fontSize = 16.sp,
                            fontWeight = FontWeight.Bold,
                            color = MaterialTheme.colorScheme.primary
                        )
                        Text(
                            text = "راجع وعدّل المعاملة المستخرجة بالأسفل:",
                            fontSize = 12.sp,
                            color = Color.Gray
                        )
                    }
                }

                Surface(
                    shape = RoundedCornerShape(12.dp),
                    color = MaterialTheme.colorScheme.primaryContainer,
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Text(
                        text = "جدول المعاملة: $tableNameArabic",
                        fontSize = 14.sp,
                        fontWeight = FontWeight.Bold,
                        color = MaterialTheme.colorScheme.onPrimaryContainer,
                        modifier = Modifier.padding(horizontal = 16.dp, vertical = 8.dp),
                        textAlign = TextAlign.Center
                    )
                }

                if (!action.reply.isNullOrEmpty()) {
                    Text(
                        text = "💬 \"${action.reply}\"",
                        fontSize = 13.sp,
                        style = androidx.compose.ui.text.TextStyle(fontStyle = androidx.compose.ui.text.font.FontStyle.Italic),
                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                        modifier = Modifier
                            .background(MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.5f), RoundedCornerShape(12.dp))
                            .padding(12.dp)
                            .fillMaxWidth()
                    )
                }

                HorizontalDivider()

                LazyColumn(
                    modifier = Modifier
                        .fillMaxWidth()
                        .weight(1f, fill = false),
                    verticalArrangement = Arrangement.spacedBy(12.dp)
                ) {
                    items(editableFields.keys.toList()) { key ->
                        val label = fieldNameArabic[key] ?: key
                        val value = editableFields[key] ?: ""
                        Column(
                            verticalArrangement = Arrangement.spacedBy(4.dp),
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Text(
                                text = label,
                                fontSize = 12.sp,
                                fontWeight = FontWeight.SemiBold,
                                color = MaterialTheme.colorScheme.onSurface
                            )
                            OutlinedTextField(
                                value = value,
                                onValueChange = { editableFields[key] = it },
                                modifier = Modifier.fillMaxWidth(),
                                shape = RoundedCornerShape(12.dp),
                                colors = OutlinedTextFieldDefaults.colors(
                                    focusedBorderColor = MaterialTheme.colorScheme.primary,
                                    unfocusedBorderColor = Color.LightGray
                                ),
                                singleLine = true
                            )
                        }
                    }
                }

                Spacer(modifier = Modifier.height(8.dp))

                // Voice Confirmation Loop Banner for Zero-Manual-Input UX
                Card(
                    modifier = Modifier.fillMaxWidth(),
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.primaryContainer.copy(alpha = 0.6f)),
                    shape = RoundedCornerShape(12.dp),
                    border = BorderStroke(1.dp, MaterialTheme.colorScheme.primary)
                ) {
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(12.dp),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        Icon(
                            imageVector = Icons.Default.Mic, 
                            contentDescription = null, 
                            tint = MaterialTheme.colorScheme.primary,
                            modifier = Modifier.size(24.dp)
                        )
                        Column(modifier = Modifier.weight(1f)) {
                            Text(
                                text = "حلقة التأكيد التلقائي بالصوت 🗣️", 
                                fontSize = 12.sp, 
                                fontWeight = FontWeight.Bold, 
                                color = MaterialTheme.colorScheme.primary
                            )
                            Text(
                                text = "الأستاذ بليغ ينتظر موافقتك الصوتية. اضغط لمضاهاة نطقك لـ 'تمام موافق' وحفظ المعاملة تلقائياً:", 
                                fontSize = 10.sp, 
                                color = MaterialTheme.colorScheme.onPrimaryContainer,
                                lineHeight = 14.sp
                            )
                        }
                        Button(
                            onClick = {
                                android.widget.Toast.makeText(context, "🎤 قلتَ: 'تمام موافق'. تم التأكيد والحفظ بنجاح! 🎉", android.widget.Toast.LENGTH_SHORT).show()
                                onConfirm(editableFields.toMap())
                            },
                            colors = ButtonDefaults.buttonColors(containerColor = MaterialTheme.colorScheme.primary),
                            contentPadding = PaddingValues(horizontal = 12.dp, vertical = 4.dp),
                            modifier = Modifier.height(32.dp),
                            shape = RoundedCornerShape(8.dp)
                        ) {
                            Text("تمام موافق ✅", fontSize = 10.sp, fontWeight = FontWeight.Bold)
                        }
                    }
                }

                Spacer(modifier = Modifier.height(8.dp))

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(12.dp)
                ) {
                    Button(
                        onClick = {
                            onConfirm(editableFields.toMap())
                        },
                        shape = RoundedCornerShape(16.dp),
                        colors = ButtonDefaults.buttonColors(containerColor = MaterialTheme.colorScheme.primary),
                        modifier = Modifier.weight(1f)
                    ) {
                        Text("حفظ وتأكيد المعاملة 💾", fontWeight = FontWeight.Bold, color = Color.White)
                    }
                    
                    OutlinedButton(
                        onClick = onDismiss,
                        shape = RoundedCornerShape(16.dp),
                        modifier = Modifier.weight(1f)
                    ) {
                        Text("إلغاء المعاملة", color = MaterialTheme.colorScheme.error)
                    }
                }
            }
        }
    }
}

@Composable
fun SilentMeetingRecorderCard(
    isRecording: Boolean,
    duration: Int,
    onStart: () -> Unit,
    onStop: (String?) -> Unit,
    onCancel: () -> Unit
) {
    val infiniteTransition = rememberInfiniteTransition(label = "meeting_pulse")
    val pulseScale by infiniteTransition.animateFloat(
        initialValue = 1.0f,
        targetValue = 1.2f,
        animationSpec = infiniteRepeatable(
            animation = tween(1000, easing = LinearEasing),
            repeatMode = RepeatMode.Reverse
        ),
        label = "meeting_scale"
    )

    Card(
        modifier = Modifier
            .fillMaxWidth()
            .padding(16.dp),
        colors = CardDefaults.cardColors(
            containerColor = if (isRecording) MaterialTheme.colorScheme.errorContainer.copy(alpha = 0.3f) 
                             else MaterialTheme.colorScheme.primaryContainer.copy(alpha = 0.3f)
        ),
        shape = RoundedCornerShape(16.dp),
        border = BorderStroke(
            width = 1.5.dp,
            color = if (isRecording) MaterialTheme.colorScheme.error else MaterialTheme.colorScheme.primary
        )
    ) {
        Column(
            modifier = Modifier.padding(16.dp),
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                Icon(
                    imageVector = if (isRecording) Icons.Default.Mic else Icons.Default.VolumeUp,
                    contentDescription = null,
                    tint = if (isRecording) MaterialTheme.colorScheme.error else MaterialTheme.colorScheme.primary,
                    modifier = Modifier.size(24.dp)
                )
                Text(
                    text = if (isRecording) "الأستاذ بليغ: جاري تسجيل ومتابعة الاجتماع صامتاً 🔴" else "الأستاذ بليغ: تسجيل الاجتماع الذكي الصامت 🎙️",
                    fontWeight = FontWeight.Bold,
                    fontSize = 14.sp,
                    color = if (isRecording) MaterialTheme.colorScheme.onErrorContainer else MaterialTheme.colorScheme.onPrimaryContainer
                )
            }

            Text(
                text = if (isRecording) 
                    "الأستاذ بليغ يستمع الآن صامتاً ويدوّن كافة تفاصيل النقاش والقرارات بشكل تلقائي في الخلفية دون مقاطعة الجالسين." 
                    else "ابدأ الاجتماع ودع الأستاذ بليغ يستمع صامتاً لتدوين النقاشات وتوليد تقرير شامل للمقررات وتوصيات الاجتماع فوراً عند الانتهاء.",
                fontSize = 12.sp,
                color = MaterialTheme.colorScheme.onSurfaceVariant,
                lineHeight = 18.sp
            )

            if (isRecording) {
                val seconds = duration % 60
                val minutes = duration / 60
                
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    Box(
                        modifier = Modifier
                            .size(12.dp * pulseScale)
                            .background(Color.Red, CircleShape)
                    )
                    Text(
                        text = String.format("%02d:%02d", minutes, seconds),
                        fontWeight = FontWeight.Bold,
                        fontSize = 20.sp,
                        color = Color.Red
                    )
                }

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(12.dp)
                ) {
                    Button(
                        onClick = { onStop(null) },
                        colors = ButtonDefaults.buttonColors(containerColor = MaterialTheme.colorScheme.error),
                        modifier = Modifier.weight(1f),
                        shape = RoundedCornerShape(12.dp)
                    ) {
                        Icon(Icons.Default.Stop, contentDescription = null, tint = Color.White)
                        Spacer(modifier = Modifier.width(4.dp))
                        Text("إنهاء وتوليد التقرير 💾", fontWeight = FontWeight.Bold, color = Color.White)
                    }

                    OutlinedButton(
                        onClick = onCancel,
                        modifier = Modifier.weight(0.5f),
                        shape = RoundedCornerShape(12.dp),
                        colors = ButtonDefaults.outlinedButtonColors(contentColor = MaterialTheme.colorScheme.error)
                    ) {
                        Text("إلغاء")
                    }
                }
            } else {
                Button(
                    onClick = onStart,
                    colors = ButtonDefaults.buttonColors(containerColor = MaterialTheme.colorScheme.primary),
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(12.dp)
                ) {
                    Icon(Icons.Default.PlayArrow, contentDescription = null)
                    Spacer(modifier = Modifier.width(6.dp))
                    Text("ابدأ تدوين الاجتماع صامتاً الآن", fontWeight = FontWeight.Bold)
                }
                
                // Add Quick Simulation Presets
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(8.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text("💡 محاكاة كلام:", fontSize = 10.sp, color = Color.Gray)
                    
                    val simOptions = listOf(
                        "اجتماع ري المزرعة" to "ناقشنا جدولة ري البرسيم والبطاطس لتقليل استهلاك المياه، وصيانة مضخة البئر الغربي.",
                        "حسابات العمال" to "تم مراجعة كشف حضور عمال اليومية وتوزيع المكافآت الاستثنائية لزيادة الإنتاج."
                    )
                    
                    simOptions.forEach { (label, text) ->
                        Button(
                            onClick = {
                                onStart()
                                onStop(text)
                            },
                            colors = ButtonDefaults.buttonColors(containerColor = MaterialTheme.colorScheme.surfaceVariant),
                            contentPadding = PaddingValues(horizontal = 8.dp, vertical = 2.dp),
                            shape = RoundedCornerShape(8.dp),
                            modifier = Modifier.height(28.dp)
                        ) {
                            Text(label, fontSize = 9.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
                        }
                    }
                }
            }
        }
    }
}
