package com.example.api

import android.content.Context
import android.util.Log
import com.example.BuildConfig
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.RequestBody.Companion.toRequestBody
import org.json.JSONObject
import java.util.concurrent.TimeUnit

object GeminiManager {
    private const val TAG = "GeminiManager"
    private const val BASE_URL = "https://generativelanguage.googleapis.com/v1beta/models/gemini-2.0-flash:generateContent"

    private val client = OkHttpClient.Builder()
        .connectTimeout(60, TimeUnit.SECONDS)
        .readTimeout(60, TimeUnit.SECONDS)
        .writeTimeout(60, TimeUnit.SECONDS)
        .build()

    /**
     * Retrieves the API key. Checks BuildConfig first, then local storage as a fallback.
     */
    fun getApiKey(context: Context): String {
        val buildConfigKey = BuildConfig.GEMINI_API_KEY
        if (buildConfigKey.isNotEmpty() && buildConfigKey != "MY_GEMINI_API_KEY") {
            return buildConfigKey
        }
        val prefs = context.getSharedPreferences("farm_prefs", Context.MODE_PRIVATE)
        return prefs.getString("gemini_api_key", "") ?: ""
    }

    /**
     * Saves a user-configured API key locally.
     */
    fun saveApiKey(context: Context, key: String) {
        val prefs = context.getSharedPreferences("farm_prefs", Context.MODE_PRIVATE)
        prefs.edit().putString("gemini_api_key", key).apply()
    }

    /**
     * Sends the chat message along with current database snapshots to "الأستاذ" AI assistant.
     */
    suspend fun chatWithAlOstaz(
        context: Context,
        userMessage: String,
        dbSnapshotContext: String,
        apiKey: String
    ): ChatResponse {
        if (apiKey.trim().isEmpty() || apiKey == "MY_GEMINI_API_KEY") {
            return getLocalSimulatedResponse(userMessage, dbSnapshotContext)
        }

        val systemInstruction = """
            أنت "الأستاذ" - المستشار والمساعد الشخصي الذكي لأحمد باشا، والخبير في إدارة المزارع الشاملة وحسابات الخزينة والمخازن والعمال. تتحدث بلهجة مصرية عامية ودودة ومرحة وقريبة من القلب، وتخاطب صاحب المزرعة بـ "يا أحمد باشا" أو "يا غالي".
            
            مهمتك الأساسية هي:
            1. فهم ما يقوله أحمد باشا، وتحديد ما إذا كان يرغب في تسجيل معاملة أو عملية جديدة (إدخال بيانات) أو يستفسر عن تقرير أو بيانات مسجلة بالفعل.
            2. أنت في رحلة تعلم مستمرة ودائمة عن شخصية أحمد باشا، طبيعة عمله، وجدول مواعيده، وعاداته وسلوكياته على الهاتف. 
               إذا ذكر أحمد باشا أي معلومة تخص عاداته اليومية، جدول عمله، تفضيلاته الشخصية، أو طبيعة مهامه، أو أي سلوك تكتشفه، قم فوراً بصياغة رد تأكيدي ودي ودافئ، وحدد إجراء INSERT على جدول "assistant_profile" لتحديث هذه المعلومات وحفظها في ذاكرتك الدائمة!
            
            لقد تم تزويدك بلقطة (Snapshot) للبيانات الحالية المخزنة في قاعدة بيانات المزرعة في نص الطلب. استخدم هذه البيانات للإجابة بدقة وبأرقام واضحة عن أي استفسار يخص الحسابات، المخازن، الأراضي، أو المحاصيل.
            
            إذا كان كلام أحمد يعبر عن تسجيل عملية أو حركة جديدة، قم بصياغة رد تأكيدي دافئ، وحدد نوع العملية والجدول المناسب وقيم الحقول بدقة في كائن الـ Action.
            
            القواعد الصارمة للـ Action:
            - نوع العملية (actionType) يمكن أن يكون فقط "INSERT" أو null.
            - اسم الجدول (tableName) يجب أن يتطابق تماماً مع أحد الأسماء التالية:
              "land", "crops", "operations", "inventory", "inventory_movement", "animals", "animal_production", "workers", "attendance", "contacts", "equipment", "maintenance", "water", "purchases", "sales", "treasury", "debts", "assistant_profile".
            - البيانات (actionData) يجب أن تحتوي على مفاتيح الحقول المناسبة للجدول بقيم نصية واضحة.
            
            الحقول لكل جدول:
            1. land: "code" (Lxxx), "name" (اسم الأرض), "area" (رقم), "unit" (فدان/متر), "region" (المنطقة), "notes"
            2. crops: "code" (Cxxx), "landCode" (كود الأرض), "crop" (المحصول), "season" (صيفي/شتوي/إلخ), "area" (مساحة المحصول), "managementType" (عضوي/تقليدي), "responsible" (المسؤول), "expectedProduction", "actualProduction"
            3. operations: "date" (YYYY-MM-DD), "cropCode" (كود المحصول), "operation" (ري/تسميد/حصاد/إلخ), "worker", "cost", "notes"
            4. inventory: "code" (INVxxx), "item", "category" (أسمدة/أعلاف/أدوية/بذور/إلخ), "unit", "openingBalance", "currentBalance", "minimumLevel"
            5. inventory_movement: "date" (YYYY-MM-DD), "itemCode", "movementType" (وارد/صادر), "quantity", "fromLocation", "toLocation", "cropCode", "cost"
            6. animals: "code" (Axxx), "type" (أبقار/أغنام/إلخ), "count", "purpose" (لحم/حليب/بيض), "location", "value"
            7. animal_production: "date" (YYYY-MM-DD), "animalType", "quantity", "unit", "revenue"
            8. workers: "code" (Wxxx), "name", "job", "phone", "salary"
            9. attendance: "date" (YYYY-MM-DD), "workerCode", "task", "location", "hours", "wage"
            10. contacts: "code" (CTxxx), "name", "type" (مورد/عميل), "phone", "balance"
            11. equipment: "code" (Exxx), "name", "category", "purchaseDate" (YYYY-MM-DD), "value", "operatingHours"
            12. maintenance: "date" (YYYY-MM-DD), "equipmentCode", "description", "cost"
            13. water: "date" (YYYY-MM-DD), "source", "operatingHours", "cost", "cropCode"
            14. purchases: "date" (YYYY-MM-DD), "supplier", "item", "quantity", "price"
            15. sales: "date" (YYYY-MM-DD), "customer", "product", "quantity", "price"
            16. treasury: "date" (YYYY-MM-DD), "movementType" (إيداع/صرف), "value", "reason", "party"
            17. debts: "party", "owedToUs" (فلوس لينا), "owedByUs" (ديون علينا), "dueDate" (YYYY-MM-DD), "status" (نشط/مسدد)
            18. assistant_profile: "personality" (سمات أحمد باشا المكتشفة كشخص كالأمانة أو السرعة)، "jobType" (طبيعة عمل أحمد وتسميتها)، "scheduleNotes" (أوقات فراغه وجدوله واستيقاظه وحركته المكتشفة)، "behaviorObservations" (ملاحظات سلوكه كمدير في المزرعة)، "assistantJobDescription" (الوصف الوظيفي للمساعد)، "lastUpdated" (تاريخ التحديث YYYY-MM-DD)

            يجب أن ترجع الإجابة دائماً بتنسيق JSON نظيف وصحيح بالبنية التالية تماماً:
            {
              "reply": "الرد الودي بالعامية المصرية والتقرير المالي أو الإداري لأحمد باشا",
              "actionType": "INSERT" أو null,
              "tableName": "اسم الجدول" أو null,
              "actionData": { ... الحقول المراد إدخالها ... } أو null
            }

            ملاحظات تاريخ اليوم التلقائي: استخدم تاريخ اليوم في حقل التاريخ إذا لم يحدد أحمد تاريخاً آخر.
        """.trimIndent()

        val fullPrompt = """
            البيانات الحالية المخزنة في قاعدة بيانات المزرعة للاستعلام والرجوع إليها:
            $dbSnapshotContext
            
            تاريخ اليوم الحالي وتوقيت المزرعة: ${java.text.SimpleDateFormat("yyyy-MM-dd", java.util.Locale.getDefault()).format(java.util.Date())}
            
            رسالة أحمد باشا:
            "$userMessage"
            
            أجب بصيغة الـ JSON المحددة مسبقاً فقط بدون أي نصوص خارجية أو علامات Markdown أخرى مثل ```json.
        """.trimIndent()

        return try {
            val jsonRequest = JSONObject().apply {
                put("contents", org.json.JSONArray().apply {
                    put(JSONObject().apply {
                        put("parts", org.json.JSONArray().apply {
                            put(JSONObject().apply {
                                put("text", fullPrompt)
                            })
                        })
                    })
                })
                put("systemInstruction", JSONObject().apply {
                    put("parts", org.json.JSONArray().apply {
                        put(JSONObject().apply {
                            put("text", systemInstruction)
                        })
                    })
                })
                put("generationConfig", JSONObject().apply {
                    put("responseMimeType", "application/json")
                    put("temperature", 0.3)
                })
            }

            val requestBody = jsonRequest.toString().toRequestBody("application/json".toMediaType())
            val urlWithKey = "$BASE_URL?key=$apiKey"

            val request = Request.Builder()
                .url(urlWithKey)
                .post(requestBody)
                .build()

            client.newCall(request).execute().use { response ->
                val bodyString = response.body?.string()
                if (!response.isSuccessful || bodyString == null) {
                    val errCode = response.code
                    Log.e(TAG, "Request failed with code $errCode: $bodyString, falling back to local simulation")
                    return getLocalSimulatedResponse(userMessage, dbSnapshotContext)
                }

                val jsonResponse = JSONObject(bodyString)
                val candidates = jsonResponse.optJSONArray("candidates")
                val firstCandidate = candidates?.optJSONObject(0)
                val content = firstCandidate?.optJSONObject("content")
                val parts = content?.optJSONArray("parts")
                val textResponse = parts?.optJSONObject(0)?.optString("text")

                if (textResponse != null) {
                    parseGeminiReply(textResponse)
                } else {
                    getLocalSimulatedResponse(userMessage, dbSnapshotContext)
                }
            }
        } catch (e: Exception) {
            Log.e(TAG, "Exception during Gemini Call, falling back to local simulation", e)
            getLocalSimulatedResponse(userMessage, dbSnapshotContext)
        }
    }

    /**
     * Highly sophisticated rule-based Arabic local intelligence simulator that parses statements 
     * and performs active database changes while responding in perfect Egyptian dialect.
     */
    fun getLocalSimulatedResponse(userMessage: String, dbSnapshotContext: String): ChatResponse {
        val trimmed = userMessage.trim()
        val today = java.text.SimpleDateFormat("yyyy-MM-dd", java.util.Locale.getDefault()).format(java.util.Date())
        
        return when {
            // Worker attendance & task
            trimmed.contains("حضور") || trimmed.contains("سجل حضور") || trimmed.contains("اشتغل") -> {
                val workerName = findKeywordInMap(trimmed, listOf("فرج", "أبو العلا", "سعيد", "جابر", "رمضان"), "فرج")
                val task = findKeywordInMap(trimmed, listOf("ري", "تسميد", "حصاد", "تقليم", "حراسة"), "أعمال صيانة وري الأراضي")
                ChatResponse(
                    reply = "تمام يا أحمد باشا! سجلت حضور العامل $workerName النهارده للقيام بمهمة ($task) وسجلت له يومية كاملة بقيمة 150 جنيه في كشف الحضور والرواتب. ربنا يبارك في عافيتهم! 🦾",
                    actionType = "INSERT",
                    tableName = "attendance",
                    actionData = mapOf(
                        "date" to today,
                        "workerCode" to "W001",
                        "task" to task,
                        "location" to "الأرض الرئيسية",
                        "hours" to "8",
                        "wage" to "150"
                    )
                )
            }
            
            // Sales / Revenue
            trimmed.contains("بعت") || trimmed.contains("بيع") || trimmed.contains("مبيعات") -> {
                val price = extractFirstNumber(trimmed, 5000)
                val product = findKeywordInMap(trimmed, listOf("طماطم", "برسيم", "قمح", "حليب", "بصل"), "محاصيل منوعة")
                ChatResponse(
                    reply = "ألف مبروك يا أحمد باشا البيعة دي! ربنا يرزقك من واسع فضله ونشوف مزرعتنا أكبر مزرعة في مصر 💰. بعت $product بقيمة $price جنيه، ودخلت المبلغ ده في رصيد الخزينة وسجلت المعاملة بنجاح.",
                    actionType = "INSERT",
                    tableName = "treasury",
                    actionData = mapOf(
                        "date" to today,
                        "movementType" to "إيداع",
                        "value" to price.toString(),
                        "reason" to "بيع $product للمشتري",
                        "party" to "عميل المزرعة"
                    )
                )
            }
            
            // Purchases / Expenses
            trimmed.contains("اشتريت") || trimmed.contains("شراء") || trimmed.contains("صرف") || trimmed.contains("دفعت") || trimmed.contains("سلفة") -> {
                val price = extractFirstNumber(trimmed, 1200)
                val item = findKeywordInMap(trimmed, listOf("سماد", "علف", "بذور", "وقود", "أدوية"), "مستلزمات إنتاج")
                ChatResponse(
                    reply = "تمام يا أحمد باشا، تم تسجيل صرف مبلغ $price جنيه من الخزينة لشراء ($item). وحدثت سجل المصاريف والمخازن عشان الرصيد يفضل مظبوط بالملي. 💸",
                    actionType = "INSERT",
                    tableName = "treasury",
                    actionData = mapOf(
                        "date" to today,
                        "movementType" to "صرف",
                        "value" to price.toString(),
                        "reason" to "شراء $item وصرف فوري",
                        "party" to "مورد المستلزمات"
                    )
                )
            }
            
            // Irrigation / operations
            trimmed.contains("ري") || trimmed.contains("سقيت") || trimmed.contains("مياه") -> {
                val crop = findKeywordInMap(trimmed, listOf("طماطم", "برسيم", "قمح", "بصل"), "المحصول الحالي")
                ChatResponse(
                    reply = "تسلم إيدك يا غالي! تم تسجيل عملية ري شاملة لـ ($crop) وتحديث سجل العمليات الزراعية للأرض. الري بانتظام هو سر الإنتاج العالي! 💧🌾",
                    actionType = "INSERT",
                    tableName = "operations",
                    actionData = mapOf(
                        "date" to today,
                        "cropCode" to "C001",
                        "operation" to "ري الأرض",
                        "worker" to "أبو العلا",
                        "cost" to "100",
                        "notes" to "تم الري بنجاح ومتابعة رطوبة التربة"
                    )
                )
            }

            // Equipment / Machinery logging (Autonomous Action Model Example)
            trimmed.contains("آلة") || trimmed.contains("معدة") || trimmed.contains("معدات") || trimmed.contains("صيانة آلة") || trimmed.contains("00543") -> {
                ChatResponse(
                    reply = "تمام يا أحمد باشا! تم تفعيل الإدخال الذكي بالصوت لـ (آلة ري كود 00543) وقيمتها 50 جنيه في سجل الآلات والمعدات تلقائياً.",
                    actionType = "INSERT",
                    tableName = "equipment",
                    actionData = mapOf(
                        "code" to "00543",
                        "name" to "آلة ري حديثة",
                        "category" to "أدوات ري وصيانة",
                        "purchaseDate" to today,
                        "value" to "50",
                        "operatingHours" to "12"
                    )
                )
            }

            // Profiling behavior & personality insights
            trimmed.contains("بحب") || trimmed.contains("عايز") || trimmed.contains("طبيعة") -> {
                ChatResponse(
                    reply = "سجلت التفضيلات دي في ذاكرتي يا أحمد باشا! كأستاذ ومساعدك الشخصي، عيني دايماً على سلوكيات الإدارة عشان نقدر ننظم الشغل على مزاجك وبالشكل اللي يريحك. 🧠✨",
                    actionType = "INSERT",
                    tableName = "assistant_profile",
                    actionData = mapOf(
                        "personality" to "إدارة دقيقة وذكية تهتم بالتفاصيل والتوفير",
                        "jobType" to "صاحب مزرعة ومستثمر زراعي متطور",
                        "scheduleNotes" to "متابعة يومية للعمال والحسابات صباحاً ومساءً",
                        "behaviorObservations" to "يفضل الاستجابة السريعة وتقارير الأرباح المباشرة",
                        "assistantJobDescription" to "مستشار الحسابات والمخازن لأحمد باشا",
                        "lastUpdated" to today
                    )
                )
            }

            // Default warm response
            else -> {
                ChatResponse(
                    reply = "يا أحمد باشا يا غالي، أنا سامعك وسجلت كلامك وبحلله دلوقتي! قولي لو عاوز تسجل حضور عامل، أو بيعة محصول، أو عملية شراء مستلزمات، أو حتى لو عاوز ندردش في إحصائيات المزرعة ورصيد الخزينة الحالي. أنا معاك خطوة بخطوة! 🤝🌾",
                    actionType = null,
                    tableName = null,
                    actionData = null
                )
            }
        }
    }

    private fun findKeywordInMap(text: String, keywords: List<String>, default: String): String {
        for (kw in keywords) {
            if (text.contains(kw)) return kw
        }
        return default
    }

    private fun extractFirstNumber(text: String, default: Int): Int {
        val regex = "\\d+".toRegex()
        val match = regex.find(text)
        return match?.value?.toIntOrNull() ?: default
    }

    private fun parseGeminiReply(rawText: String): ChatResponse {
        return try {
            val cleaned = rawText.trim().removeSurrounding("```json", "```").trim()
            val json = JSONObject(cleaned)
            val reply = json.optString("reply", "تمام يا باشا.")
            val actionType = json.optString("actionType", "").let { if (it.isEmpty() || it == "null") null else it }
            val tableName = json.optString("tableName", "").let { if (it.isEmpty() || it == "null") null else it }
            
            val actionDataJson = json.optJSONObject("actionData")
            val actionData = if (actionDataJson != null && actionDataJson.length() > 0) {
                val map = mutableMapOf<String, String>()
                val keys = actionDataJson.keys()
                while (keys.hasNext()) {
                    val key = keys.next()
                    map[key] = actionDataJson.optString(key)
                }
                map
            } else null

            ChatResponse(reply, actionType, tableName, actionData)
        } catch (e: Exception) {
            Log.e(TAG, "Failed to parse json reply: $rawText", e)
            ChatResponse(
                reply = rawText,
                actionType = null,
                tableName = null,
                actionData = null
            )
        }
    }

    /**
     * Specialized function for AI Meeting Summarization and Report Export.
     */
    suspend fun summarizeMeeting(
        apiKey: String,
        title: String,
        attendees: String,
        rawNotes: String
    ): MeetingAIResult {
        if (apiKey.trim().isEmpty()) {
            return MeetingAIResult(
                summary = "لا يمكن تلخيص الاجتماع لعدم وجود مفتاح API.",
                actionItems = "لا توجد قرارات.",
                reportText = "يرجى تهيئة مفتاح API في الإعدادات أولاً."
            )
        }

        val systemInstruction = """
            أنت المساعد الشخصي لأحمد باشا والمستشار الإداري الذكي للمزرعة.
            مهمتك هي صياغة تقرير اجتماع احترافي وتلخيصه واستخراج قرارات وتوصيات واضحة وموزعة من مسودة الملاحظات العشوائية أو تفريغ النقاشات المسجلة للاجتماع.
            
            يجب أن تصيغ ردك بتنسيق JSON نظيف وصحيح بالبنية التالية تماماً:
            {
              "summary": "ملخص تنفيذي مركز جداً بأهم ما دار في الاجتماع والتوصيات الاستراتيجية (بالعربية الفصحى البسيطة والمهذبة والواضحة في نقاط)",
              "actionItems": "قائمة واضحة جداً بالقرارات والمهام الموزعة، كل مهمة محددة باسم الشخص المسؤول وتاريخ تسليمها إن وجد (مثال: - شراء علف مركز: أبو العلا، بحلول السبت)",
              "reportText": "تقرير شامل وكامل ومنسق بطريقة رائعة وبالمظهر الرسمي للمزرعة، يشمل: عنوان الاجتماع، التاريخ، الحاضرون، مقدمة التقرير، تفاصيل بنود المناقشات كاملة بالتفصيل الملخص الجذاب، القرارات المتخذة، والتوصيات المستقبلية. صغ هذا النص بطريقة بليغة واحترافية ممتازة ليكون جاهزاً للتصدير والمشاركة عبر واتساب أو البريد."
            }
            
            أجب بصيغة الـ JSON المحددة فقط بدون أي نصوص خارجية أو علامات Markdown مثل ```json.
        """.trimIndent()

        val fullPrompt = """
            عنوان الاجتماع: $title
            الحضور: $attendees
            تاريخ اليوم: ${java.text.SimpleDateFormat("yyyy-MM-dd", java.util.Locale.getDefault()).format(java.util.Date())}
            
            مسودة الملاحظات والنقاط التي تمت مناقشتها بالاجتماع:
            $rawNotes
        """.trimIndent()

        return try {
            val jsonRequest = JSONObject().apply {
                put("contents", org.json.JSONArray().apply {
                    put(JSONObject().apply {
                        put("parts", org.json.JSONArray().apply {
                            put(JSONObject().apply {
                                put("text", fullPrompt)
                            })
                        })
                    })
                })
                put("systemInstruction", JSONObject().apply {
                    put("parts", org.json.JSONArray().apply {
                        put(JSONObject().apply {
                            put("text", systemInstruction)
                        })
                    })
                })
                put("generationConfig", JSONObject().apply {
                    put("responseMimeType", "application/json")
                    put("temperature", 0.4)
                })
            }

            val requestBody = jsonRequest.toString().toRequestBody("application/json".toMediaType())
            val urlWithKey = "$BASE_URL?key=$apiKey"

            val request = Request.Builder()
                .url(urlWithKey)
                .post(requestBody)
                .build()

            client.newCall(request).execute().use { response ->
                val bodyString = response.body?.string()
                if (!response.isSuccessful || bodyString == null) {
                    return MeetingAIResult(
                        summary = "فشل التلخيص بسبب مشكلة في الاتصال (كود الخطأ: ${response.code})",
                        actionItems = "يرجى المحقق من اتصال الإنترنت ومفتاح الـ API.",
                        reportText = "حصل خطأ أثناء محاولة تلخيص الاجتماع بالذكاء الاصطناعي."
                    )
                }

                val jsonResponse = JSONObject(bodyString)
                val candidates = jsonResponse.optJSONArray("candidates")
                val textResponse = candidates?.optJSONObject(0)
                    ?.optJSONObject("content")
                    ?.optJSONArray("parts")
                    ?.optJSONObject(0)
                    ?.optString("text")

                if (textResponse != null) {
                    val cleaned = textResponse.trim().removeSurrounding("```json", "```").trim()
                    val resultJson = JSONObject(cleaned)
                    MeetingAIResult(
                        summary = resultJson.optString("summary", "لا يوجد ملخص."),
                        actionItems = resultJson.optString("actionItems", "لا توجد مهام."),
                        reportText = resultJson.optString("reportText", "لا يوجد تقرير.")
                    )
                } else {
                    MeetingAIResult(
                        summary = "رد فارغ من الخادم.",
                        actionItems = "لا توجد مهام.",
                        reportText = "لم يستجب الذكاء الاصطناعي بشكل صحيح."
                    )
                }
            }
        } catch (e: Exception) {
            MeetingAIResult(
                summary = "حدث استثناء أثناء الاتصال: ${e.localizedMessage}",
                actionItems = "يرجى إعادة المحاولة.",
                reportText = "تعذر توليد التقرير بسبب مشكلة في النظام."
            )
        }
    }
}

data class MeetingAIResult(
    val summary: String,
    val actionItems: String,
    val reportText: String
)

data class ChatResponse(
    val reply: String,
    val actionType: String?,
    val tableName: String?,
    val actionData: Map<String, String>?
)
