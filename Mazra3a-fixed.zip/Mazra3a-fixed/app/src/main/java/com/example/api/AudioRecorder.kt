package com.example.api

import android.content.Context
import android.media.MediaRecorder
import android.os.Build
import android.util.Log
import java.io.File

class AudioRecorder(private val context: Context) {
    private var mediaRecorder: MediaRecorder? = null
    private var audioFile: File? = null

    fun startRecording(): Boolean {
        try {
            audioFile = File(context.cacheDir, "recording_temp.3gp")
            if (audioFile?.exists() == true) {
                audioFile?.delete()
            }

            @Suppress("DEPRECATION")
            mediaRecorder = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
                MediaRecorder(context)
            } else {
                MediaRecorder()
            }.apply {
                setAudioSource(MediaRecorder.AudioSource.MIC)
                setOutputFormat(MediaRecorder.OutputFormat.THREE_GPP)
                setAudioEncoder(MediaRecorder.AudioEncoder.AMR_NB)
                setOutputFile(audioFile?.absolutePath)
                prepare()
                start()
            }
            Log.d("AudioRecorder", "🎤 تم بدء تسجيل الصوت الفعلي وحفظ الملف مؤقتاً")
            return true
        } catch (e: Exception) {
            Log.e("AudioRecorder", "❌ فشل بدء تسجيل الصوت", e)
            mediaRecorder = null
            return false
        }
    }

    fun stopRecording(): File? {
        try {
            mediaRecorder?.apply {
                stop()
                release()
            }
        } catch (e: Exception) {
            Log.e("AudioRecorder", "⚠️ خطأ أثناء إيقاف التسجيل", e)
        } finally {
            mediaRecorder = null
        }
        return if (audioFile?.exists() == true) audioFile else null
    }
}
