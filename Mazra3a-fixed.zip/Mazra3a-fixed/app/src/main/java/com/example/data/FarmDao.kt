package com.example.data

import androidx.room.*
import kotlinx.coroutines.flow.Flow

@Dao
interface FarmDao {

    // --- Land ---
    @Query("SELECT * FROM land ORDER BY code ASC")
    fun getAllLands(): Flow<List<Land>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertLand(land: Land)

    @Delete
    suspend fun deleteLand(land: Land)

    @Query("DELETE FROM land WHERE code = :code")
    suspend fun deleteLandByCode(code: String)

    // --- Crops ---
    @Query("SELECT * FROM crops ORDER BY code ASC")
    fun getAllCrops(): Flow<List<Crop>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertCrop(crop: Crop)

    @Delete
    suspend fun deleteCrop(crop: Crop)

    @Query("DELETE FROM crops WHERE code = :code")
    suspend fun deleteCropByCode(code: String)

    // --- Operations ---
    @Query("SELECT * FROM operations ORDER BY date DESC, id DESC")
    fun getAllOperations(): Flow<List<Operation>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertOperation(operation: Operation)

    @Delete
    suspend fun deleteOperation(operation: Operation)

    // --- Inventory ---
    @Query("SELECT * FROM inventory ORDER BY code ASC")
    fun getAllInventoryItems(): Flow<List<InventoryItem>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertInventoryItem(item: InventoryItem)

    @Delete
    suspend fun deleteInventoryItem(item: InventoryItem)

    @Query("DELETE FROM inventory WHERE code = :code")
    suspend fun deleteInventoryItemByCode(code: String)

    // --- Inventory Movement ---
    @Query("SELECT * FROM inventory_movement ORDER BY date DESC, id DESC")
    fun getAllInventoryMovements(): Flow<List<InventoryMovement>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertInventoryMovement(movement: InventoryMovement)

    @Delete
    suspend fun deleteInventoryMovement(movement: InventoryMovement)

    // --- Animals ---
    @Query("SELECT * FROM animals ORDER BY code ASC")
    fun getAllAnimals(): Flow<List<Animal>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertAnimal(animal: Animal)

    @Delete
    suspend fun deleteAnimal(animal: Animal)

    @Query("DELETE FROM animals WHERE code = :code")
    suspend fun deleteAnimalByCode(code: String)

    // --- Animal Production ---
    @Query("SELECT * FROM animal_production ORDER BY date DESC, id DESC")
    fun getAllAnimalProduction(): Flow<List<AnimalProduction>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertAnimalProduction(production: AnimalProduction)

    @Delete
    suspend fun deleteAnimalProduction(production: AnimalProduction)

    // --- Workers ---
    @Query("SELECT * FROM workers ORDER BY code ASC")
    fun getAllWorkers(): Flow<List<Worker>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertWorker(worker: Worker)

    @Delete
    suspend fun deleteWorker(worker: Worker)

    @Query("DELETE FROM workers WHERE code = :code")
    suspend fun deleteWorkerByCode(code: String)

    // --- Attendance ---
    @Query("SELECT * FROM attendance ORDER BY date DESC, id DESC")
    fun getAllAttendance(): Flow<List<Attendance>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertAttendance(attendance: Attendance)

    @Delete
    suspend fun deleteAttendance(attendance: Attendance)

    // --- Contacts ---
    @Query("SELECT * FROM contacts ORDER BY code ASC")
    fun getAllContacts(): Flow<List<Contact>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertContact(contact: Contact)

    @Delete
    suspend fun deleteContact(contact: Contact)

    @Query("DELETE FROM contacts WHERE code = :code")
    suspend fun deleteContactByCode(code: String)

    // --- Equipment ---
    @Query("SELECT * FROM equipment ORDER BY code ASC")
    fun getAllEquipment(): Flow<List<Equipment>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertEquipment(equipment: Equipment)

    @Delete
    suspend fun deleteEquipment(equipment: Equipment)

    @Query("DELETE FROM equipment WHERE code = :code")
    suspend fun deleteEquipmentByCode(code: String)

    // --- Maintenance ---
    @Query("SELECT * FROM maintenance ORDER BY date DESC, id DESC")
    fun getAllMaintenanceLogs(): Flow<List<Maintenance>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertMaintenanceLog(maintenance: Maintenance)

    @Delete
    suspend fun deleteMaintenanceLog(maintenance: Maintenance)

    // --- Water ---
    @Query("SELECT * FROM water ORDER BY date DESC, id DESC")
    fun getAllWaterLogs(): Flow<List<WaterLog>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertWaterLog(waterLog: WaterLog)

    @Delete
    suspend fun deleteWaterLog(waterLog: WaterLog)

    // --- Purchases ---
    @Query("SELECT * FROM purchases ORDER BY date DESC, id DESC")
    fun getAllPurchases(): Flow<List<Purchase>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertPurchase(purchase: Purchase)

    @Delete
    suspend fun deletePurchase(purchase: Purchase)

    // --- Sales ---
    @Query("SELECT * FROM sales ORDER BY date DESC, id DESC")
    fun getAllSales(): Flow<List<Sale>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertSale(sale: Sale)

    @Delete
    suspend fun deleteSale(sale: Sale)

    // --- Treasury ---
    @Query("SELECT * FROM treasury ORDER BY date DESC, id DESC")
    fun getAllTreasuryTransactions(): Flow<List<TreasuryTransaction>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertTreasuryTransaction(transaction: TreasuryTransaction)

    @Delete
    suspend fun deleteTreasuryTransaction(transaction: TreasuryTransaction)

    // --- Debts ---
    @Query("SELECT * FROM debts ORDER BY dueDate DESC, id DESC")
    fun getAllDebts(): Flow<List<Debt>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertDebt(debt: Debt)

    @Delete
    suspend fun deleteDebt(debt: Debt)

    // --- Assistant Profile ---
    @Query("SELECT * FROM assistant_profile WHERE id = 1 LIMIT 1")
    fun getAssistantProfile(): Flow<AssistantProfile?>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertAssistantProfile(profile: AssistantProfile)

    // --- Meetings ---
    @Query("SELECT * FROM meetings ORDER BY date DESC, id DESC")
    fun getAllMeetings(): Flow<List<Meeting>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertMeeting(meeting: Meeting)

    @Delete
    suspend fun deleteMeeting(meeting: Meeting)

    @Query("DELETE FROM meetings WHERE id = :id")
    suspend fun deleteMeetingById(id: Int)

    // --- Ahmed Preferences ---
    @Query("SELECT * FROM ahmed_preferences ORDER BY id DESC")
    fun getAllPreferences(): Flow<List<AhmedPreference>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertPreference(preference: AhmedPreference)

    @Delete
    suspend fun deletePreference(preference: AhmedPreference)

    @Query("DELETE FROM ahmed_preferences WHERE id = :id")
    suspend fun deletePreferenceById(id: Int)

    // --- Interaction Logs ---
    @Query("SELECT * FROM interaction_logs ORDER BY timestamp DESC, id DESC")
    fun getAllInteractionLogs(): Flow<List<InteractionLog>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertInteractionLog(log: InteractionLog)

    @Delete
    suspend fun deleteInteractionLog(log: InteractionLog)

    @Query("DELETE FROM interaction_logs")
    suspend fun clearInteractionLogs()
}
