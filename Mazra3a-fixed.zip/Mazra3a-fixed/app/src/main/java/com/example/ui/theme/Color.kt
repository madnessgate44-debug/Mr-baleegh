package com.example.ui.theme

import androidx.compose.ui.graphics.Color

// Light Theme Colors (Urban Futuristic Agriculture)
val FarmPrimary = Color(0xFF10B981) // Vibrant Energetic Emerald Green
val FarmPrimaryContainer = Color(0xFFECFDF5) // Very soft mint/white green container
val FarmSecondary = Color(0xFF059669) // Deep modern green
val FarmTertiary = Color(0xFF3B82F6) // Futuristic clean electric blue
val FarmBackground = Color(0xFFFFFFFF) // Pure clean white background across all screens
val FarmSurface = Color(0xFFFFFFFF) // Pure white surface

// Force white backgrounds even for dark theme fallback to eliminate all dark canvases
val FarmPrimaryDark = Color(0xFF10B981)
val FarmPrimaryContainerDark = Color(0xFFECFDF5)
val FarmSecondaryDark = Color(0xFF059669)
val FarmTertiaryDark = Color(0xFF3B82F6)
val FarmBackgroundDark = Color(0xFFFFFFFF)
val FarmSurfaceDark = Color(0xFFFFFFFF)
val FarmOnSurfaceDark = Color(0xFF111827)


