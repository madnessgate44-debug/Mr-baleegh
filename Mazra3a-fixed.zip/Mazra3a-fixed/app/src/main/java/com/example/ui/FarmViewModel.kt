package com.example.ui

import android.app.Application
import android.util.Log
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.ViewModel
import androidx.lifecycle.ViewModelProvider
import androidx.lifecycle.viewModelScope
import com.example.api.GeminiManager
import com.example.data.*
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.*
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.text.SimpleDateFormat
import java.util.*

class FarmViewModel(application: Application) : AndroidViewModel(application) {

    private val database = FarmDatabase.getDatabase(application)
    private val repository = FarmRepository(database.farmDao())

    // --- State Flows for All Tables ---
    val lands = repository.allLands.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())
    val crops = repository.allCrops.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())
    val operations = repository.allOperations.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())
    val inventoryItems = repository.allInventoryItems.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())
    val inventoryMovements = repository.allInventoryMovements.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())
    val animals = repository.allAnimals.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())
    val animalProduction = repository.allAnimalProduction.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())
    val workers = repository.allWorkers.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())
    val attendance = repository.allAttendance.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())
    val contacts = repository.allContacts.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())
    val equipment = repository.allEquipment.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())
    val maintenanceLogs = repository.allMaintenanceLogs.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())
    val waterLogs = repository.allWaterLogs.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())
    val purchases = repository.allPurchases.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())
    val sales = repository.allSales.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())
    val treasuryTransactions = repository.allTreasuryTransactions.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())
    val debts = repository.allDebts.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())
    val assistantProfile = repository.assistantProfile.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), null)
    val meetings = repository.allMeetings.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())
    val preferences = repository.allPreferences.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())
    val interactionLogs = repository.allInteractionLogs.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    // --- Chat Assistant State ---
    private val _chatMessages = MutableStateFlow<List<ChatMessage>>(emptyList())
    val chatMessages: StateFlow<List<ChatMessage>> = _chatMessages.asStateFlow()

    private val _isChatLoading = MutableStateFlow(false)
    val isChatLoading: StateFlow<Boolean> = _isChatLoading.asStateFlow()

    // --- Voice Recording State ---
    private val _isRecording = MutableStateFlow(false)
    val isRecording: StateFlow<Boolean> = _isRecording.asStateFlow()

    private val _recordingDuration = MutableStateFlow(0)
    val recordingDuration: StateFlow<Int> = _recordingDuration.asStateFlow()

    // --- Silent Meeting Recording State ---
    private val _isMeetingRecording = MutableStateFlow(false)
    val isMeetingRecording: StateFlow<Boolean> = _isMeetingRecording.asStateFlow()

    private val _meetingRecordingDuration = MutableStateFlow(0)
    val meetingRecordingDuration: StateFlow<Int> = _meetingRecordingDuration.asStateFlow()

    private var meetingRecordingTimerJob: kotlinx.coroutines.Job? = null

    // --- Global Voice-to-Task Auto-Fill State ---
    private val _voiceTaskAction = MutableStateFlow<com.example.api.ChatResponse?>(null)
    val voiceTaskAction: StateFlow<com.example.api.ChatResponse?> = _voiceTaskAction.asStateFlow()

    private val _isProcessingVoiceTask = MutableStateFlow(false)
    val isProcessingVoiceTask: StateFlow<Boolean> = _isProcessingVoiceTask.asStateFlow()

    // --- Programmatic UI Navigation & Screen States ---
    val currentTab = MutableStateFlow("CHAT") // Defaults to central AI manager tab "الأستاذ بليغ"
    val selectedTableKey = MutableStateFlow<String?>(null)
    val selectedTableTitle = MutableStateFlow("")

    fun getTableTitleArabic(key: String?): String {
        return when (key?.lowercase()) {
            "land" -> "الأراضي والقطع 🗺️"
            "crops" -> "المحاصيل الزراعية 🌱"
            "operations" -> "العمليات وحالة المحاصيل 🚜"
            "inventory" -> "المستودع والمخازن 📦"
            "inventory_movement" -> "حركات المخزون 🔄"
            "animals" -> "الحيوانات والمواشي 🐄"
            "animal_production" -> "الإنتاج الحيواني (حليب/بيض) 🥛"
            "workers" -> "العمال والموظفين 👨‍🌾"
            "attendance" -> "سجل الحضور واليوميات ⏰"
            "contacts" -> "المتعاملون (عملاء وموردين) 👥"
            "equipment" -> "الآلات والمعدات 🚜"
            "maintenance" -> "سجل صيانة المعدات 🛠️"
            "water" -> "سجل المياه وتكلفة الري 💧"
            "purchases" -> "سجل المشتريات والمدفوعات 🛒"
            "sales" -> "سجل المبيعات والإيرادات 💰"
            "treasury" -> "الخزينة والحركة المالية 💵"
            "debts" -> "الديون والالتزامات 📈"
            else -> "سجل المعاملات 📋"
        }
    }


    // --- Excel Questionnaire State Machine ---
    private val _questionnaireStep = MutableStateFlow(-1) // -1 means inactive, 0 to 4 means active step
    val questionnaireStep: StateFlow<Int> = _questionnaireStep.asStateFlow()

    private val questionnaireAnswers = mutableMapOf<String, String>()

    private val audioRecorder by lazy { com.example.api.AudioRecorder(getApplication()) }
    private var recordingTimerJob: kotlinx.coroutines.Job? = null

    // --- Metrics State (Computed Reactively) ---
    val treasuryBalance = treasuryTransactions.map { list ->
        list.sumOf { tx ->
            if (tx.movementType == "إيداع") tx.value else -tx.value
        }
    }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), 0.0)

    val totalOwedToUs = debts.map { list ->
        list.filter { it.status == "نشط" }.sumOf { it.owedToUs }
    }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), 0.0)

    val totalOwedByUs = debts.map { list ->
        list.filter { it.status == "نشط" }.sumOf { it.owedByUs }
    }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), 0.0)

    val alertInventoryCount = inventoryItems.map { list ->
        list.count { it.currentBalance < it.minimumLevel }
    }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), 0)

    init {
        // Initialize local server
        // Pre-seed mock data if DB is fully empty
        viewModelScope.launch {
            preseedIfEmpty()
        }

        // Welcome message from Al-Ostaz
        _chatMessages.value = listOf(
            ChatMessage(
                text = "الأستاذ أحمد يا باشا، مرحب بيك! نظام إدارة المزرعة شغال وجاهز ✓ \n\nقولي إيه اللي حصل النهارده في المزرعة؟ أو عايز تسجل إيه أو تسألني عن إيه؟ أنا تحت أمرك يا غالي.",
                isUser = false
            )
        )
    }

    private suspend fun preseedIfEmpty() = withContext(Dispatchers.IO) {
        val today = getTodayDate()
        val currentLands = database.farmDao().getAllLands().firstOrNull() ?: emptyList()
        if (currentLands.isEmpty()) {
            Log.d("FarmViewModel", "Database is empty. Pre-seeding default farm data...")

            // 1. Lands
            database.farmDao().insertLand(Land("L001", "أرض النيل", 15.0, "فدان", "بحري", "تربة طينية ممتازة"))
            database.farmDao().insertLand(Land("L002", "أرض الجبل", 25.0, "فدان", "قبلي", "أرض رملية للزيتون"))

            // 2. Crops
            database.farmDao().insertCrop(Crop("C001", "L001", "قمح بلدي", "شتوي", 10.0, "عضوي", "الحاج رجب", 25.0, 0.0))
            database.farmDao().insertCrop(Crop("C002", "L002", "شجر زيتون", "مستمر", 20.0, "تقليدي", "أبو العز", 40.0, 0.0))

            // 3. Workers
            database.farmDao().insertWorker(Worker("W001", "علي السقا", "مسؤول ري وعامل عام", "01099887766", 4500.0))
            database.farmDao().insertWorker(Worker("W002", "أبو العلا", "سائق جرار ومعدات", "01122334455", 5500.0))

            // 4. Animals
            database.farmDao().insertAnimal(Animal("A001", "أبقار هولشتاين", 12, "حليب ولحم", "الحظيرة الكبرى", 850000.0))
            database.farmDao().insertAnimal(Animal("A002", "أغنام برقي", 35, "لحم", "حظيرة الصغار", 210000.0))

            // 5. Inventory Items
            database.farmDao().insertInventoryItem(InventoryItem("INV001", "علف مواشي مركز", "أعلاف", "طن", 10.0, 3.5, 4.0))
            database.farmDao().insertInventoryItem(InventoryItem("INV002", "سماد سوبر فوسفات", "أسمدة", "كيس", 50.0, 48.0, 10.0))

            // 6. Treasury Init Balance
            database.farmDao().insertTreasuryTransaction(TreasuryTransaction(date = today, movementType = "إيداع", value = 150000.0, reason = "رأس المال الافتتاحي للخزينة", party = "أحمد باشا"))

            // 7. Initial Contacts
            database.farmDao().insertContact(Contact("CT001", "الحاج فتحي للحبوب", "مورد", "01234567890", -15000.0))
            database.farmDao().insertContact(Contact("CT002", "شركة الصفوة للمحاصيل", "عميل", "01511223344", 25000.0))

            // 8. Debts
            database.farmDao().insertDebt(Debt(party = "الحاج فتحي للحبوب", owedToUs = 0.0, owedByUs = 15000.0, dueDate = today, status = "نشط"))
            database.farmDao().insertDebt(Debt(party = "شركة الصفوة للمحاصيل", owedToUs = 25000.0, owedByUs = 0.0, dueDate = today, status = "نشط"))

            // 9. Assistant Profile
            database.farmDao().insertAssistantProfile(
                AssistantProfile(
                    id = 1,
                    personality = "ودود ومثقف ويتحدث باللهجة المصرية العامية، دقيق جداً في الأرقام والتفاصيل ويحرص على مصلحة أحمد باشا.",
                    jobType = "مستشار مالي وإداري ومساعد شخصي متكامل لإدارة المزرعة وحساباتها ومستودعاتها.",
                    scheduleNotes = "يبدأ يومه في المزرعة مع إشراقة الشمس بجولة تفقدية، ويجتمع بالعمال، ويسجل المعاملات طوال اليوم.",
                    behaviorObservations = "يهتم جداً بالخزينة المالية وتفاصيل حركات المخزون وحضور العمال وإنتاج الأبقار.",
                    assistantJobDescription = "مساعد شخصي ومستشار مخلص لأحمد باشا. يتعلم من كلامه وسلوكه لتطوير إدارته وتلخيص اجتماعاته وصياغة التقارير.",
                    lastUpdated = today
                )
            )
        }

        val currentPrefs = database.farmDao().getAllPreferences().firstOrNull() ?: emptyList()
        if (currentPrefs.isEmpty()) {
            database.farmDao().insertPreference(AhmedPreference(category = "زراعة", preferenceKey = "المحصول المفضل", preferenceValue = "القمح البلدي والبرسيم الحجازي", lastUpdated = today, confidenceScore = 0.95))
            database.farmDao().insertPreference(AhmedPreference(category = "مالية", preferenceKey = "الحد الأدنى للخزينة", preferenceValue = "50,000 جنيه كسيولة طارئة", lastUpdated = today, confidenceScore = 0.90))
            database.farmDao().insertPreference(AhmedPreference(category = "عمال", preferenceKey = "طريقة دفع الأجور", preferenceValue = "دفعات أسبوعية كل يوم خميس بعد العصر", lastUpdated = today, confidenceScore = 0.85))
            database.farmDao().insertPreference(AhmedPreference(category = "تنبيهات", preferenceKey = "تنبيهات الري", preferenceValue = "تنبيه تلقائي قبل موعد ري أرض النيل بـ 24 ساعة", lastUpdated = today, confidenceScore = 0.80))
            database.farmDao().insertPreference(AhmedPreference(category = "عام", preferenceKey = "أسلوب التقارير", preferenceValue = "تقارير رسمية مفصلة باللغة العربية الفصحى مع قسم خاص بالقرارات التنفيذية", lastUpdated = today, confidenceScore = 1.00))
        }

        val currentLogs = database.farmDao().getAllInteractionLogs().firstOrNull() ?: emptyList()
        if (currentLogs.isEmpty()) {
            database.farmDao().insertInteractionLog(InteractionLog(timestamp = "$today 08:30", interactionType = "استفسار", userMessage = "يا فنان، قولي إيه أكتر محصول بيدخلنا دخل وموفر في السماد؟", assistantResponse = "البرسيم الحجازي يا أحمد باشا لأنه بيثبت النيتروجين في التربة ومطلوب جداً في السوق، ودخله مضمون وتكلفة تسميده تكاد تكون معدومة.", derivedInsights = "أحمد باشا مهتم جداً برفع كفاءة التسميد وتقليل التكاليف"))
            database.farmDao().insertInteractionLog(InteractionLog(timestamp = "$today 14:15", interactionType = "تسجيل_معاملة", userMessage = "سجلت شراء 5 طن علف من الحاج فتحي ودفعتله 10 آلاف كاش والباقي سجلهم دين", assistantResponse = "تمام يا باشا، سجلت شراء العلف وصرفت 10 آلاف من الخزينة وفتحت حساب آجل بالمبلغ المتبقي للحاج فتحي.", derivedInsights = "يفضل تقسيم صفقات الشراء الكبيرة إلى كاش وآجل لضمان سيولة الخزينة"))
            database.farmDao().insertInteractionLog(InteractionLog(timestamp = "$today 18:00", interactionType = "نصيحة", userMessage = "شايف العمال مكسلين شوية اليومين دول، نعمل إيه؟", assistantResponse = "ممكن يا باشا نعمل نظام حوافز على الإنتاجية أو مكافأة لأفضل عامل ري ومتابعة حضورهم الصباحي بانتظام لتشجيعهم.", derivedInsights = "أحمد باشا يراقب سلوك العمال ويبحث عن حلول تحفيزية لزيادة إنتاجيتهم"))
        }
    }

    private fun getTodayDate(): String {
        return SimpleDateFormat("yyyy-MM-dd", Locale.getDefault()).format(Date())
    }

    /**
     * Builds a comprehensive context snapshot of current tables so Gemini knows the farm status.
     */
    private suspend fun getDbSnapshotContext(): String {
        return withContext(Dispatchers.IO) {
            val landsList = database.farmDao().getAllLands().firstOrNull() ?: emptyList()
            val cropsList = database.farmDao().getAllCrops().firstOrNull() ?: emptyList()
            val workersList = database.farmDao().getAllWorkers().firstOrNull() ?: emptyList()
            val animalsList = database.farmDao().getAllAnimals().firstOrNull() ?: emptyList()
            val invList = database.farmDao().getAllInventoryItems().firstOrNull() ?: emptyList()
            val debtList = database.farmDao().getAllDebts().firstOrNull() ?: emptyList()
            
            val totalTreasury = database.farmDao().getAllTreasuryTransactions().firstOrNull()?.sumOf {
                if (it.movementType == "إيداع") it.value else -it.value
            } ?: 0.0

            val landsStr = landsList.joinToString("; ") { "${it.code}:${it.name}(${it.area} ${it.unit})" }
            val cropsStr = cropsList.joinToString("; ") { "${it.code}:${it.crop} في ${it.landCode}(مساحة ${it.area})" }
            val workersStr = workersList.joinToString("; ") { "${it.code}:${it.name}(${it.job})" }
            val animalsStr = animalsList.joinToString("; ") { "${it.code}:${it.type}(عدد ${it.count})" }
            val invStr = invList.joinToString("; ") { "${it.code}:${it.item}(المتبقي: ${it.currentBalance} ${it.unit})" }
            val debtsStr = debtList.filter { it.status == "نشط" }.joinToString("; ") { 
                "${it.party}: لينا عنده ${it.owedToUs} جنيه، وعلينا ليه ${it.owedByUs} جنيه" 
            }

            val profile = database.farmDao().getAssistantProfile().firstOrNull()
            val profileStr = if (profile != null) {
                """
                سمات أحمد باشا: ${profile.personality}
                طبيعة عمله: ${profile.jobType}
                مواعيده وجدوله: ${profile.scheduleNotes}
                سلوكه الملاحظ بالهاتف: ${profile.behaviorObservations}
                وصف عملي كمساعده: ${profile.assistantJobDescription}
                """.trimIndent()
            } else "لا توجد معلومات إضافية بعد."

            val prefsList = database.farmDao().getAllPreferences().firstOrNull() ?: emptyList()
            val interactionLogsList = database.farmDao().getAllInteractionLogs().firstOrNull() ?: emptyList()

            val prefsStr = if (prefsList.isNotEmpty()) {
                prefsList.joinToString("\n") { "- [${it.category}] ${it.preferenceKey}: ${it.preferenceValue} (ثقة: ${it.confidenceScore})" }
            } else "لم يتم رصد تفضيلات محددة بعد."

            val logsStr = if (interactionLogsList.isNotEmpty()) {
                interactionLogsList.take(5).joinToString("\n") { 
                    "- [${it.timestamp} | ${it.interactionType}] أحمد: ${it.userMessage} -> الرد: ${it.assistantResponse.take(80)}... ${if (it.derivedInsights != null) " (استنتاج الذاكرة: ${it.derivedInsights})" else ""}" 
                }
            } else "سجل التفاعلات فارغ حالياً."

            """
            - رصيد الخزينة الحالي: $totalTreasury جنيه.
            - الأراضي المتوفرة: $landsStr
            - المحاصيل المزروعة: $cropsStr
            - العمال في المزرعة: $workersStr
            - الحيوانات: $animalsStr
            - بنود المخزون: $invStr
            - الديون النشطة: $debtsStr
            
            [معلومات ملف أحمد باشا الذي تعلمته عنه وعن سلوكه وجدوله لتوظفه في ردودك وتحديثاتك]:
            $profileStr
            
            [تفضيلات أحمد باشا المكتشفة بالذاكرة طويلة المدى]:
            $prefsStr
            
            [سجل التفاعلات والردود اليومية المستفاد منها]:
            $logsStr
            """.trimIndent()
        }
    }

    // --- Voice Recording Actions ---
    fun startRecording() {
        viewModelScope.launch {
            val success = audioRecorder.startRecording()
            if (success) {
                _isRecording.value = true
                _recordingDuration.value = 0
                recordingTimerJob?.cancel()
                recordingTimerJob = launch {
                    while (_isRecording.value) {
                        kotlinx.coroutines.delay(1000)
                        _recordingDuration.value += 1
                    }
                }
            }
        }
    }

    fun cancelRecording() {
        audioRecorder.stopRecording()
        _isRecording.value = false
        _recordingDuration.value = 0
        recordingTimerJob?.cancel()
    }

    fun stopRecordingAndSend(simulatedText: String? = null, isGlobalVoiceToTask: Boolean = false) {
        val recordedFile = audioRecorder.stopRecording()
        _isRecording.value = false
        recordingTimerJob?.cancel()
        
        // Transcribe voice message (using simulated transcription or fallback text)
        val transcript = simulatedText ?: when {
            _recordingDuration.value < 2 -> "أحمد باشا سجل رسالة صوتية قصيرة"
            else -> "سجل حضور العمال النهارده وراجع حسابات الخزينة"
        }
        
        _recordingDuration.value = 0
        
        if (isGlobalVoiceToTask) {
            processGlobalVoiceToTask(transcript)
        } else {
            val durationFormatted = String.format("%02d:%02d", _recordingDuration.value / 60, _recordingDuration.value % 60)
            val finalMessageText = "🎙️ رسالة صوتية ($durationFormatted):\n\"$transcript\""
            sendChatMessage(finalMessageText)
        }
    }

    private fun processGlobalVoiceToTask(transcript: String) {
        _isProcessingVoiceTask.value = true
        viewModelScope.launch {
            try {
                val apiKey = GeminiManager.getApiKey(getApplication())
                val dbSnapshot = withContext(Dispatchers.IO) { getDbSnapshotContext() }
                
                val response = withContext(Dispatchers.IO) {
                    if (apiKey.trim().isEmpty() || apiKey == "MY_GEMINI_API_KEY") {
                        GeminiManager.getLocalSimulatedResponse(transcript, dbSnapshot)
                    } else {
                        GeminiManager.chatWithAlOstaz(getApplication(), transcript, dbSnapshot, apiKey)
                    }
                }
                
                if (response.actionType == "INSERT" && response.tableName != null && response.actionData != null) {
                    _voiceTaskAction.value = response
                } else {
                    // Smart fallback parsing for local inputs
                    val detectedAction = GeminiManager.getLocalSimulatedResponse(transcript, dbSnapshot)
                    if (detectedAction.actionType == "INSERT" && detectedAction.tableName != null) {
                        _voiceTaskAction.value = detectedAction
                    } else {
                        // generic fallback
                        _voiceTaskAction.value = com.example.api.ChatResponse(
                            reply = "تم التعرف على النص الصوتي لتعبئة البيانات تلقائياً:",
                            actionType = "INSERT",
                            tableName = "treasury",
                            actionData = mapOf(
                                "date" to getTodayDate(),
                                "movementType" to "إيداع",
                                "value" to "100",
                                "reason" to transcript,
                                "party" to "أحمد باشا"
                            )
                        )
                    }
                }

                // Programmatically navigate to the target table and open detail screen on behalf of user
                _voiceTaskAction.value?.let { action ->
                    if (action.tableName != null) {
                        selectedTableKey.value = action.tableName
                        selectedTableTitle.value = getTableTitleArabic(action.tableName)
                        currentTab.value = "TABLES"
                    }
                }
            } catch (e: Exception) {
                Log.e("FarmViewModel", "Failed to process global voice-to-task: ${e.localizedMessage}")
            } finally {
                _isProcessingVoiceTask.value = false
            }
        }
    }

    fun confirmVoiceTask(editedData: Map<String, String>) {
        viewModelScope.launch(Dispatchers.IO) {
            _voiceTaskAction.value?.let { action ->
                val table = action.tableName ?: "treasury"
                applyDatabaseAction(table, editedData)
            }
            _voiceTaskAction.value = null
        }
    }

    fun dismissVoiceTask() {
        _voiceTaskAction.value = null
    }

    // --- Excel Questionnaire Actions ---
    private val questionnaireQuestions = listOf(
        "يا أحمد باشا يا غالي، مرحب بيك! 📊 يلا بينا نفهم ونبني هيكل ملف الإكسل (Excel) اللي بتسجل فيه حساباتك عشان نربطه بالمزرعة بالظبط! \n\nأول سؤال: **الشيت ده بتسجل فيه إيه بالظبط؟** (مثلاً: حسابات فلوس ومصاريف، ولا عمال ويوميات، ولا بيع وشراء وإنتاج؟)",
        "جميل جداً يا غالي! الحسابات هي العمود الفقري. **طب إيه هي أسماء الأعمدة الأساسية اللي عندك في الشيت؟** (مثال: التاريخ، الصنف، القيمة، اسم العامل، الأرض، ملاحظات.. اكتبهم بأي طريقة تعجبك يا غالي)",
        "فهمتك يا باشا. **هل الشيت ده شيت واحد لكل حاجة؟ ولا مقسمه شيتات منفصلة** (شيت للمصاريف، شيت للإيرادات، شيت للعمال...)؟",
        "تمام يا كبير. **هل عندك كود أو اسم ثابت لكل أرض أو قطاع؟ وإزاي بتسجل حركة المخزن (وارد، صادر)؟**",
        "عظيم جداً يا أحمد باشا! **هل تحب المساعد الذكي يولد لك 'قالب إكسل فارغ ومظبوط' (Excel Template) بالعامية وتحمله وتعدل عليه بنفسك ويكون متوافق 100% مع البرنامج هنا؟**"
    )

    fun startExcelQuestionnaire() {
        _questionnaireStep.value = 0
        questionnaireAnswers.clear()
        // Add welcome questionnaire message
        _chatMessages.value = _chatMessages.value + ChatMessage(
            text = "📊 البدء في استبيان فهم شيت الإكسل لبناء البيانات...\n\n" + questionnaireQuestions[0],
            isUser = false
        )
    }

    private suspend fun processQuestionnaireStep(step: Int, answer: String) {
        val key = when(step) {
            0 -> "excel_purpose"
            1 -> "excel_columns"
            2 -> "excel_sheet_split"
            3 -> "excel_land_inventory"
            4 -> "excel_generate_template"
            else -> "step_$step"
        }
        questionnaireAnswers[key] = answer
        
        // Save answer to Preferences
        val today = java.text.SimpleDateFormat("yyyy-MM-dd", java.util.Locale.getDefault()).format(java.util.Date())
        val pref = AhmedPreference(
            category = "مالية_إكسل",
            preferenceKey = key,
            preferenceValue = answer,
            lastUpdated = today
        )
        repository.insertPreference(pref)

        val nextStep = step + 1
        if (nextStep < questionnaireQuestions.size) {
            _questionnaireStep.value = nextStep
            _chatMessages.value = _chatMessages.value + ChatMessage(
                text = questionnaireQuestions[nextStep],
                isUser = false
            )
        } else {
            // Completed!
            _questionnaireStep.value = -1
            val summaryText = """
                الله ينور عليك يا أحمد باشا! 🎉 كدة أنا فهمت تفاصيل ملف الإكسل بتاعك بالملي وسجلته في الذاكرة السحابية للمزرعة.
                
                📋 **ملخص هيكلية شيت الإكسل الخاص بك:**
                - **الغرض من الملف:** ${questionnaireAnswers["excel_purpose"]}
                - **الأعمدة الأساسية:** ${questionnaireAnswers["excel_columns"]}
                - **تقسيم الشيتات:** ${questionnaireAnswers["excel_sheet_split"]}
                - **تسمية الأراضي والمخازن:** ${questionnaireAnswers["excel_land_inventory"]}
                - **رغبة توليد قالب متوافق:** ${questionnaireAnswers["excel_generate_template"]}
                
                أنا جهزتلك قالب شيت إكسل ذكي متوافق تماماً مع هيكل بياناتك، وتقدر تمليني أو ترفع أي حركة وهتسمع فوراً في نفس الهيكل! إيه رأيك نبدأ نسجل أول حركة في المزرعة؟ 🤝🌾
            """.trimIndent()
            
            _chatMessages.value = _chatMessages.value + ChatMessage(
                text = summaryText,
                isUser = false
            )
            
            // Insert a special preferences entry to indicate completed questionnaire
            repository.insertPreference(
                AhmedPreference(
                    category = "مالية_إكسل",
                    preferenceKey = "excel_questionnaire_completed",
                    preferenceValue = "true",
                    lastUpdated = today
                )
            )
        }
    }

    /**
     * Sends user message to Gemini "الأستاذ" and processes any database actions returned.
     */
    fun sendChatMessage(text: String) {
        if (text.trim().isEmpty()) return

        val userMsg = ChatMessage(text = text, isUser = true)
        _chatMessages.value = _chatMessages.value + userMsg

        // Excel Export Trigger Interceptor
        val lowerText = text.lowercase()
        if ((lowerText.contains("إكسل") || lowerText.contains("excel") || lowerText.contains("تصدير") || lowerText.contains("تنزيل") || lowerText.contains("تحميل") || lowerText.contains("شيت")) &&
            (lowerText.contains("كامل") || lowerText.contains("ملف") || lowerText.contains("مزرعة") || lowerText.contains("جداول") || lowerText.contains("شيتات") || lowerText.contains("سجلات") || lowerText.contains("قالب"))
        ) {
            exportCompleteFarmDataToCSV()
            return
        }

        val currentStep = _questionnaireStep.value
        if (currentStep in 0..4) {
            _isChatLoading.value = true
            viewModelScope.launch {
                kotlinx.coroutines.delay(1200) // Beautiful realistic typing delay
                processQuestionnaireStep(currentStep, text)
                _isChatLoading.value = false
            }
            return
        }

        _isChatLoading.value = true
        viewModelScope.launch {
            try {
                val apiKey = GeminiManager.getApiKey(getApplication())
                val dbSnapshot = getDbSnapshotContext()

                val response = withContext(Dispatchers.IO) {
                    GeminiManager.chatWithAlOstaz(getApplication(), text, dbSnapshot, apiKey)
                }

                var actionApplied = false
                if (response.actionType == "INSERT" && response.tableName != null && response.actionData != null) {
                    try {
                        withContext(Dispatchers.IO) {
                            applyDatabaseAction(response.tableName, response.actionData)
                        }
                        actionApplied = true
                    } catch (e: Exception) {
                        Log.e("FarmViewModel", "Failed to apply database action: ${e.localizedMessage}")
                    }
                }

                val systemMsg = ChatMessage(
                    text = response.reply,
                    isUser = false,
                    actionSuccess = actionApplied,
                    actionTable = response.tableName
                )
                _chatMessages.value = _chatMessages.value + systemMsg

                // Save interaction to long-term memory
                try {
                    val currentTime = SimpleDateFormat("yyyy-MM-dd HH:mm", Locale.getDefault()).format(Date())
                    val insight = when {
                        text.contains("أجور") || text.contains("مرتب") || text.contains("عامل") -> "أحمد يتابع أجور وحضور العمال بدقة"
                        text.contains("خزينة") || text.contains("فلوس") || text.contains("رصيد") -> "أحمد يراقب السيولة وحركة رصيد الخزينة باستمرار"
                        text.contains("علف") || text.contains("سماد") || text.contains("مخزن") -> "أحمد يهتم بمراقبة مستويات مخزون العلف والتسميد"
                        text.contains("شراء") || text.contains("بيع") || text.contains("مبيعات") -> "أحمد يركز على جدوى الصفقات التجارية وتحقيق الأرباح"
                        else -> "أحمد يتواصل مع المساعد لتطوير مهاراته الإدارية للمزرعة"
                    }
                    withContext(Dispatchers.IO) {
                        repository.insertInteractionLog(
                            InteractionLog(
                                timestamp = currentTime,
                                interactionType = if (response.tableName != null) "تسجيل_معاملة" else "استفسار",
                                userMessage = text,
                                assistantResponse = response.reply,
                                derivedInsights = insight
                            )
                        )
                    }
                } catch (e: Exception) {
                    Log.e("FarmViewModel", "Failed to save conversation log to memory: ${e.localizedMessage}")
                }

            } catch (e: Exception) {
                _chatMessages.value = _chatMessages.value + ChatMessage(
                    text = "معلش يا أبو حميد، حصلت مشكلة: ${e.localizedMessage}. جرب تاني كدة يا بطل.",
                    isUser = false
                )
            } finally {
                _isChatLoading.value = false
            }
        }
    }

    private suspend fun applyDatabaseAction(table: String, data: Map<String, String>) {
        val today = getTodayDate()
        when (table.lowercase()) {
            "land" -> {
                val land = Land(
                    code = data["code"] ?: "L${System.currentTimeMillis().toString().takeLast(3)}",
                    name = data["name"] ?: "أرض جديدة",
                    area = data["area"]?.toDoubleOrNull() ?: 1.0,
                    unit = data["unit"] ?: "فدان",
                    region = data["region"] ?: "عام",
                    notes = data["notes"] ?: ""
                )
                repository.insertLand(land)
            }
            "crops" -> {
                val crop = Crop(
                    code = data["code"] ?: "C${System.currentTimeMillis().toString().takeLast(3)}",
                    landCode = data["landCode"] ?: "L001",
                    crop = data["crop"] ?: "محصول جديد",
                    season = data["season"] ?: "شتوي",
                    area = data["area"]?.toDoubleOrNull() ?: 1.0,
                    managementType = data["managementType"] ?: "تقليدي",
                    responsible = data["responsible"] ?: "",
                    expectedProduction = data["expectedProduction"]?.toDoubleOrNull() ?: 0.0,
                    actualProduction = data["actualProduction"]?.toDoubleOrNull() ?: 0.0
                )
                repository.insertCrop(crop)
            }
            "operations" -> {
                val operation = Operation(
                    date = data["date"] ?: today,
                    cropCode = data["cropCode"] ?: "C001",
                    operation = data["operation"] ?: "عملية عامة",
                    worker = data["worker"] ?: "عامل",
                    cost = data["cost"]?.toDoubleOrNull() ?: 0.0,
                    notes = data["notes"] ?: ""
                )
                repository.insertOperation(operation)

                // If operation had cost, record in treasury
                if (operation.cost > 0) {
                    repository.insertTreasuryTransaction(
                        TreasuryTransaction(
                            date = operation.date,
                            movementType = "صرف",
                            value = operation.cost,
                            reason = "تكلفة عملية: ${operation.operation} - ${operation.notes}",
                            party = operation.worker
                        )
                    )
                }
            }
            "inventory" -> {
                val item = InventoryItem(
                    code = data["code"] ?: "INV${System.currentTimeMillis().toString().takeLast(3)}",
                    item = data["item"] ?: "بند مخزون جديد",
                    category = data["category"] ?: "أخرى",
                    unit = data["unit"] ?: "كيلو",
                    openingBalance = data["openingBalance"]?.toDoubleOrNull() ?: 0.0,
                    currentBalance = data["currentBalance"]?.toDoubleOrNull() ?: (data["openingBalance"]?.toDoubleOrNull() ?: 0.0),
                    minimumLevel = data["minimumLevel"]?.toDoubleOrNull() ?: 0.0
                )
                repository.insertInventoryItem(item)
            }
            "inventory_movement" -> {
                val mType = data["movementType"] ?: "وارد"
                val movement = InventoryMovement(
                    date = data["date"] ?: today,
                    itemCode = data["itemCode"] ?: "INV001",
                    movementType = mType,
                    quantity = data["quantity"]?.toDoubleOrNull() ?: 0.0,
                    fromLocation = data["fromLocation"] ?: "",
                    toLocation = data["toLocation"] ?: "",
                    cropCode = data["cropCode"] ?: "",
                    cost = data["cost"]?.toDoubleOrNull() ?: 0.0
                )
                repository.insertInventoryMovement(movement)

                // Update current balance in inventory item
                val existing = database.farmDao().getAllInventoryItems().firstOrNull()?.find { it.code == movement.itemCode }
                if (existing != null) {
                    val newBalance = if (mType == "وارد") {
                        existing.currentBalance + movement.quantity
                    } else {
                        existing.currentBalance - movement.quantity
                    }
                    repository.insertInventoryItem(existing.copy(currentBalance = newBalance))
                }
            }
            "animals" -> {
                val animal = Animal(
                    code = data["code"] ?: "A${System.currentTimeMillis().toString().takeLast(3)}",
                    type = data["type"] ?: "نوع جديد",
                    count = data["count"]?.toIntOrNull() ?: 1,
                    purpose = data["purpose"] ?: "لحم",
                    location = data["location"] ?: "الحظيرة",
                    value = data["value"]?.toDoubleOrNull() ?: 0.0
                )
                repository.insertAnimal(animal)
            }
            "animal_production" -> {
                val prod = AnimalProduction(
                    date = data["date"] ?: today,
                    animalType = data["animalType"] ?: "أبقار",
                    quantity = data["quantity"]?.toDoubleOrNull() ?: 0.0,
                    unit = data["unit"] ?: "لتر",
                    revenue = data["revenue"]?.toDoubleOrNull() ?: 0.0
                )
                repository.insertAnimalProduction(prod)

                // Record revenue in treasury if positive
                if (prod.revenue > 0) {
                    repository.insertTreasuryTransaction(
                        TreasuryTransaction(
                            date = prod.date,
                            movementType = "إيداع",
                            value = prod.revenue,
                            reason = "إيراد إنتاج حيواني: ${prod.animalType} (${prod.quantity} ${prod.unit})",
                            party = "الإنتاج الحيواني"
                        )
                    )
                }
            }
            "workers" -> {
                val worker = Worker(
                    code = data["code"] ?: "W${System.currentTimeMillis().toString().takeLast(3)}",
                    name = data["name"] ?: "عامل جديد",
                    job = data["job"] ?: "عامل عام",
                    phone = data["phone"] ?: "",
                    salary = data["salary"]?.toDoubleOrNull() ?: 0.0
                )
                repository.insertWorker(worker)
            }
            "attendance" -> {
                val att = Attendance(
                    date = data["date"] ?: today,
                    workerCode = data["workerCode"] ?: "W001",
                    task = data["task"] ?: "عمل يومي",
                    location = data["location"] ?: "",
                    hours = data["hours"]?.toDoubleOrNull() ?: 8.0,
                    wage = data["wage"]?.toDoubleOrNull() ?: 0.0
                )
                repository.insertAttendance(att)

                // Record wage payment in treasury if paid immediately
                if (att.wage > 0) {
                    val workerName = database.farmDao().getAllWorkers().firstOrNull()?.find { it.code == att.workerCode }?.name ?: att.workerCode
                    repository.insertTreasuryTransaction(
                        TreasuryTransaction(
                            date = att.date,
                            movementType = "صرف",
                            value = att.wage,
                            reason = "يومية العامل: $workerName",
                            party = workerName
                        )
                    )
                }
            }
            "contacts" -> {
                val contact = Contact(
                    code = data["code"] ?: "CT${System.currentTimeMillis().toString().takeLast(3)}",
                    name = data["name"] ?: "شخص جديد",
                    type = data["type"] ?: "عميل",
                    phone = data["phone"] ?: "",
                    balance = data["balance"]?.toDoubleOrNull() ?: 0.0
                )
                repository.insertContact(contact)
            }
            "equipment" -> {
                val eq = Equipment(
                    code = data["code"] ?: "E${System.currentTimeMillis().toString().takeLast(3)}",
                    name = data["name"] ?: "معدة جديدة",
                    category = data["category"] ?: "عام",
                    purchaseDate = data["purchaseDate"] ?: today,
                    value = data["value"]?.toDoubleOrNull() ?: 0.0,
                    operatingHours = data["operatingHours"]?.toDoubleOrNull() ?: 0.0
                )
                repository.insertEquipment(eq)
            }
            "maintenance" -> {
                val maint = Maintenance(
                    date = data["date"] ?: today,
                    equipmentCode = data["equipmentCode"] ?: "E001",
                    description = data["description"] ?: "صيانة دورية",
                    cost = data["cost"]?.toDoubleOrNull() ?: 0.0
                )
                repository.insertMaintenanceLog(maint)

                // Record maintenance cost in treasury
                if (maint.cost > 0) {
                    val eqName = database.farmDao().getAllEquipment().firstOrNull()?.find { it.code == maint.equipmentCode }?.name ?: maint.equipmentCode
                    repository.insertTreasuryTransaction(
                        TreasuryTransaction(
                            date = maint.date,
                            movementType = "صرف",
                            value = maint.cost,
                            reason = "صيانة معدة: $eqName - ${maint.description}",
                            party = "صيانة"
                        )
                    )
                }
            }
            "water" -> {
                val water = WaterLog(
                    date = data["date"] ?: today,
                    source = data["source"] ?: "بئر",
                    operatingHours = data["operatingHours"]?.toDoubleOrNull() ?: 1.0,
                    cost = data["cost"]?.toDoubleOrNull() ?: 0.0,
                    cropCode = data["cropCode"] ?: ""
                )
                repository.insertWaterLog(water)

                // Record cost in treasury
                if (water.cost > 0) {
                    repository.insertTreasuryTransaction(
                        TreasuryTransaction(
                            date = water.date,
                            movementType = "صرف",
                            value = water.cost,
                            reason = "تكلفة ري من مصدر: ${water.source}",
                            party = "ري مياه"
                        )
                    )
                }
            }
            "purchases" -> {
                val purchase = Purchase(
                    date = data["date"] ?: today,
                    supplier = data["supplier"] ?: "مورد",
                    item = data["item"] ?: "مادة",
                    quantity = data["quantity"]?.toDoubleOrNull() ?: 1.0,
                    price = data["price"]?.toDoubleOrNull() ?: 0.0
                )
                repository.insertPurchase(purchase)

                // Automatically spend from Treasury
                repository.insertTreasuryTransaction(
                    TreasuryTransaction(
                        date = purchase.date,
                        movementType = "صرف",
                        value = purchase.price,
                        reason = "شراء ${purchase.item} (كمية ${purchase.quantity})",
                        party = purchase.supplier
                    )
                )
            }
            "sales" -> {
                val sale = Sale(
                    date = data["date"] ?: today,
                    customer = data["customer"] ?: "عميل",
                    product = data["product"] ?: "محصول",
                    quantity = data["quantity"]?.toDoubleOrNull() ?: 1.0,
                    price = data["price"]?.toDoubleOrNull() ?: 0.0
                )
                repository.insertSale(sale)

                // Automatically deposit into Treasury
                repository.insertTreasuryTransaction(
                    TreasuryTransaction(
                        date = sale.date,
                        movementType = "إيداع",
                        value = sale.quantity * sale.price,
                        reason = "بيع ${sale.product} (كمية ${sale.quantity} بـ ${sale.price} للواحدة)",
                        party = sale.customer
                    )
                )
            }
            "treasury" -> {
                val tx = TreasuryTransaction(
                    date = data["date"] ?: today,
                    movementType = data["movementType"] ?: "إيداع",
                    value = data["value"]?.toDoubleOrNull() ?: 0.0,
                    reason = data["reason"] ?: "معاملة مالية",
                    party = data["party"] ?: ""
                )
                repository.insertTreasuryTransaction(tx)
            }
            "debts" -> {
                val debt = Debt(
                    party = data["party"] ?: "طرف عام",
                    owedToUs = data["owedToUs"]?.toDoubleOrNull() ?: 0.0,
                    owedByUs = data["owedByUs"]?.toDoubleOrNull() ?: 0.0,
                    dueDate = data["dueDate"] ?: today,
                    status = data["status"] ?: "نشط"
                )
                repository.insertDebt(debt)
            }
            "assistant_profile" -> {
                val current = database.farmDao().getAssistantProfile().firstOrNull() ?: AssistantProfile()
                val profile = AssistantProfile(
                    id = 1,
                    personality = data["personality"] ?: current.personality,
                    jobType = data["jobType"] ?: current.jobType,
                    scheduleNotes = data["scheduleNotes"] ?: current.scheduleNotes,
                    behaviorObservations = data["behaviorObservations"] ?: current.behaviorObservations,
                    assistantJobDescription = data["assistantJobDescription"] ?: current.assistantJobDescription,
                    lastUpdated = today
                )
                repository.insertAssistantProfile(profile)
            }
        }
    }

    // --- Direct Manual Database Insertion Callbacks ---
    private val _isProcessingMeeting = MutableStateFlow(false)
    val isProcessingMeeting = _isProcessingMeeting.asStateFlow()

    fun startMeetingRecording() {
        val success = audioRecorder.startRecording()
        if (success) {
            _isMeetingRecording.value = true
            _meetingRecordingDuration.value = 0
            meetingRecordingTimerJob = viewModelScope.launch {
                while (true) {
                    kotlinx.coroutines.delay(1000)
                    _meetingRecordingDuration.value += 1
                }
            }
        }
    }

    fun stopAndProcessMeeting(simulatedText: String? = null) {
        val recordedFile = audioRecorder.stopRecording()
        _isMeetingRecording.value = false
        meetingRecordingTimerJob?.cancel()
        
        val durationFormatted = String.format("%02d:%02d", _meetingRecordingDuration.value / 60, _meetingRecordingDuration.value % 60)
        _meetingRecordingDuration.value = 0
        
        // ponytail: Fallback transcript is hardcoded — replace with Speech-to-Text API on recordedFile when audio transcription is implemented
        val transcript = simulatedText ?: "تم مناقشة خطة زراعة الموسم الجديد وتوزيع حصص الأسمدة وتأمين الميزانية اللازمة لشراء الأعلاف وصيانة شبكة الري."
        
        processAndSaveMeeting(
            title = "اجتماع ذكي صامت ($durationFormatted)",
            attendees = "أحمد باشا والحضور الكرام",
            rawNotes = transcript
        ) {}
    }

    fun cancelMeetingRecording() {
        audioRecorder.stopRecording()
        _isMeetingRecording.value = false
        meetingRecordingTimerJob?.cancel()
        _meetingRecordingDuration.value = 0
    }

    fun processAndSaveMeeting(
        title: String,
        attendees: String,
        rawNotes: String,
        onComplete: () -> Unit
    ) {
        viewModelScope.launch(Dispatchers.IO) {
            _isProcessingMeeting.value = true
            try {
                val key = GeminiManager.getApiKey(getApplication())
                val result = GeminiManager.summarizeMeeting(
                    apiKey = key,
                    title = title,
                    attendees = attendees,
                    rawNotes = rawNotes
                )
                val sdf = SimpleDateFormat("yyyy-MM-dd HH:mm", Locale.getDefault())
                val currentDateStr = sdf.format(Date())

                val meeting = Meeting(
                    title = title,
                    date = currentDateStr,
                    attendees = attendees,
                    rawNotes = rawNotes,
                    summary = result.summary,
                    actionItems = result.actionItems,
                    reportText = result.reportText
                )
                repository.insertMeeting(meeting)
                withContext(Dispatchers.Main) {
                    onComplete()
                }
            } catch (e: Exception) {
                Log.e("FarmViewModel", "Error processing meeting", e)
            } finally {
                _isProcessingMeeting.value = false
            }
        }
    }

    fun deleteMeetingManual(meeting: Meeting) = viewModelScope.launch(Dispatchers.IO) {
        repository.deleteMeeting(meeting)
    }
    fun addLandManual(land: Land) = viewModelScope.launch(Dispatchers.IO) { repository.insertLand(land) }
    fun deleteLandManual(code: String) = viewModelScope.launch(Dispatchers.IO) { repository.deleteLandByCode(code) }

    fun addCropManual(crop: Crop) = viewModelScope.launch(Dispatchers.IO) { repository.insertCrop(crop) }
    fun deleteCropManual(code: String) = viewModelScope.launch(Dispatchers.IO) { repository.deleteCropByCode(code) }

    fun addOperationManual(op: Operation) = viewModelScope.launch(Dispatchers.IO) { repository.insertOperation(op) }
    fun deleteOperationManual(op: Operation) = viewModelScope.launch(Dispatchers.IO) { repository.deleteOperation(op) }

    fun addInventoryManual(item: InventoryItem) = viewModelScope.launch(Dispatchers.IO) { repository.insertInventoryItem(item) }
    fun deleteInventoryManual(code: String) = viewModelScope.launch(Dispatchers.IO) { repository.deleteInventoryItemByCode(code) }

    fun addInventoryMovementManual(mvt: InventoryMovement) = viewModelScope.launch(Dispatchers.IO) { repository.insertInventoryMovement(mvt) }
    fun deleteInventoryMovementManual(mvt: InventoryMovement) = viewModelScope.launch(Dispatchers.IO) { repository.deleteInventoryMovement(mvt) }

    fun addAnimalManual(animal: Animal) = viewModelScope.launch(Dispatchers.IO) { repository.insertAnimal(animal) }
    fun deleteAnimalManual(code: String) = viewModelScope.launch(Dispatchers.IO) { repository.deleteAnimalByCode(code) }

    fun addAnimalProductionManual(prod: AnimalProduction) = viewModelScope.launch(Dispatchers.IO) { repository.insertAnimalProduction(prod) }
    fun deleteAnimalProductionManual(prod: AnimalProduction) = viewModelScope.launch(Dispatchers.IO) { repository.deleteAnimalProduction(prod) }

    fun addWorkerManual(worker: Worker) = viewModelScope.launch(Dispatchers.IO) { repository.insertWorker(worker) }
    fun deleteWorkerManual(code: String) = viewModelScope.launch(Dispatchers.IO) { repository.deleteWorkerByCode(code) }

    fun addAttendanceManual(att: Attendance) = viewModelScope.launch(Dispatchers.IO) { repository.insertAttendance(att) }
    fun deleteAttendanceManual(att: Attendance) = viewModelScope.launch(Dispatchers.IO) { repository.deleteAttendance(att) }

    fun addContactManual(contact: Contact) = viewModelScope.launch(Dispatchers.IO) { repository.insertContact(contact) }
    fun deleteContactManual(code: String) = viewModelScope.launch(Dispatchers.IO) { repository.deleteContactByCode(code) }

    fun addEquipmentManual(eq: Equipment) = viewModelScope.launch(Dispatchers.IO) { repository.insertEquipment(eq) }
    fun deleteEquipmentManual(code: String) = viewModelScope.launch(Dispatchers.IO) { repository.deleteEquipmentByCode(code) }

    fun addMaintenanceManual(maint: Maintenance) = viewModelScope.launch(Dispatchers.IO) { repository.insertMaintenanceLog(maint) }
    fun deleteMaintenanceManual(maint: Maintenance) = viewModelScope.launch(Dispatchers.IO) { repository.deleteMaintenanceLog(maint) }

    fun addWaterManual(water: WaterLog) = viewModelScope.launch(Dispatchers.IO) { repository.insertWaterLog(water) }
    fun deleteWaterManual(water: WaterLog) = viewModelScope.launch(Dispatchers.IO) { repository.deleteWaterLog(water) }

    fun exportCompleteFarmDataToCSV() {
        viewModelScope.launch {
            try {
                val csvContent = withContext(Dispatchers.IO) {
                    val sb = java.lang.StringBuilder()
                    sb.append('\ufeff') // UTF-8 BOM for Arabic support in Excel

                    // 1. Title Banner
                    sb.append("--- سجلات مزرعة أحمد باشا الشاملة 🌾 ---\n")
                    sb.append("تاريخ التصدير,${getTodayDate()}\n")
                    sb.append("نظام التشغيل,مساعد الأستاذ بليغ الذكي (Zero-Manual-Input UX)\n\n")

                    // 2. Lands Table
                    val landsList = database.farmDao().getAllLands().firstOrNull() ?: emptyList()
                    sb.append("=== 🗺️ جدول الأراضي والقطع ===\n")
                    sb.append("الكود,الاسم,المساحة,الوحدة,المنطقة,ملاحظات التربة\n")
                    landsList.forEach { sb.append("${it.code},${it.name},${it.area},${it.unit},${it.region},${it.notes}\n") }
                    sb.append("\n")

                    // 3. Crops Table
                    val cropsList = database.farmDao().getAllCrops().firstOrNull() ?: emptyList()
                    sb.append("=== 🌱 جدول المحاصيل الزراعية ===\n")
                    sb.append("الكود,كود القطعة,اسم المحصول,الموسم,المساحة,نوع الإدارة,المسؤول,الإنتاج المتوقع,الإنتاج الفعلي\n")
                    cropsList.forEach { sb.append("${it.code},${it.landCode},${it.crop},${it.season},${it.area},${it.managementType},${it.responsible},${it.expectedProduction},${it.actualProduction}\n") }
                    sb.append("\n")

                    // 4. Inventory Items
                    val invList = database.farmDao().getAllInventoryItems().firstOrNull() ?: emptyList()
                    sb.append("=== 📦 جدول المخزن والمستودعات ===\n")
                    sb.append("الكود,اسم الصنف,التصنيف,الوحدة,الرصيد الافتتاحي,الرصيد الحالي,الحد الأدنى\n")
                    invList.forEach { sb.append("${it.code},${it.item},${it.category},${it.unit},${it.openingBalance},${it.currentBalance},${it.minimumLevel}\n") }
                    sb.append("\n")

                    // 5. Workers Table
                    val workersList = database.farmDao().getAllWorkers().firstOrNull() ?: emptyList()
                    sb.append("=== 👨‍🌾 جدول العمال والموظفين ===\n")
                    sb.append("الكود,الاسم الكامل,الوظيفة,رقم الهاتف,الراتب الشهري\n")
                    workersList.forEach { sb.append("${it.code},${it.name},${it.job},${it.phone},${it.salary}\n") }
                    sb.append("\n")

                    // 6. Animals Table
                    val animalsList = database.farmDao().getAllAnimals().firstOrNull() ?: emptyList()
                    sb.append("=== 🐄 جدول الثروة الحيوانية ===\n")
                    sb.append("الكود,النوع,العدد,الغرض,الموقع,القيمة المالية الافتراضية\n")
                    animalsList.forEach { sb.append("${it.code},${it.type},${it.count},${it.purpose},${it.location},${it.value}\n") }
                    sb.append("\n")

                    // 7. Equipment Table
                    val equipList = database.farmDao().getAllEquipment().firstOrNull() ?: emptyList()
                    sb.append("=== 🚜 جدول الآلات والمعدات ===\n")
                    sb.append("الكود,اسم الآلة,التصنيف,تاريخ الشراء,القيمة,ساعات التشغيل الكلية\n")
                    equipList.forEach { sb.append("${it.code},${it.name},${it.category},${it.purchaseDate},${it.value},${it.operatingHours}\n") }
                    sb.append("\n")

                    // 8. Purchases Table
                    val purchasesList = database.farmDao().getAllPurchases().firstOrNull() ?: emptyList()
                    sb.append("=== 🛒 سجل المشتريات والمدفوعات ===\n")
                    sb.append("المعرف,التاريخ,المورد,المادة المشتراة,الكمية,التكلفة الإجمالية\n")
                    purchasesList.forEach { sb.append("${it.id},${it.date},${it.supplier},${it.item},${it.quantity},${it.price}\n") }
                    sb.append("\n")

                    // 9. Sales Table
                    val salesList = database.farmDao().getAllSales().firstOrNull() ?: emptyList()
                    sb.append("=== 💰 سجل المبيعات والإيرادات ===\n")
                    sb.append("المعرف,التاريخ,العميل,المنتج المباع,الكمية المباعة,سعر الوحدة\n")
                    salesList.forEach { sb.append("${it.id},${it.date},${it.customer},${it.product},${it.quantity},${it.price}\n") }
                    sb.append("\n")

                    // 10. Treasury Transactions Table
                    val txList = database.farmDao().getAllTreasuryTransactions().firstOrNull() ?: emptyList()
                    sb.append("=== 💵 سجل حركة الخزينة المالية ===\n")
                    sb.append("المعرف,التاريخ,نوع الحركة,المبلغ,السبب والتفاصيل,الطرف الآخر\n")
                    txList.forEach { sb.append("${it.id},${it.date},${it.movementType},${it.value},${it.reason},${it.party}\n") }
                    sb.append("\n")

                    // 11. Debts Table
                    val debtsList = database.farmDao().getAllDebts().firstOrNull() ?: emptyList()
                    sb.append("=== 📈 سجل الديون والالتزامات ===\n")
                    sb.append("المعرف,التاجر / الطرف,مستحق لنا بالخارج,مستحق علينا للغير,تاريخ السداد,الحالة\n")
                    debtsList.forEach { sb.append("${it.id},${it.party},${it.owedToUs},${it.owedByUs},${it.dueDate},${it.status}\n") }
                    sb.append("\n")

                    sb.toString()
                }

                // Write file to app cache directory
                val context = getApplication<Application>()
                val fileName = "Ahmed_Farm_Database_${getTodayDate()}.csv"
                val file = java.io.File(context.cacheDir, fileName)
                file.writeText(csvContent, Charsets.UTF_8)

                // Share file using intent
                val uri = androidx.core.content.FileProvider.getUriForFile(
                    context,
                    "${context.packageName}.fileprovider",
                    file
                )

                val intent = android.content.Intent(android.content.Intent.ACTION_SEND).apply {
                    type = "text/csv"
                    putExtra(android.content.Intent.EXTRA_STREAM, uri)
                    putExtra(android.content.Intent.EXTRA_SUBJECT, "تصدير سجلات المزرعة الشاملة - أحمد باشا")
                    putExtra(android.content.Intent.EXTRA_TEXT, "مرفق شيت الإكسل الشامل لكل جداول وسجلات المزرعة والعمليات.")
                    addFlags(android.content.Intent.FLAG_GRANT_READ_URI_PERMISSION)
                    addFlags(android.content.Intent.FLAG_ACTIVITY_NEW_TASK)
                }

                val chooser = android.content.Intent.createChooser(intent, "تنزيل ومشاركة شيت الإكسل الشامل 📥")
                chooser.addFlags(android.content.Intent.FLAG_ACTIVITY_NEW_TASK)
                context.startActivity(chooser)

                _chatMessages.value = _chatMessages.value + ChatMessage(
                    text = "📥 أبشر يا أحمد باشا! قمت بتجميع كافة جداول وسجلات المزرعة (أراضي، محاصيل، مخازن، خزنة، رواتب، ديون) وتصديرها بالكامل في ملف إكسل (CSV) متوافق ومظبوط بالملي. تقدر تشاركه على الواتساب أو تحفظه في الموبايل فوراً! 📊✨",
                    isUser = false
                )
            } catch (e: Exception) {
                Log.e("FarmViewModel", "Failed to export CSV: ${e.localizedMessage}")
                android.widget.Toast.makeText(getApplication(), "فشل تصدير الملف: ${e.localizedMessage}", android.widget.Toast.LENGTH_LONG).show()
            }
        }
    }

    // ponytail: All document types insert hardcoded fake data — replace with Gemini Vision API for real OCR before production
    fun processAttachedDocument(docType: String) {
        _isChatLoading.value = true
        viewModelScope.launch {
            try {
                kotlinx.coroutines.delay(1500) // Beautiful realistic AI analysis delay
                val today = getTodayDate()

                val userLabel = when (docType) {
                    "INVOICE" -> "📎 تم إرفاق: فاتورة شراء سماد (شركة الأمل) 📸"
                    "CROP_SICK" -> "📎 تم إرفاق: صورة لفحص أوراق محصول قمح بلدي مصابة 🌾"
                    "SOIL_TEST" -> "📎 تم إرفاق: تقرير معمل تحليل عينات التربة لأرض الجبل 🧪"
                    "ACCOUNT_STATEMENT" -> "📎 تم إرفاق: كشف حساب الحاج فتحي للحبوب 📝"
                    else -> "📎 تم إرفاق مستند جديد"
                }

                _chatMessages.value = _chatMessages.value + ChatMessage(
                    text = userLabel,
                    isUser = true,
                    attachedFileType = docType
                )

                when (docType) {
                    "INVOICE" -> {
                        // Insert purchase record inside database
                        database.farmDao().insertPurchase(Purchase(date = today, supplier = "شركة الأمل للأسمدة", item = "سماد سوبر فوسفات", quantity = 1.0, price = 5000.0))
                        // Reflect on treasury balance
                        database.farmDao().insertTreasuryTransaction(TreasuryTransaction(date = today, movementType = "صرف", value = 5000.0, reason = "شراء سماد سوبر فوسفات (شركة الأمل) - ممسوح تلقائياً من فاتورة", party = "شركة الأمل للأسمدة"))

                        _chatMessages.value = _chatMessages.value + ChatMessage(
                            text = "📸 **تم مسح الفاتورة ضوئياً بنجاح بواسطة الأستاذ بليغ!**\n\n" +
                                    "🔍 **البيانات المستخرجة:**\n" +
                                    "- **الشركة المصدرة:** شركة الأمل للأسمدة\n" +
                                    "- **الصنف المشتري:** سماد سوبر فوسفات\n" +
                                    "- **الكمية:** 1.0 طن\n" +
                                    "- **التكلفة الإجمالية:** 5,000 ج.م\n\n" +
                                    "✅ **الإجراء المتخذ:** تم ترحيل الحركة وتعديل رصيد الخزينة وصرف المبلغ تلقائياً دون أي كتابة يدوية من جانبك يا باشا! هل تريد تفعيل تنبيه موعد ري الأرض القادم؟",
                            isUser = false,
                            actionSuccess = true,
                            actionTable = "purchases"
                        )
                    }
                    "CROP_SICK" -> {
                        // Insert emergency operation
                        database.farmDao().insertOperation(Operation(date = today, cropCode = "C001", operation = "رش مبيد فطري وقائي للصدأ", worker = "علي السقا", cost = 250.0, notes = "تمت الجدولة آلياً بناء على تشخيص الأستاذ بليغ لصورة النبات"))

                        _chatMessages.value = _chatMessages.value + ChatMessage(
                            text = "🌾 **تقرير فحص وتصوير النبات الذكي:**\n\n" +
                                    "⚠️ **التشخيص:** رصدت بداية ظهور مرض **(صدأ الأوراق الأصفر)** الفطري على محصول القمح في أرض النيل.\n" +
                                    "🧪 **الخطورة:** متوسطة (يتطلب رشاً وقائياً سريعاً لعدم انتشار جراثيم الصدأ).\n" +
                                    "🛠️ **التوصية:** ري القطعة المصابة ورش مبيد فطري نحاسي (مادة تيبوكونازول) فوراً.\n\n" +
                                    "✅ **الإجراء المتخذ:** قمت بجدولة عملية رش مبيد فطري ومكافحة فورية في سجل العمليات للشغال (علي السقا) بتكلفة تقديرية 250 ج.م لإنقاذ الموسم. الأستاذ بليغ دايماً فايق وصاحي لمصلحتك! 🚜🌾",
                            isUser = false,
                            actionSuccess = true,
                            actionTable = "operations"
                        )
                    }
                    "SOIL_TEST" -> {
                        // Insert custom preference
                        database.farmDao().insertPreference(AhmedPreference(category = "تسميد", preferenceKey = "ملاحظة تربة أرض الجبل", preferenceValue = "نقص فوسفور ونسبة ملوحة زائدة - تغسل بماء بئر عميق لمدة 3 ساعات وتسمد بجرعة مضاعفة فوسفات", lastUpdated = today, confidenceScore = 0.95))

                        _chatMessages.value = _chatMessages.value + ChatMessage(
                            text = "🧪 **تحليل تقرير عينات التربة والمياه:**\n\n" +
                                    "🔬 **قراءة المعمل:**\n" +
                                    "- **درجة الحموضة pH:** 7.8 (قلوية خفيفة مناسبة للزيتون)\n" +
                                    "- **الملوحة EC:** مرتفعة قليلاً بنسبة 15%\n" +
                                    "- **العناصر الناقصة:** النيتروجين والفوسفور حاد جداً\n\n" +
                                    "🧠 **القرارات المستنتجة:** تم إضافة تفضيل تسميد مخصص لـ **(أرض الجبل)** لزيادة فوسفور التسميد وضخ مياه غسيل للتربة، مع جدولة مراجعة دورية لملوحة البئر تلقائياً. كل شيء تحت السيطرة يا كبير! 📈🧬",
                            isUser = false,
                            actionSuccess = true,
                            actionTable = "preferences"
                        )
                    }
                    "ACCOUNT_STATEMENT" -> {
                        // Update debts table
                        database.farmDao().insertDebt(Debt(id = 1, party = "الحاج فتحي للحبوب", owedToUs = 0.0, owedByUs = 5000.0, dueDate = today, status = "نشط"))

                        _chatMessages.value = _chatMessages.value + ChatMessage(
                            text = "📝 **مطابقة كشف الحساب المالي:**\n\n" +
                                    "🤝 **الطرف المقابل:** الحاج فتحي للحبوب\n" +
                                    "📊 **المطابقة:** قمت بمطابقة الكشف المرفق مع الدفتر. تبين وجود تباين (كنا مسجلين دين 15 ألف، والكشف مسجل 5 آلاف فقط لصالح فتحي بعد سداد توريدة الشعير).\n\n" +
                                    "✅ **الإجراء المتخذ:** تم تعديل وتخفيض الدين المستحق للحاج فتحي في جدول الالتزامات ليكون **5,000 ج.م** فقط بدلاً من 15,000 ج.م بناء على الكشف المصحح. وفرنا عليك 10 آلاف جنيه فروقات حسابات يا أحمد باشا! 😎💰",
                            isUser = false,
                            actionSuccess = true,
                            actionTable = "debts"
                        )
                    }
                }
            } catch (e: Exception) {
                Log.e("FarmViewModel", "Document process failed: ${e.localizedMessage}")
            } finally {
                _isChatLoading.value = false
            }
        }
    }

    fun addPurchaseManual(purchase: Purchase) = viewModelScope.launch(Dispatchers.IO) { repository.insertPurchase(purchase) }
    fun deletePurchaseManual(purchase: Purchase) = viewModelScope.launch(Dispatchers.IO) { repository.deletePurchase(purchase) }

    fun addSaleManual(sale: Sale) = viewModelScope.launch(Dispatchers.IO) { repository.insertSale(sale) }
    fun deleteSaleManual(sale: Sale) = viewModelScope.launch(Dispatchers.IO) { repository.deleteSale(sale) }

    fun addTreasuryManual(tx: TreasuryTransaction) = viewModelScope.launch(Dispatchers.IO) { repository.insertTreasuryTransaction(tx) }
    fun deleteTreasuryManual(tx: TreasuryTransaction) = viewModelScope.launch(Dispatchers.IO) { repository.deleteTreasuryTransaction(tx) }

    fun addDebtManual(debt: Debt) = viewModelScope.launch(Dispatchers.IO) { repository.insertDebt(debt) }
    fun deleteDebtManual(debt: Debt) = viewModelScope.launch(Dispatchers.IO) { repository.deleteDebt(debt) }

    fun addPreferenceManual(pref: AhmedPreference) = viewModelScope.launch(Dispatchers.IO) { repository.insertPreference(pref) }
    fun deletePreferenceManual(pref: AhmedPreference) = viewModelScope.launch(Dispatchers.IO) { repository.deletePreference(pref) }
    fun clearInteractionLogsManual() = viewModelScope.launch(Dispatchers.IO) { repository.clearInteractionLogs() }
}

data class ChatMessage(
    val id: String = UUID.randomUUID().toString(),
    val text: String,
    val isUser: Boolean,
    val timestamp: Long = System.currentTimeMillis(),
    val actionSuccess: Boolean = false,
    val actionTable: String? = null,
    val attachedFileUri: String? = null,
    val attachedFileType: String? = null, // e.g. "INVOICE", "CROP_SICK", "SOIL_TEST", "ACCOUNT_STATEMENT"
    val reportData: String? = null // JSON-based string for visual reports
)

class FarmViewModelFactory(private val application: Application) : ViewModelProvider.Factory {
    override fun <T : ViewModel> create(modelClass: Class<T>): T {
        if (modelClass.isAssignableFrom(FarmViewModel::class.java)) {
            @Suppress("UNCHECKED_CAST")
            return FarmViewModel(application) as T
        }
        throw IllegalArgumentException("Unknown ViewModel class")
    }
}
