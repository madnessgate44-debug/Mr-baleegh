package com.example.data

import android.content.Context
import androidx.room.Database
import androidx.room.Room
import androidx.room.RoomDatabase

@Database(
    entities = [
        Land::class,
        Crop::class,
        Operation::class,
        InventoryItem::class,
        InventoryMovement::class,
        Animal::class,
        AnimalProduction::class,
        Worker::class,
        Attendance::class,
        Contact::class,
        Equipment::class,
        Maintenance::class,
        WaterLog::class,
        Purchase::class,
        Sale::class,
        TreasuryTransaction::class,
        Debt::class,
        AssistantProfile::class,
        Meeting::class,
        AhmedPreference::class,
        InteractionLog::class
    ],
    version = 3,
    exportSchema = true
)
abstract class FarmDatabase : RoomDatabase() {
    abstract fun farmDao(): FarmDao

    companion object {
        @Volatile
        private var INSTANCE: FarmDatabase? = null

        fun getDatabase(context: Context): FarmDatabase {
            return INSTANCE ?: synchronized(this) {
                val instance = Room.databaseBuilder(
                    context.applicationContext,
                    FarmDatabase::class.java,
                    "farm_database"
                )
                // ponytail: Replace with explicit Migration objects before any production release — this wipes all data on schema change
                .fallbackToDestructiveMigration()
                .build()
                INSTANCE = instance
                instance
            }
        }
    }
}
