package com.example.data

import kotlinx.coroutines.flow.Flow

class FarmRepository(private val farmDao: FarmDao) {

    val allLands: Flow<List<Land>> = farmDao.getAllLands()
    val allCrops: Flow<List<Crop>> = farmDao.getAllCrops()
    val allOperations: Flow<List<Operation>> = farmDao.getAllOperations()
    val allInventoryItems: Flow<List<InventoryItem>> = farmDao.getAllInventoryItems()
    val allInventoryMovements: Flow<List<InventoryMovement>> = farmDao.getAllInventoryMovements()
    val allAnimals: Flow<List<Animal>> = farmDao.getAllAnimals()
    val allAnimalProduction: Flow<List<AnimalProduction>> = farmDao.getAllAnimalProduction()
    val allWorkers: Flow<List<Worker>> = farmDao.getAllWorkers()
    val allAttendance: Flow<List<Attendance>> = farmDao.getAllAttendance()
    val allContacts: Flow<List<Contact>> = farmDao.getAllContacts()
    val allEquipment: Flow<List<Equipment>> = farmDao.getAllEquipment()
    val allMaintenanceLogs: Flow<List<Maintenance>> = farmDao.getAllMaintenanceLogs()
    val allWaterLogs: Flow<List<WaterLog>> = farmDao.getAllWaterLogs()
    val allPurchases: Flow<List<Purchase>> = farmDao.getAllPurchases()
    val allSales: Flow<List<Sale>> = farmDao.getAllSales()
    val allTreasuryTransactions: Flow<List<TreasuryTransaction>> = farmDao.getAllTreasuryTransactions()
    val allDebts: Flow<List<Debt>> = farmDao.getAllDebts()
    val assistantProfile: Flow<AssistantProfile?> = farmDao.getAssistantProfile()
    val allMeetings: Flow<List<Meeting>> = farmDao.getAllMeetings()
    val allPreferences: Flow<List<AhmedPreference>> = farmDao.getAllPreferences()
    val allInteractionLogs: Flow<List<InteractionLog>> = farmDao.getAllInteractionLogs()

    // --- Write Actions ---
    suspend fun insertAssistantProfile(profile: AssistantProfile) = farmDao.insertAssistantProfile(profile)
    suspend fun insertMeeting(meeting: Meeting) = farmDao.insertMeeting(meeting)
    suspend fun deleteMeeting(meeting: Meeting) = farmDao.deleteMeeting(meeting)
    suspend fun deleteMeetingById(id: Int) = farmDao.deleteMeetingById(id)

    suspend fun insertPreference(preference: AhmedPreference) = farmDao.insertPreference(preference)
    suspend fun deletePreference(preference: AhmedPreference) = farmDao.deletePreference(preference)
    suspend fun deletePreferenceById(id: Int) = farmDao.deletePreferenceById(id)

    suspend fun insertInteractionLog(log: InteractionLog) = farmDao.insertInteractionLog(log)
    suspend fun deleteInteractionLog(log: InteractionLog) = farmDao.deleteInteractionLog(log)
    suspend fun clearInteractionLogs() = farmDao.clearInteractionLogs()

    suspend fun insertLand(land: Land) = farmDao.insertLand(land)
    suspend fun deleteLandByCode(code: String) = farmDao.deleteLandByCode(code)

    suspend fun insertCrop(crop: Crop) = farmDao.insertCrop(crop)
    suspend fun deleteCropByCode(code: String) = farmDao.deleteCropByCode(code)

    suspend fun insertOperation(operation: Operation) = farmDao.insertOperation(operation)
    suspend fun deleteOperation(operation: Operation) = farmDao.deleteOperation(operation)

    suspend fun insertInventoryItem(item: InventoryItem) = farmDao.insertInventoryItem(item)
    suspend fun deleteInventoryItemByCode(code: String) = farmDao.deleteInventoryItemByCode(code)

    suspend fun insertInventoryMovement(movement: InventoryMovement) = farmDao.insertInventoryMovement(movement)
    suspend fun deleteInventoryMovement(movement: InventoryMovement) = farmDao.deleteInventoryMovement(movement)

    suspend fun insertAnimal(animal: Animal) = farmDao.insertAnimal(animal)
    suspend fun deleteAnimalByCode(code: String) = farmDao.deleteAnimalByCode(code)

    suspend fun insertAnimalProduction(production: AnimalProduction) = farmDao.insertAnimalProduction(production)
    suspend fun deleteAnimalProduction(production: AnimalProduction) = farmDao.deleteAnimalProduction(production)

    suspend fun insertWorker(worker: Worker) = farmDao.insertWorker(worker)
    suspend fun deleteWorkerByCode(code: String) = farmDao.deleteWorkerByCode(code)

    suspend fun insertAttendance(attendance: Attendance) = farmDao.insertAttendance(attendance)
    suspend fun deleteAttendance(attendance: Attendance) = farmDao.deleteAttendance(attendance)

    suspend fun insertContact(contact: Contact) = farmDao.insertContact(contact)
    suspend fun deleteContactByCode(code: String) = farmDao.deleteContactByCode(code)

    suspend fun insertEquipment(equipment: Equipment) = farmDao.insertEquipment(equipment)
    suspend fun deleteEquipmentByCode(code: String) = farmDao.deleteEquipmentByCode(code)

    suspend fun insertMaintenanceLog(maintenance: Maintenance) = farmDao.insertMaintenanceLog(maintenance)
    suspend fun deleteMaintenanceLog(maintenance: Maintenance) = farmDao.deleteMaintenanceLog(maintenance)

    suspend fun insertWaterLog(waterLog: WaterLog) = farmDao.insertWaterLog(waterLog)
    suspend fun deleteWaterLog(waterLog: WaterLog) = farmDao.deleteWaterLog(waterLog)

    suspend fun insertPurchase(purchase: Purchase) = farmDao.insertPurchase(purchase)
    suspend fun deletePurchase(purchase: Purchase) = farmDao.deletePurchase(purchase)

    suspend fun insertSale(sale: Sale) = farmDao.insertSale(sale)
    suspend fun deleteSale(sale: Sale) = farmDao.deleteSale(sale)

    suspend fun insertTreasuryTransaction(transaction: TreasuryTransaction) = farmDao.insertTreasuryTransaction(transaction)
    suspend fun deleteTreasuryTransaction(transaction: TreasuryTransaction) = farmDao.deleteTreasuryTransaction(transaction)

    suspend fun insertDebt(debt: Debt) = farmDao.insertDebt(debt)
    suspend fun deleteDebt(debt: Debt) = farmDao.deleteDebt(debt)
}
