package com.example.data

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "land")
data class Land(
    @PrimaryKey val code: String,
    val name: String,
    val area: Double,
    val unit: String, // e.g., "فدان", "متر"
    val region: String,
    val notes: String = ""
)

@Entity(tableName = "crops")
data class Crop(
    @PrimaryKey val code: String,
    val landCode: String,
    val crop: String, // e.g., "قمح", "طماطم"
    val season: String, // e.g., "صيفي", "شتوي"
    val area: Double,
    val managementType: String = "", // e.g., "عضوي", "كيميائي"
    val responsible: String = "",
    val expectedProduction: Double = 0.0,
    val actualProduction: Double = 0.0
)

@Entity(tableName = "operations")
data class Operation(
    @PrimaryKey(autoGenerate = true) val id: Int = 0,
    val date: String, // YYYY-MM-DD
    val cropCode: String,
    val operation: String, // e.g., "ري", "تسميد", "حصاد"
    val worker: String,
    val cost: Double,
    val notes: String = ""
)

@Entity(tableName = "inventory")
data class InventoryItem(
    @PrimaryKey val code: String,
    val item: String, // e.g., "سماد يوريا", "علف مواشي"
    val category: String, // e.g., "أسمدة", "أعلاف"
    val unit: String, // e.g., "طن", "كيلو", "كيس"
    val openingBalance: Double = 0.0,
    val currentBalance: Double = 0.0,
    val minimumLevel: Double = 0.0
)

@Entity(tableName = "inventory_movement")
data class InventoryMovement(
    @PrimaryKey(autoGenerate = true) val id: Int = 0,
    val date: String,
    val itemCode: String,
    val movementType: String, // "وارد" (incoming) or "صادر" (outgoing)
    val quantity: Double,
    val fromLocation: String = "",
    val toLocation: String = "",
    val cropCode: String = "",
    val cost: Double = 0.0
)

@Entity(tableName = "animals")
data class Animal(
    @PrimaryKey val code: String,
    val type: String, // e.g., "أبقار", "أغنام", "دواجن"
    val count: Int,
    val purpose: String, // e.g., "لحم", "حليب", "بيض"
    val location: String,
    val value: Double = 0.0
)

@Entity(tableName = "animal_production")
data class AnimalProduction(
    @PrimaryKey(autoGenerate = true) val id: Int = 0,
    val date: String,
    val animalType: String,
    val quantity: Double,
    val unit: String, // e.g., "لتر", "طبق", "رأس"
    val revenue: Double = 0.0
)

@Entity(tableName = "workers")
data class Worker(
    @PrimaryKey val code: String,
    val name: String,
    val job: String,
    val phone: String = "",
    val salary: Double = 0.0
)

@Entity(tableName = "attendance")
data class Attendance(
    @PrimaryKey(autoGenerate = true) val id: Int = 0,
    val date: String,
    val workerCode: String,
    val task: String = "",
    val location: String = "",
    val hours: Double = 8.0,
    val wage: Double = 0.0
)

@Entity(tableName = "contacts")
data class Contact(
    @PrimaryKey val code: String,
    val name: String,
    val type: String, // "مورد" (supplier) or "عميل" (customer)
    val phone: String = "",
    val balance: Double = 0.0 // positive means they owe us, negative means we owe them
)

@Entity(tableName = "equipment")
data class Equipment(
    @PrimaryKey val code: String,
    val name: String,
    val category: String = "",
    val purchaseDate: String = "",
    val value: Double = 0.0,
    val operatingHours: Double = 0.0
)

@Entity(tableName = "maintenance")
data class Maintenance(
    @PrimaryKey(autoGenerate = true) val id: Int = 0,
    val date: String,
    val equipmentCode: String,
    val description: String,
    val cost: Double = 0.0
)

@Entity(tableName = "water")
data class WaterLog(
    @PrimaryKey(autoGenerate = true) val id: Int = 0,
    val date: String,
    val source: String, // e.g., "بئر عميق", "ترعة"
    val operatingHours: Double = 0.0,
    val cost: Double = 0.0,
    val cropCode: String = ""
)

@Entity(tableName = "purchases")
data class Purchase(
    @PrimaryKey(autoGenerate = true) val id: Int = 0,
    val date: String,
    val supplier: String,
    val item: String,
    val quantity: Double = 1.0,
    val price: Double = 0.0
)

@Entity(tableName = "sales")
data class Sale(
    @PrimaryKey(autoGenerate = true) val id: Int = 0,
    val date: String,
    val customer: String,
    val product: String,
    val quantity: Double = 1.0,
    val price: Double = 0.0
)

@Entity(tableName = "treasury")
data class TreasuryTransaction(
    @PrimaryKey(autoGenerate = true) val id: Int = 0,
    val date: String,
    val movementType: String, // "إيداع" (deposit) or "صرف" (withdrawal)
    val value: Double,
    val reason: String,
    val party: String = "" // who deposited or withdrew
)

@Entity(tableName = "debts")
data class Debt(
    @PrimaryKey(autoGenerate = true) val id: Int = 0,
    val party: String,
    val owedToUs: Double = 0.0, // فلوس لينا برة
    val owedByUs: Double = 0.0, // ديون علينا لغيرنا
    val dueDate: String = "",
    val status: String = "نشط" // "نشط" or "مسدد"
)

@Entity(tableName = "assistant_profile")
data class AssistantProfile(
    @PrimaryKey val id: Int = 1, // Only one entry for the assistant profile
    val personality: String = "ودود ومثقف ويتحدث باللهجة المصرية العامية، دقيق في الحسابات والتفاصيل ويحرص على مصلحة أحمد باشا.",
    val jobType: String = "مستشار مالي وإداري ذكي ومساعد شخصي متكامل لإدارة المزارع الشاملة وحسابات الخزينة والمخازن والعمال.",
    val scheduleNotes: String = "يبدأ أحمد باشا يومه في المزرعة مع إشراقة الشمس الساعة 6 صباحاً بجولة تفقدية، ويجتمع بالعمال بانتظام، ويقوم بتسجيل المعاملات على مدار اليوم.",
    val behaviorObservations: String = "يهتم جداً برصيد الخزينة، وتكلفة وتوافر الأعلاف والمستلزمات في المخازن، ومتابعة حضور وانضباط العمال، وتفقد الثروة الحيوانية والإنتاج اليومي.",
    val assistantJobDescription: String = "أنا المساعد الشخصي والمستشار المخلص لأحمد باشا. أقوم بتدوين كل كبيرة وصغيرة في المزرعة، وأتعلم من أسلوب وجدول وسلوكيات أحمد لتطوير إدارته وتسهيل عمله وتلخيص وصياغة تقارير اجتماعاته.",
    val lastUpdated: String = ""
)

@Entity(tableName = "meetings")
data class Meeting(
    @PrimaryKey(autoGenerate = true) val id: Int = 0,
    val title: String,
    val date: String, // YYYY-MM-DD HH:MM
    val attendees: String,
    val rawNotes: String, // Messy bullet points or audio draft transcripts
    val summary: String, // AI-generated concise executive summary and recommendations
    val actionItems: String, // AI-generated list of action tasks with assigned personnel
    val reportText: String // Beautifully formatted professional final Arabic report for sharing
)

@Entity(tableName = "ahmed_preferences")
data class AhmedPreference(
    @PrimaryKey(autoGenerate = true) val id: Int = 0,
    val category: String, // "زراعة", "مالية", "عمال", "تنبيهات", "عام"
    val preferenceKey: String, // e.g. "المحصول_المفضل"
    val preferenceValue: String,
    val lastUpdated: String,
    val confidenceScore: Double = 1.0 // 0.0 to 1.0
)

@Entity(tableName = "interaction_logs")
data class InteractionLog(
    @PrimaryKey(autoGenerate = true) val id: Int = 0,
    val timestamp: String, // YYYY-MM-DD HH:MM
    val interactionType: String, // "استفسار", "تسجيل_معاملة", "تعديل_تقرير", "نصيحة"
    val userMessage: String,
    val assistantResponse: String,
    val userFeedback: String? = null, // "أعجبني", "تعديل", "تجاهل"
    val derivedInsights: String? = null // Insights extracted like "أحمد يفضل سقي البرسيم بالليل"
)


