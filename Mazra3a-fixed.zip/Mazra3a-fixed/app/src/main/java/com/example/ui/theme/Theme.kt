package com.example.ui.theme

import android.os.Build
import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.dynamicDarkColorScheme
import androidx.compose.material3.dynamicLightColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.platform.LocalContext

private val DarkColorScheme = darkColorScheme(
    primary = FarmPrimaryDark,
    primaryContainer = FarmPrimaryContainerDark,
    secondary = FarmSecondaryDark,
    tertiary = FarmTertiaryDark,
    background = FarmBackgroundDark,
    surface = FarmSurfaceDark,
    onBackground = FarmOnSurfaceDark,
    onSurface = FarmOnSurfaceDark
)

private val LightColorScheme = lightColorScheme(
    primary = FarmPrimary,
    primaryContainer = FarmPrimaryContainer,
    secondary = FarmSecondary,
    tertiary = FarmTertiary,
    background = FarmBackground,
    surface = FarmSurface,
    onPrimary = androidx.compose.ui.graphics.Color.White,
    onSecondary = androidx.compose.ui.graphics.Color.White,
    onBackground = androidx.compose.ui.graphics.Color(0xFF111827), // Modern dark gray for text
    onSurface = androidx.compose.ui.graphics.Color(0xFF111827) // Modern dark gray for text
)

@Composable
fun MyApplicationTheme(
    darkTheme: Boolean = false, // Always light theme for pure white futuristic background
    dynamicColor: Boolean = false, // Force our custom high-end organic farm palette
    content: @Composable () -> Unit,
) {
  val colorScheme = LightColorScheme


  MaterialTheme(colorScheme = colorScheme, typography = Typography, content = content)
}
